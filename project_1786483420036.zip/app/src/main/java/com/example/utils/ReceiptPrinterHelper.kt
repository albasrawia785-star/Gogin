package com.example.utils

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.*
import android.widget.Toast
import com.example.data.Invoice
import com.example.data.InvoiceItem
import com.example.data.PrintOption
import com.example.data.PrintTarget
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

data class PrintJob(
    val invoice: com.example.data.Invoice,
    val items: List<com.example.data.InvoiceItem>,
    val isKitchenOnly: Boolean = false
)

object ReceiptPrinterHelper {

    private var currentContextReference: java.lang.ref.WeakReference<Context>? = null

    // Callback to notify UI of printer failure so it can show the AlertDialog
    var onPrinterFailure: ((printerName: String, job: PrintJob) -> Unit)? = null

    // Queue of pending print jobs
    val pendingQueue = java.util.Collections.synchronizedList(mutableListOf<PrintJob>())

    init {
        startQueueWorker()
    }

    private fun startQueueWorker() {
        Thread {
            while (true) {
                try {
                    Thread.sleep(10000) // Check every 10 seconds
                    val context = currentContextReference?.get()
                    if (context != null && pendingQueue.isNotEmpty()) {
                        val job = pendingQueue[0]
                        val success = silentPrintJob(context, job)
                        if (success) {
                            pendingQueue.removeAt(0)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    @SuppressLint("MissingPermission")
    fun silentPrintJob(context: Context, job: PrintJob): Boolean {
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val mainPaperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        val kitchenPaperWidth = prefs.getString("kitchen_paper_size", "80mm") ?: "80mm"
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) return false

        if (!job.isKitchenOnly) {
            val printerName = prefs.getString("selected_printer_name", "") ?: ""
            val macAddress = getPrinterMacAddress(printerName) ?: return false
            var primarySocket: BluetoothSocket? = null
            var primaryOut: OutputStream? = null
            var primarySuccess = false

            try {
                val primaryDevice = adapter.getRemoteDevice(macAddress)
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                primarySocket = primaryDevice.createRfcommSocketToServiceRecord(uuid)
                adapter.cancelDiscovery()
                primarySocket.connect()
                primaryOut = primarySocket.outputStream

                // Initialize printer
                primaryOut.write(byteArrayOf(0x1B, 0x40)) 
                
                // Print customer receipt
                val customerBitmap = generateCustomerReceiptBitmap(context, job.invoice, job.items, mainPaperWidth)
                val customerBytes = convertBitmapToEscPosBytes(customerBitmap)
                primaryOut.write(customerBytes)

                // Feed and cut
                primaryOut.write(byteArrayOf(0x1B, 0x64, 0x03)) // feed 3 lines
                primaryOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00)) // auto-cut
                primaryOut.flush()
                primarySuccess = true

                // Kitchen integrated on same printer
                val isKitchenPrinterEnabled = prefs.getBoolean("is_kitchen_printer_enabled", false)
                val isKitchenOptionalEnabled = prefs.getBoolean("is_kitchen_optional_enabled", false)
                if (!isKitchenPrinterEnabled && isKitchenOptionalEnabled) {
                    Thread.sleep(800)
                    val kitchenBitmap = generateKitchenReceiptBitmap(context, job.invoice, job.items, mainPaperWidth)
                    val kitchenBytes = convertBitmapToEscPosBytes(kitchenBitmap)
                    primaryOut.write(kitchenBytes)

                    primaryOut.write(byteArrayOf(0x1B, 0x64, 0x03))
                    primaryOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00))
                    primaryOut.flush()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            } finally {
                try { primaryOut?.close() } catch (ex: Exception) {}
                try { primarySocket?.close() } catch (ex: Exception) {}
            }

            // Now, check if separate kitchen printer is needed
            val isKitchenPrinterEnabled = prefs.getBoolean("is_kitchen_printer_enabled", false)
            if (isKitchenPrinterEnabled && primarySuccess) {
                val kitchenPrinterName = prefs.getString("selected_kitchen_printer_name", "") ?: ""
                val kitchenMac = getPrinterMacAddress(kitchenPrinterName) ?: return false
                var kitchenSocket: BluetoothSocket? = null
                var kitchenOut: OutputStream? = null
                try {
                    val kitchenDevice = adapter.getRemoteDevice(kitchenMac)
                    val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                    kitchenSocket = kitchenDevice.createRfcommSocketToServiceRecord(uuid)
                    kitchenSocket.connect()
                    kitchenOut = kitchenSocket.outputStream

                    kitchenOut.write(byteArrayOf(0x1B, 0x40))
                    val kitchenBitmap = generateKitchenReceiptBitmap(context, job.invoice, job.items, kitchenPaperWidth)
                    val kitchenBytes = convertBitmapToEscPosBytes(kitchenBitmap)
                    kitchenOut.write(kitchenBytes)

                    kitchenOut.write(byteArrayOf(0x1B, 0x64, 0x03))
                    kitchenOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00))
                    kitchenOut.flush()
                    return true
                } catch (e: Exception) {
                    e.printStackTrace()
                    // Primary succeeded, but kitchen failed. Re-queue as kitchen only!
                    pendingQueue.add(PrintJob(job.invoice, job.items, isKitchenOnly = true))
                    return false
                } finally {
                    try { kitchenOut?.close() } catch (ex: Exception) {}
                    try { kitchenSocket?.close() } catch (ex: Exception) {}
                }
            }
            return primarySuccess
        } else {
            // Kitchen printer only retry
            val kitchenPrinterName = prefs.getString("selected_kitchen_printer_name", "") ?: ""
            val kitchenMac = getPrinterMacAddress(kitchenPrinterName) ?: return false
            var kitchenSocket: BluetoothSocket? = null
            var kitchenOut: OutputStream? = null
            try {
                val kitchenDevice = adapter.getRemoteDevice(kitchenMac)
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                kitchenSocket = kitchenDevice.createRfcommSocketToServiceRecord(uuid)
                kitchenSocket.connect()
                kitchenOut = kitchenSocket.outputStream

                kitchenOut.write(byteArrayOf(0x1B, 0x40))
                val kitchenBitmap = generateKitchenReceiptBitmap(context, job.invoice, job.items, kitchenPaperWidth)
                val kitchenBytes = convertBitmapToEscPosBytes(kitchenBitmap)
                kitchenOut.write(kitchenBytes)

                kitchenOut.write(byteArrayOf(0x1B, 0x64, 0x03))
                kitchenOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00))
                kitchenOut.flush()
                return true
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            } finally {
                try { kitchenOut?.close() } catch (ex: Exception) {}
                try { kitchenSocket?.close() } catch (ex: Exception) {}
            }
        }
    }

    private fun getPrinterMacAddress(printerName: String): String? {
        val regex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
        val match = regex.find(printerName)
        return match?.value
    }

    private fun centerText(text: String, lineLength: Int): String {
        if (text.length >= lineLength) return text
        val padding = (lineLength - text.length) / 2
        return " ".repeat(padding) + text
    }

    private fun formatRow(col1: String, col2: String, col3: String, w1: Int, w2: Int, w3: Int): String {
        val c1 = if (col1.length > w1) col1.substring(0, w1) else col1.padEnd(w1)
        val c2 = if (col2.length > w2) col2.substring(0, w2) else col2.padStart(w2)
        val c3 = if (col3.length > w3) col3.substring(0, w3) else col3.padStart(w3)
        return c1 + c2 + c3
    }

    fun generateInvoiceText(context: Context, invoice: Invoice, items: List<InvoiceItem>, paperWidth: String): String {
        AppConfig.load(context)
        val restName = AppConfig.restaurantName
        val restPhone = AppConfig.restaurantPhone
        val restAddress = AppConfig.restaurantAddress
        
        val is80mm = paperWidth == "80mm"
        val lineWidth = if (is80mm) 42 else 32
        val lineChar = "-"
        val doubleLineChar = "="
        
        val sb = java.lang.StringBuilder()
        
        // Header (Restaurant Info)
        sb.append(centerText(restName, lineWidth)).append("\n")
        if (restAddress.isNotEmpty()) {
            sb.append(centerText(restAddress, lineWidth)).append("\n")
        }
        if (restPhone.isNotEmpty()) {
            sb.append(centerText("هاتف: $restPhone", lineWidth)).append("\n")
        }
        sb.append(doubleLineChar.repeat(lineWidth)).append("\n")
        
        // Invoice details
        sb.append("رقم الوصل: #${invoice.invoiceNumber}\n")
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH)
        val formattedDate = sdf.format(Date(invoice.orderTime))
        sb.append("التاريخ: $formattedDate\n")
        
        val typeStr = when (invoice.orderType) {
            "صالة" -> if (invoice.orderTypeDetails.isNotEmpty()) "صالة (طاولة: ${invoice.orderTypeDetails})" else "النوع: صالة"
            "دلفري" -> if (invoice.orderTypeDetails.isNotEmpty()) "دلفري (هاتف: ${invoice.orderTypeDetails})" else "النوع: دلفري"
            else -> "النوع: سفري"
        }
        sb.append("$typeStr\n")
        sb.append("طريقة الدفع: ${invoice.paymentMethod}\n")
        sb.append(lineChar.repeat(lineWidth)).append("\n")
        
        // Items Header
        if (is80mm) {
            sb.append(formatRow("المادة", "العدد", "السعر", 24, 4, 14)).append("\n")
        } else {
            sb.append(formatRow("المادة", "العدد", "السعر", 16, 3, 13)).append("\n")
        }
        sb.append(lineChar.repeat(lineWidth)).append("\n")
        
        // Items List
        for (item in items) {
            val name = item.productName
            val qty = "${item.quantity}"
            val price = formatIraqiDinarEnglishNumbers(item.productPrice * item.quantity)
            if (is80mm) {
                sb.append(formatRow(name, qty, price, 24, 4, 14)).append("\n")
            } else {
                sb.append(formatRow(name, qty, price, 16, 3, 13)).append("\n")
            }
        }
        sb.append(lineChar.repeat(lineWidth)).append("\n")
        
        // Totals
        val itemsTotal = items.sumOf { it.productPrice * it.quantity }
        val deliveryFee = invoice.totalAmount - itemsTotal
        if (invoice.orderType == "دلفري" && deliveryFee > 0) {
            val deliveryStr = formatIraqiDinarEnglishNumbers(deliveryFee)
            val subtotalStr = formatIraqiDinarEnglishNumbers(itemsTotal)
            if (is80mm) {
                sb.append(formatRow("مجموع المواد:", "", subtotalStr, 24, 4, 14)).append("\n")
                sb.append(formatRow("أجور التوصيل:", "", deliveryStr, 24, 4, 14)).append("\n")
            } else {
                sb.append(formatRow("مجموع المواد:", "", subtotalStr, 16, 3, 13)).append("\n")
                sb.append(formatRow("أجور التوصيل:", "", deliveryStr, 16, 3, 13)).append("\n")
            }
            sb.append(lineChar.repeat(lineWidth)).append("\n")
        }
        
        val totalStr = formatIraqiDinarEnglishNumbers(invoice.totalAmount)
        if (is80mm) {
            sb.append(formatRow("المجموع الكلي:", "", totalStr, 24, 4, 14)).append("\n")
        } else {
            sb.append(formatRow("المجموع الكلي:", "", totalStr, 16, 3, 13)).append("\n")
        }
        sb.append(doubleLineChar.repeat(lineWidth)).append("\n")
        
        // Footer
        sb.append(centerText("شكراً لزيارتكم وصحتين وعافية", lineWidth)).append("\n")
        sb.append("\n\n")
        
        return sb.toString()
    }

    fun generateShiftReportText(
        context: Context,
        shiftName: String,
        startTime: Long,
        endTime: Long,
        openingCapital: Double,
        totalSales: Double,
        cashSales: Double = totalSales,
        totalExpenses: Double = 0.0,
        paperWidth: String
    ): String {
        AppConfig.load(context)
        val restName = AppConfig.restaurantName
        
        val is80mm = paperWidth == "80mm"
        val lineWidth = if (is80mm) 42 else 32
        val lineChar = "-"
        val doubleLineChar = "="
        
        val sb = java.lang.StringBuilder()
        
        sb.append(centerText(restName, lineWidth)).append("\n")
        sb.append(centerText("تقرير إغلاق نقطة البيع", lineWidth)).append("\n")
        sb.append(doubleLineChar.repeat(lineWidth)).append("\n")
        
        sb.append("الكاشير: $shiftName\n")
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH)
        sb.append("تاريخ الفتح: ${sdf.format(Date(startTime))}\n")
        sb.append("تاريخ الإغلاق: ${sdf.format(Date(endTime))}\n")
        sb.append(lineChar.repeat(lineWidth)).append("\n")
        
        val capitalStr = formatIraqiDinarEnglishNumbers(openingCapital)
        val salesStr = formatIraqiDinarEnglishNumbers(totalSales)
        val cashSalesStr = formatIraqiDinarEnglishNumbers(cashSales)
        val expensesStr = formatIraqiDinarEnglishNumbers(totalExpenses)
        val totalInDrawerStr = formatIraqiDinarEnglishNumbers((openingCapital + cashSales) - totalExpenses)
        
        val labelW = if (is80mm) 26 else 18
        val valW = if (is80mm) 16 else 14
        
        sb.append(formatRow("رأس المال الافتتاحي:", "", capitalStr, labelW, 0, valW)).append("\n")
        sb.append(formatRow("إجمالي المبيعات:", "", salesStr, labelW, 0, valW)).append("\n")
        sb.append(formatRow("إجمالي النقدية:", "", cashSalesStr, labelW, 0, valW)).append("\n")
        sb.append(formatRow("إجمالي المصاريف:", "", expensesStr, labelW, 0, valW)).append("\n")
        sb.append(lineChar.repeat(lineWidth)).append("\n")
        sb.append(formatRow("المبلغ المتوقع بالصندوق:", "", totalInDrawerStr, labelW, 0, valW)).append("\n")
        
        sb.append(doubleLineChar.repeat(lineWidth)).append("\n")
        sb.append(centerText("تم تصدير وحفظ التقرير بنجاح", lineWidth)).append("\n")
        sb.append("\n\n")
        
        return sb.toString()
    }

    @SuppressLint("MissingPermission")
    fun printReceipt(context: Context, invoice: Invoice, items: List<InvoiceItem>) {
        currentContextReference = java.lang.ref.WeakReference(context)
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val mainPaperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        val kitchenPaperWidth = prefs.getString("kitchen_paper_size", "80mm") ?: "80mm"
        val printerName = prefs.getString("selected_printer_name", "") ?: ""
        
        // Flexible Printing Logic settings:
        val isKitchenPrinterEnabled = prefs.getBoolean("is_kitchen_printer_enabled", false)
        val isKitchenOptionalEnabled = prefs.getBoolean("is_kitchen_optional_enabled", false)
        val kitchenPrinterName = prefs.getString("selected_kitchen_printer_name", "") ?: ""
        
        val macAddress = getPrinterMacAddress(printerName)
        if (macAddress == null) {
            val activity = context as? android.app.Activity
            activity?.runOnUiThread {
                Toast.makeText(context, "عذراً، لم يتم العثور على عنوان MAC للطابعة المحددة ($printerName). الرجاء إعادة البحث والاتصال.", Toast.LENGTH_LONG).show()
            }
            return
        }

        val activity = context as? android.app.Activity
        activity?.runOnUiThread {
            Toast.makeText(context, "جاري طباعة الفاتورة...", Toast.LENGTH_SHORT).show()
        }

        // Generate the customer receipt bitmap
        val customerBitmap = generateCustomerReceiptBitmap(context, invoice, items, mainPaperWidth)

        Thread {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null || !adapter.isEnabled) {
                activity?.runOnUiThread {
                    Toast.makeText(context, "البلوتوث مغلق أو غير مدعوم على هذا الجهاز.", Toast.LENGTH_LONG).show()
                    val job = PrintJob(invoice, items, isKitchenOnly = false)
                    pendingQueue.add(job)
                    onPrinterFailure?.invoke(printerName, job)
                }
                return@Thread
            }

            // 1. Always print the Customer Invoice on the primary printer
            var primarySocket: BluetoothSocket? = null
            var primaryOut: OutputStream? = null
            var primarySuccess = false
            try {
                val primaryDevice = adapter.getRemoteDevice(macAddress)
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                
                primarySocket = primaryDevice.createRfcommSocketToServiceRecord(uuid)
                adapter.cancelDiscovery()
                primarySocket.connect()
                primaryOut = primarySocket.outputStream

                // Initialize printer
                primaryOut.write(byteArrayOf(0x1B, 0x40)) 
                
                // Print customer receipt
                val customerBytes = convertBitmapToEscPosBytes(customerBitmap)
                primaryOut.write(customerBytes)

                // Feed and cut
                primaryOut.write(byteArrayOf(0x1B, 0x64, 0x03)) // feed 3 lines
                primaryOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00)) // auto-cut
                primaryOut.flush()
                primarySuccess = true

                // Sequential Kitchen Printing on Primary Printer
                // Only if separate kitchen printer is disabled AND integrated kitchen printing is enabled
                if (!isKitchenPrinterEnabled && isKitchenOptionalEnabled) {
                    Thread.sleep(800) // Small delay for cutter
                    
                    val kitchenBitmap = generateKitchenReceiptBitmap(context, invoice, items, mainPaperWidth)
                    val kitchenBytes = convertBitmapToEscPosBytes(kitchenBitmap)
                    primaryOut.write(kitchenBytes)

                    primaryOut.write(byteArrayOf(0x1B, 0x64, 0x03)) // feed 3 lines
                    primaryOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00)) // auto-cut
                    primaryOut.flush()
                    
                    activity?.runOnUiThread {
                        Toast.makeText(context, "تمت طباعة وصل الزبون والمطبخ من الطابعة الأساسية بنجاح!", Toast.LENGTH_SHORT).show()
                    }
                } else if (!isKitchenPrinterEnabled && !isKitchenOptionalEnabled) {
                    activity?.runOnUiThread {
                        Toast.makeText(context, "تمت طباعة فاتورة الزبون بنجاح!", Toast.LENGTH_SHORT).show()
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
                val job = PrintJob(invoice, items, isKitchenOnly = false)
                pendingQueue.add(job)
                activity?.runOnUiThread {
                    onPrinterFailure?.invoke(printerName, job)
                }
            } finally {
                try { primaryOut?.close() } catch (e: Exception) {}
                try { primarySocket?.close() } catch (e: Exception) {}
            }

            // 2. Direct Kitchen Printing on Separate Kitchen Printer
            // Only if separate kitchen printer is enabled
            if (isKitchenPrinterEnabled && primarySuccess) {
                if (kitchenPrinterName.isEmpty()) {
                    activity?.runOnUiThread {
                        Toast.makeText(context, "لم يتم تحديد طابعة المطبخ المنفصلة في الإعدادات. يرجى اختيارها.", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }

                val kitchenMac = getPrinterMacAddress(kitchenPrinterName)
                if (kitchenMac == null) {
                    activity?.runOnUiThread {
                        Toast.makeText(context, "عذراً، لم يتم العثور على عنوان MAC لطابعة المطبخ المحددة ($kitchenPrinterName).", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }

                activity?.runOnUiThread {
                    Toast.makeText(context, "جاري إرسال الطلب إلى طابعة المطبخ: $kitchenPrinterName ...", Toast.LENGTH_SHORT).show()
                }

                var kitchenSocket: BluetoothSocket? = null
                var kitchenOut: OutputStream? = null
                try {
                    val kitchenDevice = adapter.getRemoteDevice(kitchenMac)
                    val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                    
                    kitchenSocket = kitchenDevice.createRfcommSocketToServiceRecord(uuid)
                    kitchenSocket.connect()
                    kitchenOut = kitchenSocket.outputStream

                    // Initialize printer
                    kitchenOut.write(byteArrayOf(0x1B, 0x40))

                    // Generate and print kitchen receipt
                    val kitchenBitmap = generateKitchenReceiptBitmap(context, invoice, items, kitchenPaperWidth)
                    val kitchenBytes = convertBitmapToEscPosBytes(kitchenBitmap)
                    kitchenOut.write(kitchenBytes)

                    // Feed and cut
                    kitchenOut.write(byteArrayOf(0x1B, 0x64, 0x03)) // feed 3 lines
                    kitchenOut.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00)) // auto-cut
                    kitchenOut.flush()

                    activity?.runOnUiThread {
                        Toast.makeText(context, "تمت طباعة الفاتورة للزبون، وإرسال الطلب للمطبخ بنجاح!", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    val job = PrintJob(invoice, items, isKitchenOnly = true)
                    pendingQueue.add(job)
                    activity?.runOnUiThread {
                        onPrinterFailure?.invoke(kitchenPrinterName, job)
                    }
                } finally {
                    try { kitchenOut?.close() } catch (e: Exception) {}
                    try { kitchenSocket?.close() } catch (e: Exception) {}
                }
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    private fun sendBitmapToBluetoothPrinter(adapter: BluetoothAdapter, macAddress: String, bitmap: Bitmap) {
        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null
        try {
            val device = adapter.getRemoteDevice(macAddress)
            val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
            socket = device.createRfcommSocketToServiceRecord(uuid)
            adapter.cancelDiscovery()
            socket.connect()
            outputStream = socket.outputStream

            // Initialize printer
            outputStream.write(byteArrayOf(0x1B, 0x40))
            
            // Print image
            val bytes = convertBitmapToEscPosBytes(bitmap)
            outputStream.write(bytes)

            // Feed 3 lines & cut
            outputStream.write(byteArrayOf(0x1B, 0x64, 0x03))
            outputStream.write(byteArrayOf(0x1D, 0x56, 0x41, 0x00))
            outputStream.flush()
        } finally {
            try { outputStream?.close() } catch (e: Exception) {}
            try { socket?.close() } catch (e: Exception) {}
        }
    }

    @SuppressLint("MissingPermission")
    fun reprintOrder(
        context: Context,
        invoice: Invoice,
        items: List<InvoiceItem>,
        printOption: PrintOption,
        printTarget: PrintTarget
    ) {
        currentContextReference = java.lang.ref.WeakReference(context)
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val mainPaperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        val kitchenPaperWidth = prefs.getString("kitchen_paper_size", "80mm") ?: "80mm"
        val mainPrinterName = prefs.getString("selected_printer_name", "") ?: ""
        val kitchenPrinterName = prefs.getString("selected_kitchen_printer_name", "") ?: ""

        val activity = context as? android.app.Activity

        val targetPrinterName = when (printTarget) {
            PrintTarget.MAIN_PRINTER -> mainPrinterName
            PrintTarget.KITCHEN_PRINTER -> if (kitchenPrinterName.isNotBlank()) kitchenPrinterName else mainPrinterName
        }

        val targetMac = getPrinterMacAddress(targetPrinterName)
        val mainMac = getPrinterMacAddress(mainPrinterName)

        if (targetMac.isNullOrBlank()) {
            activity?.runOnUiThread {
                Toast.makeText(context, "عذراً، لم يتم العثور على عنوان MAC للطابعة المحددة ($targetPrinterName). الرجاء مراجعة الإعدادات.", Toast.LENGTH_LONG).show()
            }
            return
        }

        activity?.runOnUiThread {
            Toast.makeText(context, "جاري إرسال أصل الطلب لإعادة الطباعة أوفلاين...", Toast.LENGTH_SHORT).show()
        }

        Thread {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null || !adapter.isEnabled) {
                activity?.runOnUiThread {
                    Toast.makeText(context, "البلوتوث مغلق أو غير مدعوم على هذا الجهاز.", Toast.LENGTH_LONG).show()
                }
                return@Thread
            }

            try {
                when (printOption) {
                    PrintOption.CUSTOMER_ONLY -> {
                        val mac = mainMac ?: targetMac
                        val bitmap = generateCustomerReceiptBitmap(context, invoice, items, mainPaperWidth)
                        sendBitmapToBluetoothPrinter(adapter, mac, bitmap)
                        activity?.runOnUiThread {
                            Toast.makeText(context, "تمت إعادة طباعة وصل الزبون بنجاح!", Toast.LENGTH_SHORT).show()
                        }
                    }

                    PrintOption.KITCHEN_ONLY -> {
                        val paperWidth = if (printTarget == PrintTarget.KITCHEN_PRINTER) kitchenPaperWidth else mainPaperWidth
                        val bitmap = generateKitchenReceiptBitmap(context, invoice, items, paperWidth)
                        sendBitmapToBluetoothPrinter(adapter, targetMac, bitmap)
                        activity?.runOnUiThread {
                            Toast.makeText(context, "تمت إعادة طباعة وصل المطبخ بنجاح!", Toast.LENGTH_SHORT).show()
                        }
                    }

                    PrintOption.CUSTOMER_WITH_KITCHEN -> {
                        if (printTarget == PrintTarget.MAIN_PRINTER) {
                            val mac = mainMac ?: targetMac
                            val customerBitmap = generateCustomerReceiptBitmap(context, invoice, items, mainPaperWidth)
                            sendBitmapToBluetoothPrinter(adapter, mac, customerBitmap)

                            Thread.sleep(800)

                            val kitchenBitmap = generateKitchenReceiptBitmap(context, invoice, items, mainPaperWidth)
                            sendBitmapToBluetoothPrinter(adapter, mac, kitchenBitmap)

                            activity?.runOnUiThread {
                                Toast.makeText(context, "تمت إعادة طباعة وصل الزبون ووصل المطبخ من الطابعة الأساسية بنجاح!", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            val mac = mainMac ?: targetMac
                            val customerBitmap = generateCustomerReceiptBitmap(context, invoice, items, mainPaperWidth)
                            sendBitmapToBluetoothPrinter(adapter, mac, customerBitmap)

                            val kMac = if (!targetMac.isNullOrBlank()) targetMac else mac
                            val kitchenBitmap = generateKitchenReceiptBitmap(context, invoice, items, kitchenPaperWidth)
                            sendBitmapToBluetoothPrinter(adapter, kMac, kitchenBitmap)

                            activity?.runOnUiThread {
                                Toast.makeText(context, "تمت إعادة طباعة وصل الزبون ووصل المطبخ من طابعة المطبخ بنجاح!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                activity?.runOnUiThread {
                    Toast.makeText(context, "فشلت إعادة الطباعة: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    fun printShiftReport(
        context: Context,
        shiftName: String,
        startTime: Long,
        endTime: Long,
        openingCapital: Double,
        totalSales: Double,
        cashSales: Double = totalSales,
        totalExpenses: Double = 0.0,
        cancelledInvoices: List<Invoice> = emptyList()
    ) {
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val paperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        val printerName = prefs.getString("selected_printer_name", "") ?: ""
        
        val macAddress = getPrinterMacAddress(printerName)
        if (macAddress == null) {
            val activity = context as? android.app.Activity
            activity?.runOnUiThread {
                Toast.makeText(context, "عذراً، لم يتم العثور على عنوان MAC للطابعة المحددة ($printerName). الرجاء إعادة البحث والاتصال.", Toast.LENGTH_LONG).show()
            }
            return
        }

        val activity = context as? android.app.Activity
        activity?.runOnUiThread {
            Toast.makeText(context, "جاري طباعة تقرير نقطة البيع كـ Bitmap فخم: $printerName", Toast.LENGTH_SHORT).show()
        }

        val bitmap = generateShiftReportBitmap(context, shiftName, startTime, endTime, openingCapital, totalSales, cashSales, totalExpenses, paperWidth, cancelledInvoices)

        Thread {
            var socket: BluetoothSocket? = null
            var outputStream: OutputStream? = null
            try {
                val adapter = BluetoothAdapter.getDefaultAdapter()
                if (adapter == null || !adapter.isEnabled) {
                    activity?.runOnUiThread {
                        Toast.makeText(context, "البلوتوث مغلق أو غير مدعوم على هذا الجهاز.", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }

                val device = adapter.getRemoteDevice(macAddress)
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                
                socket = device.createRfcommSocketToServiceRecord(uuid)
                adapter.cancelDiscovery()
                socket.connect()
                outputStream = socket.outputStream

                // Initialize printer
                outputStream.write(byteArrayOf(0x1B, 0x40)) 
                
                // Convert and print shift report bitmap
                val escPosBytes = convertBitmapToEscPosBytes(bitmap)
                outputStream.write(escPosBytes)

                // Feed and cut paper
                outputStream.write(byteArrayOf(0x1B, 0x64, 0x05)) // feed 5 lines
                outputStream.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00)) // cut
                outputStream.flush()

                activity?.runOnUiThread {
                    Toast.makeText(context, "تم طباعة تقرير نقطة البيع بنجاح!", Toast.LENGTH_SHORT).show()
                }

            } catch (e: Exception) {
                e.printStackTrace()
                activity?.runOnUiThread {
                    Toast.makeText(context, "فشل الاتصال أو الطباعة: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            } finally {
                try {
                    outputStream?.close()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                try {
                    socket?.close()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }.start()
    }

    private fun drawGeometricLogo(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val paint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }
        
        // Draw elegant outer gourmet circle plate
        canvas.drawCircle(cx, cy, size * 0.45f, paint)
        
        // Draw inner concentric ring
        paint.strokeWidth = 1.5f
        canvas.drawCircle(cx, cy, size * 0.35f, paint)
        
        // Draw stylized dome cloche/cover
        paint.style = Paint.Style.FILL
        val rectF = RectF(cx - size * 0.22f, cy - size * 0.15f, cx + size * 0.22f, cy + size * 0.15f)
        canvas.drawArc(rectF, 180f, 180f, true, paint)
        
        // Cloche handle
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3.5f
        canvas.drawCircle(cx, cy - size * 0.17f, size * 0.04f, paint)
        
        // Decorative wings
        paint.strokeWidth = 2f
        canvas.drawLine(cx - size * 0.45f, cy, cx - size * 0.55f, cy, paint)
        canvas.drawLine(cx - size * 0.45f, cy - 8f, cx - size * 0.52f, cy - 8f, paint)
        canvas.drawLine(cx - size * 0.45f, cy + 8f, cx - size * 0.52f, cy + 8f, paint)
        
        canvas.drawLine(cx + size * 0.45f, cy, cx + size * 0.55f, cy, paint)
        canvas.drawLine(cx + size * 0.45f, cy - 8f, cx + size * 0.52f, cy - 8f, paint)
        canvas.drawLine(cx + size * 0.45f, cy + 8f, cx + size * 0.52f, cy + 8f, paint)
    }

    private fun drawDecorativeDivider(canvas: Canvas, width: Float, y: Float) {
        val paint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        
        // Double lines with a gap
        canvas.drawLine(15f, y - 2f, width - 15f, y - 2f, paint)
        canvas.drawLine(15f, y + 2f, width - 15f, y + 2f, paint)
        
        // Center decorative diamond
        paint.style = Paint.Style.FILL
        val cx = width / 2
        val path = Path().apply {
            moveTo(cx, y - 6f)
            lineTo(cx + 8f, y)
            lineTo(cx, y + 6f)
            lineTo(cx - 8f, y)
            close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawBarcode(canvas: Canvas, invoiceNumber: Long, cx: Float, cy: Float, width: Float, height: Float) {
        val paint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.FILL
            isAntiAlias = false
        }
        
        val codeStr = "978${String.format("%06d", invoiceNumber)}2"
        val barCount = codeStr.length * 5 + 10
        val barWidth = width / barCount
        
        var currentX = cx - (width / 2)
        
        // Start guard
        for (i in 0..2) {
            if (i % 2 == 0) {
                canvas.drawRect(currentX, cy, currentX + barWidth, cy + height, paint)
            }
            currentX += barWidth
        }
        
        val random = Random(invoiceNumber + 99)
        for (char in codeStr) {
            val digit = char.toString().toIntOrNull() ?: 3
            val pattern = when (digit) {
                0 -> booleanArrayOf(true, true, false, false, true)
                1 -> booleanArrayOf(true, false, true, true, false)
                2 -> booleanArrayOf(false, true, true, false, true)
                3 -> booleanArrayOf(true, true, true, false, false)
                4 -> booleanArrayOf(false, false, true, true, true)
                5 -> booleanArrayOf(true, false, false, true, true)
                6 -> booleanArrayOf(false, true, false, false, true)
                7 -> booleanArrayOf(true, true, false, true, false)
                8 -> booleanArrayOf(false, true, true, true, false)
                else -> booleanArrayOf(true, false, true, false, true)
            }
            for (bar in pattern) {
                if (bar) {
                    canvas.drawRect(currentX, cy, currentX + barWidth * 1.2f, cy + height, paint)
                }
                currentX += barWidth
            }
        }
        
        // End guard
        for (i in 0..2) {
            if (i % 2 == 0) {
                canvas.drawRect(currentX, cy, currentX + barWidth, cy + height, paint)
            }
            currentX += barWidth
        }
        
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("* $codeStr *", cx, cy + height + 16f, textPaint)
    }

    fun generateCustomerReceiptBitmap(
        context: Context,
        invoice: Invoice,
        items: List<InvoiceItem>,
        paperWidth: String
    ): Bitmap {
        val restName = UserAli.getRestaurantNameFromPrefs(context)
        val restPhone = UserAli.getRestaurantPhoneFromPrefs(context)

        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val textThicknessSetting = prefs.getString("selected_text_thickness", "normal") ?: "normal"
        val extraBold = textThicknessSetting == "extra_bold"
        val boldText = textThicknessSetting == "bold" || extraBold

        val itemsTextSizeSetting = prefs.getString("main_printer_items_text_size", "normal") ?: "normal"
        val itemsScale = when (itemsTextSizeSetting) {
            "small" -> 0.85f
            "large" -> 1.25f
            "extra_large" -> 1.5f
            else -> 1.0f
        }

        // A thermal printer prints at 203 DPI. 58mm = ~384 px, 80mm = ~576 px
        val width = if (paperWidth == "58mm") 384 else 576
        
        // Calculate dynamic height based on item count and items font scale
        val headerHeight = 185f
        val itemHeight = 45f * maxOf(1.0f, itemsScale)
        val totalsHeight = 120f
        val barcodeHeight = 130f
        val footerHeight = 80f
        val dynamicHeight = (headerHeight + (items.size * itemHeight) + totalsHeight + barcodeHeight + footerHeight).toInt()
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val normalPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, if (boldText) Typeface.BOLD else Typeface.NORMAL)
        }

        val baseItemSize = if (paperWidth == "58mm") 16f else 18f
        val itemPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = baseItemSize * itemsScale
            typeface = Typeface.create(Typeface.DEFAULT, if (boldText) Typeface.BOLD else Typeface.NORMAL)
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 22f else 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val centerPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 15f else 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        val leftPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.LEFT
        }

        val rightPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }

        if (extraBold) {
            paint.isFakeBoldText = true
            normalPaint.isFakeBoldText = true
            itemPaint.isFakeBoldText = true
            titlePaint.isFakeBoldText = true
            centerPaint.isFakeBoldText = true
            rightPaint.isFakeBoldText = true
            leftPaint.isFakeBoldText = true
        }

        var currentY = 35f
        
        // 1. Header (Restaurant Info)
        canvas.drawText(restName, (width / 2).toFloat(), currentY, titlePaint)
        currentY += 45f
        if (restPhone.isNotEmpty()) {
            canvas.drawText("هاتف: $restPhone", (width / 2).toFloat(), currentY, centerPaint)
            currentY += 30f
        }
        
        // Double-line Diamond Decorative Divider
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 35f
        
        // Invoice Meta Info (RTL alignment)
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH)
        val formattedDate = sdf.format(Date(invoice.orderTime))
        
        paint.textSize = if (paperWidth == "58mm") 16f else 18f
        normalPaint.textSize = if (paperWidth == "58mm") 15f else 17f
        
        val typeStr = when (invoice.orderType) {
            "صالة" -> if (invoice.orderTypeDetails.isNotEmpty()) "صالة (طاولة: ${invoice.orderTypeDetails})" else "النوع: صالة"
            "دلفري" -> if (invoice.orderTypeDetails.isNotEmpty()) "دلفري (هاتف: ${invoice.orderTypeDetails})" else "النوع: دلفري"
            else -> "النوع: سفري"
        }
        canvas.drawText("رقم الوصل: #${invoice.invoiceNumber}", 15f, currentY, paint)
        canvas.drawText(typeStr, (width - 15).toFloat() - rightPaint.measureText(typeStr), currentY, paint)
        currentY += 35f
        canvas.drawText("التاريخ: $formattedDate", 15f, currentY, normalPaint)
        canvas.drawText("الدفع: ${invoice.paymentMethod}", (width - 15).toFloat() - rightPaint.measureText("الدفع: ${invoice.paymentMethod}"), currentY, normalPaint)
        currentY += 30f
        
        // Divider
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 35f
        
        // Table Headers
        val productX = 15f
        val qtyX = if (paperWidth == "58mm") 180f else 260f
        val priceX = if (paperWidth == "58mm") 265f else 390f
        val totalX = (width - 15).toFloat()
        
        canvas.drawText("المادة", productX, currentY, paint)
        canvas.drawText("العدد", qtyX, currentY, paint)
        canvas.drawText("السعر", priceX, currentY, paint)
        currentY += 35f
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, Paint().apply { color = Color.BLACK; strokeWidth = 1.5f })
        currentY += 30f
        
        // 2. Items List
        for (item in items) {
            val pName = item.productName
            val displayQty = "${item.quantity}"
            val priceFormatted = formatIraqiDinarEnglishNumbers(item.productPrice)
            
            canvas.drawText(pName, productX, currentY, itemPaint)
            canvas.drawText(displayQty, qtyX, currentY, itemPaint)
            canvas.drawText(priceFormatted, priceX, currentY, itemPaint)
            currentY += 40f * maxOf(1.0f, itemsScale)
        }
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, Paint().apply { color = Color.BLACK; strokeWidth = 1.5f })
        currentY += 35f
        
        // 3. Totals Block
        val itemsTotal = items.sumOf { it.productPrice * it.quantity }
        val deliveryFee = invoice.totalAmount - itemsTotal
        val finalTotalPaint = Paint(paint).apply {
            textSize = if (paperWidth == "58mm") 20f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val finalTotalValuePaint = Paint(paint).apply {
            textSize = if (paperWidth == "58mm") 20f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        if (extraBold) {
            finalTotalPaint.isFakeBoldText = true
            finalTotalValuePaint.isFakeBoldText = true
        }

        if (invoice.orderType == "دلفري" && deliveryFee > 0) {
            val subtotalStr = formatIraqiDinarEnglishNumbers(itemsTotal)
            val deliveryStr = formatIraqiDinarEnglishNumbers(deliveryFee)
            
            // Draw Subtotal
            canvas.drawText("مجموع المواد:", 15f, currentY, paint)
            canvas.drawText(subtotalStr, totalX, currentY, finalTotalValuePaint)
            currentY += 40f
            
            // Draw Delivery Fee
            canvas.drawText("أجور التوصيل:", 15f, currentY, paint)
            canvas.drawText(deliveryStr, totalX, currentY, finalTotalValuePaint)
            currentY += 40f
            
            canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, Paint().apply { color = Color.BLACK; strokeWidth = 1f })
            currentY += 35f
        }

        canvas.drawText("المجموع الكلي:", 15f, currentY, finalTotalPaint)
        canvas.drawText(formatIraqiDinarEnglishNumbers(invoice.totalAmount), totalX, currentY, finalTotalValuePaint)
        currentY += 45f
        
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 45f
        
        // Draw Authentic Barcode
        drawBarcode(canvas, invoice.invoiceNumber, (width / 2).toFloat(), currentY, 180f, 40f)
        currentY += 85f
        
        // 4. Footer Message
        canvas.drawText("شكراً لزيارتكم وصحتين وعافية", (width / 2).toFloat(), currentY, centerPaint)
        
        return bitmap
    }

    fun generateKitchenReceiptBitmap(
        context: Context,
        invoice: Invoice,
        items: List<InvoiceItem>,
        paperWidth: String
    ): Bitmap {
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val textThicknessSetting = prefs.getString("selected_text_thickness", "normal") ?: "normal"
        val extraBold = textThicknessSetting == "extra_bold"

        val width = if (paperWidth == "58mm") 384 else 576
        
        // Calculate dynamic height based on items and notes
        var heightNeeded = 260f
        for (item in items) {
            heightNeeded += 65f
            if (item.notes.isNotEmpty()) {
                heightNeeded += 45f
            }
        }
        heightNeeded += 60f
        val dynamicHeight = heightNeeded.toInt()
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val largeBoldPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 32f else 40f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val hugeBoldPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 42f else 56f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val detailPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 22f else 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val timePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        val itemPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 22f else 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }

        val notePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 18f else 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            textAlign = Paint.Align.RIGHT
        }

        if (extraBold) {
            largeBoldPaint.isFakeBoldText = true
            hugeBoldPaint.isFakeBoldText = true
            detailPaint.isFakeBoldText = true
            itemPaint.isFakeBoldText = true
            notePaint.isFakeBoldText = true
        }

        var currentY = 50f

        // 1. Invoice Number (فاتورة رقم: #42)
        canvas.drawText("فاتورة رقم: #${invoice.invoiceNumber}", (width / 2).toFloat(), currentY, largeBoldPaint)
        currentY += 60f

        // 2. Order Type in huge bold text
        val orderTypeLabel = when (invoice.orderType) {
            "صالة" -> "صـــالــة"
            "سفري" -> "ســفــري"
            "دلفري" -> "دلفـــري"
            else -> invoice.orderType
        }
        canvas.drawText(orderTypeLabel, (width / 2).toFloat(), currentY, hugeBoldPaint)
        currentY += 70f

        // 3. Details of order type
        if (invoice.orderType == "صالة") {
            val tableText = "طـاولـة رقم: ${invoice.orderTypeDetails}"
            canvas.drawText(tableText, (width / 2).toFloat(), currentY, detailPaint)
            currentY += 40f
        } else if (invoice.orderType == "دلفري") {
            val deliveryText = "توصيل: ${invoice.orderTypeDetails}"
            canvas.drawText(deliveryText, (width / 2).toFloat(), currentY, detailPaint)
            currentY += 40f
        }

        // 4. Time (HH:mm)
        val sdf = SimpleDateFormat("HH:mm", Locale.ENGLISH)
        val timeStr = "الوقت: ${sdf.format(Date(invoice.orderTime))}"
        canvas.drawText(timeStr, (width / 2).toFloat(), currentY, timePaint)
        currentY += 30f

        // Divider
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, Paint().apply { color = Color.BLACK; strokeWidth = 3f })
        currentY += 40f

        // 5. Items List (Right-aligned)
        val rightX = (width - 15).toFloat()
        for (item in items) {
            val itemLine = "${item.quantity}x ${item.productName}"
            canvas.drawText(itemLine, rightX, currentY, itemPaint)
            currentY += 45f

            if (item.notes.isNotEmpty()) {
                val noteLine = "  * ${item.notes}"
                canvas.drawText(noteLine, rightX, currentY, notePaint)
                currentY += 40f
            }
        }

        // Divider
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, Paint().apply { color = Color.BLACK; strokeWidth = 2f })
        
        return bitmap
    }

    fun generateShiftReportBitmap(
        context: Context,
        shiftName: String,
        startTime: Long,
        endTime: Long,
        openingCapital: Double,
        totalSales: Double,
        cashSales: Double = totalSales,
        totalExpenses: Double = 0.0,
        paperWidth: String,
        cancelledInvoices: List<Invoice> = emptyList()
    ): Bitmap {
        AppConfig.load(context)
        val restName = AppConfig.restaurantName

        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val textThicknessSetting = prefs.getString("selected_text_thickness", "normal") ?: "normal"
        val extraBold = textThicknessSetting == "extra_bold"
        val boldText = textThicknessSetting == "bold" || extraBold

        val width = if (paperWidth == "58mm") 384 else 576
        
        val cancelledHeight = if (cancelledInvoices.isNotEmpty()) {
            80 + (cancelledInvoices.size * 65)
        } else {
            0
        }
        val dynamicHeight = 720 + cancelledHeight
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        
        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val normalPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 15f else 17f
            typeface = Typeface.create(Typeface.DEFAULT, if (boldText) Typeface.BOLD else Typeface.NORMAL)
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 18f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val centerPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 14f else 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        if (extraBold) {
            paint.isFakeBoldText = true
            normalPaint.isFakeBoldText = true
            titlePaint.isFakeBoldText = true
            centerPaint.isFakeBoldText = true
        }

        var currentY = 50f
        
        // Header
        canvas.drawText(restName, (width / 2).toFloat(), currentY, titlePaint)
        currentY += 35f
        canvas.drawText("تقرير إغلاق نقطة البيع", (width / 2).toFloat(), currentY, centerPaint)
        currentY += 35f
        
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 30f
        
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH)
        
        // Report Details
        canvas.drawText("الكاشير: $shiftName", 15f, currentY, paint)
        currentY += 35f
        canvas.drawText("تاريخ الفتح: ${sdf.format(Date(startTime))}", 15f, currentY, normalPaint)
        currentY += 35f
        canvas.drawText("تاريخ الإغلاق: ${sdf.format(Date(endTime))}", 15f, currentY, normalPaint)
        currentY += 40f
        
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 35f
        
        // Calculations
        canvas.drawText("رأس المال الافتتاحي:", 15f, currentY, normalPaint)
        val capitalStr = formatIraqiDinarEnglishNumbers(openingCapital)
        canvas.drawText(capitalStr, (width - 15).toFloat() - normalPaint.measureText(capitalStr), currentY, normalPaint)
        currentY += 35f
        
        canvas.drawText("إجمالي المبيعات:", 15f, currentY, normalPaint)
        val salesStr = formatIraqiDinarEnglishNumbers(totalSales)
        canvas.drawText(salesStr, (width - 15).toFloat() - normalPaint.measureText(salesStr), currentY, normalPaint)
        currentY += 35f

        canvas.drawText("إجمالي النقدية:", 15f, currentY, normalPaint)
        val cashSalesStr = formatIraqiDinarEnglishNumbers(cashSales)
        canvas.drawText(cashSalesStr, (width - 15).toFloat() - normalPaint.measureText(cashSalesStr), currentY, normalPaint)
        currentY += 35f

        canvas.drawText("إجمالي المصاريف:", 15f, currentY, normalPaint)
        val expensesStr = formatIraqiDinarEnglishNumbers(totalExpenses)
        canvas.drawText(expensesStr, (width - 15).toFloat() - normalPaint.measureText(expensesStr), currentY, normalPaint)
        currentY += 40f
        
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 35f
        
        // Total In Drawer
        val totalInDrawer = (openingCapital + cashSales) - totalExpenses
        val totalInDrawerStr = formatIraqiDinarEnglishNumbers(totalInDrawer)
        canvas.drawText("المبلغ المتوقع بالصندوق:", 15f, currentY, paint)
        canvas.drawText(totalInDrawerStr, (width - 15).toFloat() - paint.measureText(totalInDrawerStr), currentY, paint)
        currentY += 45f
        
        drawDecorativeDivider(canvas, width.toFloat(), currentY)
        currentY += 35f

        // Cancelled Invoices List
        if (cancelledInvoices.isNotEmpty()) {
            canvas.drawText("العمليات والطلبات الملغاة/المحذوفة:", 15f, currentY, paint)
            currentY += 35f
            
            for (invoice in cancelledInvoices) {
                val invText = "فاتورة #${invoice.invoiceNumber} | القيمة: ${formatIraqiDinarEnglishNumbers(invoice.totalAmount)}"
                canvas.drawText(invText, 15f, currentY, normalPaint)
                currentY += 30f
                val reasonText = "السبب: ${invoice.cancelReason ?: "ملغي"}"
                canvas.drawText(reasonText, 30f, currentY, normalPaint)
                currentY += 35f
            }
            drawDecorativeDivider(canvas, width.toFloat(), currentY)
            currentY += 35f
        }
        
        // Footer
        canvas.drawText("تم تصدير وحفظ التقرير بنجاح", (width / 2).toFloat(), currentY, centerPaint)
        
        return bitmap
    }
    
    private fun formatIraqiDinarEnglishNumbers(amount: Double): String {
        val df = java.text.DecimalFormat("#,###", java.text.DecimalFormatSymbols(Locale.ENGLISH))
        return "${df.format(amount)} د.ع"
    }

    private fun convertBitmapToEscPosBytes(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val byteWidth = (width + 7) / 8
        val commandLength = 8 + (byteWidth * height)
        val bytes = ByteArray(commandLength)

        // GS v 0 0 xL xH yL yH
        bytes[0] = 0x1D // GS
        bytes[1] = 0x76 // v
        bytes[2] = 0x30 // 0
        bytes[3] = 0x00 // m = 0 (normal size)
        
        bytes[4] = (byteWidth % 256).toByte() // xL
        bytes[5] = (byteWidth / 256).toByte() // xH
        bytes[6] = (height % 256).toByte()    // yL
        bytes[7] = (height / 256).toByte()    // yH

        var index = 8
        for (y in 0 until height) {
            for (xByte in 0 until byteWidth) {
                var currentByte = 0
                for (bit in 0 until 8) {
                    val xPixel = xByte * 8 + bit
                    if (xPixel < width) {
                        val pixel = bitmap.getPixel(xPixel, y)
                        val alpha = Color.alpha(pixel)
                        val red = Color.red(pixel)
                        val green = Color.green(pixel)
                        val blue = Color.blue(pixel)
                        
                        // Treat transparent as white, and calculate luminance threshold
                        val isBlack = if (alpha < 50) {
                            false
                        } else {
                            val luminance = (0.299 * red + 0.587 * green + 0.114 * blue)
                            luminance < 160 // Black pixel threshold
                        }
                        
                        if (isBlack) {
                            currentByte = currentByte or (1 shl (7 - bit))
                        }
                    }
                }
                bytes[index++] = currentByte.toByte()
            }
        }
        return bytes
    }

    fun generateTestReceiptBitmap(
        context: Context,
        paperWidth: String,
        testTitle: String = "فحص الطابعة والاتصال"
    ): Bitmap {
        val restName = UserAli.getRestaurantNameFromPrefs(context)
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val textThicknessSetting = prefs.getString("selected_text_thickness", "normal") ?: "normal"
        val extraBold = textThicknessSetting == "extra_bold"
        val boldText = textThicknessSetting == "bold" || extraBold

        val is58mm = paperWidth == "58mm"
        val width = if (is58mm) 384 else 576
        val dynamicHeight = if (is58mm) 480 else 520
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (is58mm) 15f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val normalPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (is58mm) 14f else 17f
            typeface = Typeface.create(Typeface.DEFAULT, if (boldText) Typeface.BOLD else Typeface.NORMAL)
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (is58mm) 20f else 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val centerPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (is58mm) 14f else 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        if (extraBold) {
            paint.isFakeBoldText = true
            normalPaint.isFakeBoldText = true
            titlePaint.isFakeBoldText = true
            centerPaint.isFakeBoldText = true
        }

        val margin = if (is58mm) 12f else 20f
        val rightMargin = width - margin

        var currentY = 45f
        canvas.drawText(restName, (width / 2).toFloat(), currentY, titlePaint)
        currentY += if (is58mm) 38f else 45f
        
        canvas.drawText(testTitle, (width / 2).toFloat(), currentY, centerPaint)
        currentY += if (is58mm) 35f else 40f
        
        canvas.drawLine(margin, currentY, rightMargin, currentY, Paint().apply { color = Color.BLACK; strokeWidth = 2f })
        currentY += 35f

        val rightAlignPaint = Paint(normalPaint).apply { textAlign = Paint.Align.RIGHT }
        val leftAlignPaint = Paint(normalPaint).apply { textAlign = Paint.Align.LEFT }

        canvas.drawText("1x وجبة شاورما لحم دبل", rightMargin, currentY, rightAlignPaint)
        canvas.drawText("8,500 د.ع", margin, currentY, leftAlignPaint)
        currentY += if (is58mm) 35f else 40f

        canvas.drawText("2x كوكا كولا بارد", rightMargin, currentY, rightAlignPaint)
        canvas.drawText("1,000 د.ع", margin, currentY, leftAlignPaint)
        currentY += if (is58mm) 35f else 40f

        canvas.drawLine(margin, currentY, rightMargin, currentY, Paint().apply { color = Color.BLACK; strokeWidth = 1f })
        currentY += 35f

        val totalTitlePaint = Paint(paint).apply { textAlign = Paint.Align.RIGHT }
        val totalValuePaint = Paint(paint).apply { textAlign = Paint.Align.LEFT }

        val totalLabel = if (is58mm) "المجموع التجريبي:" else "المجموع الكلي للطلب التجريبي:"
        canvas.drawText(totalLabel, rightMargin, currentY, totalTitlePaint)
        canvas.drawText("9,500 د.ع", margin, currentY, totalValuePaint)
        currentY += if (is58mm) 40f else 45f

        val infoPaint = Paint(centerPaint).apply { 
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) 
            textSize = if (is58mm) 14f else 17f
        }
        canvas.drawText("قياس الورق المعتمد: $paperWidth", (width / 2).toFloat(), currentY, infoPaint)
        currentY += if (is58mm) 35f else 40f

        canvas.drawLine(margin, currentY, rightMargin, currentY, Paint().apply { color = Color.BLACK; strokeWidth = 1.5f })
        currentY += 35f

        canvas.drawText("منظومة الكاشير الذكية - جاهزة للعمل", (width / 2).toFloat(), currentY, centerPaint)
        
        return bitmap
    }
}
