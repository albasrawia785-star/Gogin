package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ExpenseEntity
import com.example.ui.theme.*
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(viewModel: POSViewModel) {
    val shiftLogs by viewModel.shiftLogs.collectAsStateWithLifecycle()
    val allExpenses by viewModel.expenses.collectAsStateWithLifecycle()
    
    val activeShift by remember {
        derivedStateOf { shiftLogs.firstOrNull { it.status == "مفتوحة" } }
    }
    
    val activeExpenses by remember {
        derivedStateOf {
            val shift = activeShift
            if (shift == null) emptyList<ExpenseEntity>()
            else allExpenses.filter { it.shiftId == shift.id }
        }
    }
    
    val totalExpenses by remember {
        derivedStateOf { activeExpenses.sumOf { it.amount } }
    }

    var amountInput by remember { mutableStateOf("") }
    var reasonInput by remember { mutableStateOf("") }
    
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val iqFormatter = remember { DecimalFormat("#,###", java.text.DecimalFormatSymbols.getInstance(Locale.US)) }

    fun convertDigitsToEnglish(input: String): String {
        var result = input
        val arabic = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        val persian = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
        for (i in 0..9) {
            result = result.replace(arabic[i], (i + '0'.code).toChar())
            result = result.replace(persian[i], (i + '0'.code).toChar())
        }
        return result
    }
    
    fun formatIraqiDinar(amount: Double): String {
        return "${iqFormatter.format(amount)} د.ع"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(POSBackground)
    ) {
        // Modern Header Block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(POSPrimary)
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "إدارة حركة الصندوق والمصاريف",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "سجل المصاريف اليومية للوردية الحالية بأمان واحترافية",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
                
                // Total Box Indicator
                Card(
                    colors = CardDefaults.cardColors(containerColor = POSAccent.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "مجموع المصاريف",
                            fontSize = 11.sp,
                            color = POSAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = formatIraqiDinar(totalExpenses),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = POSAccent
                        )
                    }
                }
            }
        }

        val currentShift = activeShift
        if (currentShift == null) {
            // No Active Shift State
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(20.dp)),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = POSSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(POSDanger.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AccountBalanceWallet,
                                contentDescription = null,
                                tint = POSDanger,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "الوردية مغلقة حالياً",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "يجب فتح نقطة بيع أو شفت جديد من شاشة الإعدادات لتتمكن من تسجيل المصاريف ومراقبة الصندوق.",
                            fontSize = 14.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        } else {
            // Main content with active shift
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Cash Flow Input Form Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = POSSurface)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "تسجيل مصروف جديد",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextDark
                            )
                            
                            // Amount Input
                            OutlinedTextField(
                                value = amountInput,
                                onValueChange = { input ->
                                    val converted = input.map { char ->
                                        when (char) {
                                            '٠', '۰' -> '0'
                                            '١', '۱' -> '1'
                                            '٢', '۲' -> '2'
                                            '٣', '۳' -> '3'
                                            '٤', '۴' -> '4'
                                            '٥', '۵' -> '5'
                                            '٦', '۶' -> '6'
                                            '٧', '۷' -> '7'
                                            '٨', '۸' -> '8'
                                            '٩', '۹' -> '9'
                                            else -> char
                                        }
                                    }.joinToString("")
                                    // Strictly filter input to allow only English numbers (0-9)
                                    val englishDigitsOnly = converted.filter { it in '0'..'9' }
                                    if (englishDigitsOnly.isEmpty()) {
                                        amountInput = ""
                                    } else {
                                        val parsedDouble = englishDigitsOnly.toDoubleOrNull()
                                        if (parsedDouble != null) {
                                            amountInput = iqFormatter.format(parsedDouble)
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("expense_amount_input"),
                                label = { Text("مبلغ المصروف بالدينار العراقي") },
                                placeholder = { Text("مثال: 5,000") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Payments,
                                        contentDescription = null,
                                        tint = POSPrimary
                                    )
                                },
                                trailingIcon = { Text("د.ع", fontWeight = FontWeight.Bold, color = TextMuted) },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                ),
                                keyboardActions = KeyboardActions(
                                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                ),
                                shape = RoundedCornerShape(16.dp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = POSPrimary,
                                    unfocusedBorderColor = POSBorder,
                                    focusedLabelColor = POSPrimary,
                                    unfocusedLabelColor = TextMuted,
                                    focusedContainerColor = POSSurface,
                                    unfocusedContainerColor = POSSurface
                                )
                            )
                            
                            // Reason / Description Input
                            OutlinedTextField(
                                value = reasonInput,
                                onValueChange = { reasonInput = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("expense_reason_input"),
                                label = { Text("البيان أو السبب") },
                                placeholder = { Text("مثال: مسواك مطبخ، شراء غاز، أجور نقل") },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { focusManager.clearFocus() }
                                ),
                                shape = RoundedCornerShape(16.dp),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = POSPrimary,
                                    unfocusedBorderColor = POSBorder,
                                    focusedLabelColor = POSPrimary,
                                    unfocusedLabelColor = TextMuted,
                                    focusedContainerColor = POSSurface,
                                    unfocusedContainerColor = POSSurface
                                )
                            )
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            // Submit Button
                            Button(
                                onClick = {
                                    val amountValue = amountInput.replace(",", "").toDoubleOrNull()
                                    val reasonValue = reasonInput.trim()
                                    
                                    if (amountValue == null || amountValue <= 0) {
                                        Toast.makeText(context, "الرجاء إدخال مبلغ صحيح", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    if (reasonValue.isEmpty()) {
                                        Toast.makeText(context, "الرجاء إدخال سبب المصروف", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    
                                    viewModel.addExpense(amountValue, reasonValue, currentShift.id)
                                    
                                    amountInput = ""
                                    reasonInput = ""
                                    focusManager.clearFocus()
                                    
                                    Toast.makeText(context, "تم تسجيل المصروف بنجاح", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("add_expense_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = "تسجيل مادة مصروفة",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
                
                // History Header
                item {
                    Text(
                        text = "المصاريف المسجلة في الشفت الحالي (${currentShift.shiftName})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }
                
                if (activeExpenses.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = POSSurface),
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, POSBorder)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "لا توجد مصاريف مسجلة لشفت العمل هذا بعد.",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextMuted,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                } else {
                    items(activeExpenses, key = { it.id }) { expense ->
                        val timeString = remember(expense.timestamp) {
                            val sdf = SimpleDateFormat("hh:mm a", Locale.US)
                            sdf.format(Date(expense.timestamp))
                        }
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(elevation = 1.dp, shape = RoundedCornerShape(20.dp)),
                            colors = CardDefaults.cardColors(containerColor = POSSurface),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                              ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = expense.reason,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextDark
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "الوقت: $timeString",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextMuted
                                    )
                                }
                                
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Text(
                                        text = formatIraqiDinar(expense.amount),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = POSDanger
                                    )
                                    
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteExpense(expense)
                                            Toast.makeText(context, "تم حذف المصروف", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(POSDanger.copy(alpha = 0.1f), CircleShape)
                                            .testTag("delete_expense_${expense.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "حذف المصروف",
                                            tint = POSDanger,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
