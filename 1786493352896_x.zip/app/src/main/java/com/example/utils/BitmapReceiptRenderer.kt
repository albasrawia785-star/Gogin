package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import java.io.ByteArrayOutputStream

object BitmapReceiptRenderer {

    sealed class PrintItem {
        data class TextLine(
            val text: String,
            val size: Float,
            val isBold: Boolean,
            val align: Paint.Align,
            val isTitle: Boolean = false
        ) : PrintItem()

        data class Row(
            val rightText: String,
            val leftText: String,
            val isBold: Boolean,
            val size: Float
        ) : PrintItem()

        data class Divider(
            val isDouble: Boolean,
            val isDotted: Boolean
        ) : PrintItem()

        data class BoxedText(
            val text: String,
            val isBold: Boolean,
            val size: Float
        ) : PrintItem()

        data class Space(
            val height: Float
        ) : PrintItem()
    }

    class ReceiptBuilder(private val context: Context) {
        private val items = mutableListOf<PrintItem>()

        fun addHeader(text: String, size: Float = 28f): ReceiptBuilder {
            items.add(PrintItem.TextLine(text, size, true, Paint.Align.CENTER, isTitle = true))
            return this
        }

        fun addSubHeader(text: String, size: Float = 24f): ReceiptBuilder {
            items.add(PrintItem.TextLine(text, size, true, Paint.Align.CENTER))
            return this
        }

        fun addText(text: String, size: Float = 22f, isBold: Boolean = false, align: Paint.Align = Paint.Align.RIGHT): ReceiptBuilder {
            items.add(PrintItem.TextLine(text, size, isBold, align))
            return this
        }

        fun addRow(rightText: String, leftText: String, isBold: Boolean = false, size: Float = 22f): ReceiptBuilder {
            items.add(PrintItem.Row(rightText, leftText, isBold, size))
            return this
        }

        fun addDivider(isDouble: Boolean = false, isDotted: Boolean = false): ReceiptBuilder {
            items.add(PrintItem.Divider(isDouble, isDotted))
            return this
        }

        fun addBoxedText(text: String, size: Float = 24f, isBold: Boolean = true): ReceiptBuilder {
            items.add(PrintItem.BoxedText(text, isBold, size))
            return this
        }

        fun addSpace(height: Float = 10f): ReceiptBuilder {
            items.add(PrintItem.Space(height))
            return this
        }

        fun buildBytes(): ByteArray {
            // Read settings from SharedPreferences
            val sharedPrefs = context.getSharedPreferences("sales_printer_prefs", Context.MODE_PRIVATE)
            val paperSize = sharedPrefs.getString("printer_size", "58mm") ?: "58mm"
            val threshold = sharedPrefs.getInt("printer_threshold", 128)
            val margin = sharedPrefs.getInt("printer_margin", 8)
            val feedLines = sharedPrefs.getInt("printer_feed", 4)

            val width = if (paperSize == "80mm") 576 else 384

            // 1. First pass: Measure the total height required
            val textPaint = TextPaint().apply {
                isAntiAlias = true
                color = Color.BLACK
            }

            var totalHeight = 20f // start padding
            val itemsHeight = mutableListOf<Float>()

            for (item in items) {
                var h = 0f
                when (item) {
                    is PrintItem.TextLine -> {
                        textPaint.textSize = item.size
                        textPaint.typeface = if (item.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                        val availableWidth = width - (margin * 2)
                        
                        // Use StaticLayout to measure wrapped text height
                        val staticLayout = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            StaticLayout.Builder.obtain(item.text, 0, item.text.length, textPaint, availableWidth)
                                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                                .build()
                        } else {
                            @Suppress("DEPRECATION")
                            StaticLayout(item.text, textPaint, availableWidth, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false)
                        }
                        h = staticLayout.height.toFloat() + 6f
                    }
                    is PrintItem.Row -> {
                        textPaint.textSize = item.size
                        textPaint.typeface = if (item.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                        val fm = textPaint.fontMetrics
                        h = (fm.bottom - fm.top) + 8f
                    }
                    is PrintItem.Divider -> {
                        h = if (item.isDouble) 15f else 10f
                    }
                    is PrintItem.BoxedText -> {
                        textPaint.textSize = item.size
                        textPaint.typeface = if (item.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                        val fm = textPaint.fontMetrics
                        val textHeight = fm.bottom - fm.top
                        h = textHeight + 30f // generous padding for the box
                    }
                    is PrintItem.Space -> {
                        h = item.height
                    }
                }
                itemsHeight.add(h)
                totalHeight += h
            }

            totalHeight += 20f // bottom padding

            // 2. Create Bitmap and Canvas
            val bitmap = Bitmap.createBitmap(width, totalHeight.toInt(), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            // 3. Second pass: Draw everything
            var currentY = 20f
            val paint = Paint().apply {
                color = Color.BLACK
                isAntiAlias = true
            }

            for (i in items.indices) {
                val item = items[i]
                val itemH = itemsHeight[i]
                
                when (item) {
                    is PrintItem.TextLine -> {
                        paint.textSize = item.size
                        paint.typeface = if (item.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                        paint.textAlign = Paint.Align.LEFT // Use StaticLayout for actual drawing to wrap & support RTL elegantly
                        
                        val availableWidth = width - (margin * 2)
                        
                        val alignment = when (item.align) {
                            Paint.Align.CENTER -> Layout.Alignment.ALIGN_CENTER
                            Paint.Align.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
                            else -> Layout.Alignment.ALIGN_NORMAL
                        }

                        val staticLayout = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            StaticLayout.Builder.obtain(item.text, 0, item.text.length, TextPaint(paint), availableWidth)
                                .setAlignment(alignment)
                                .build()
                        } else {
                            @Suppress("DEPRECATION")
                            StaticLayout(item.text, TextPaint(paint), availableWidth, alignment, 1.0f, 0.0f, false)
                        }

                        canvas.save()
                        canvas.translate(margin.toFloat(), currentY)
                        staticLayout.draw(canvas)
                        canvas.restore()
                    }
                    is PrintItem.Row -> {
                        paint.textSize = item.size
                        paint.typeface = if (item.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                        
                        val fm = paint.fontMetrics
                        val textY = currentY - fm.top + 4f
                        
                        // Right text (key) - Aligned to right
                        paint.textAlign = Paint.Align.RIGHT
                        canvas.drawText(item.rightText, (width - margin).toFloat(), textY, paint)
                        
                        // Left text (value) - Aligned to left
                        paint.textAlign = Paint.Align.LEFT
                        canvas.drawText(item.leftText, margin.toFloat(), textY, paint)
                    }
                    is PrintItem.Divider -> {
                        paint.strokeWidth = if (item.isDouble) 3f else 1.5f
                        val midY = currentY + itemH / 2f
                        
                        if (item.isDotted) {
                            // Draw dotted line
                            val pathEffect = android.graphics.DashPathEffect(floatArrayOf(5f, 5f), 0f)
                            paint.pathEffect = pathEffect
                            canvas.drawLine(margin.toFloat(), midY, (width - margin).toFloat(), midY, paint)
                            paint.pathEffect = null
                        } else {
                            if (item.isDouble) {
                                canvas.drawLine(margin.toFloat(), midY - 2, (width - margin).toFloat(), midY - 2, paint)
                                canvas.drawLine(margin.toFloat(), midY + 2, (width - margin).toFloat(), midY + 2, paint)
                            } else {
                                canvas.drawLine(margin.toFloat(), midY, (width - margin).toFloat(), midY, paint)
                            }
                        }
                    }
                    is PrintItem.BoxedText -> {
                        paint.textSize = item.size
                        paint.typeface = if (item.isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                        paint.textAlign = Paint.Align.CENTER
                        
                        val fm = paint.fontMetrics
                        val textY = currentY + (itemH / 2f) - (fm.ascent + fm.descent) / 2f
                        
                        // Draw box frame
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = 2.5f
                        val rect = Rect(margin + 4, (currentY + 4).toInt(), width - margin - 4, (currentY + itemH - 4).toInt())
                        canvas.drawRect(rect, paint)
                        
                        // Draw text centered
                        paint.style = Paint.Style.FILL
                        canvas.drawText(item.text, (width / 2f), textY, paint)
                    }
                    is PrintItem.Space -> {
                        // Do nothing, just spacing
                    }
                }
                currentY += itemH
            }

            // 4. Binarize and convert to ESC/POS bytes
            val printBytes = convertBitmapToEscPosBytes(bitmap, threshold)
            
            // Add feed lines at the end
            val bos = ByteArrayOutputStream()
            bos.write(printBytes)
            
            if (feedLines > 0) {
                // ESC d n (feed n lines)
                bos.write(0x1B)
                bos.write(0x64)
                bos.write(feedLines)
            }
            
            // Cut paper command (GS V 66 0)
            bos.write(0x1D)
            bos.write(0x56)
            bos.write(0x42)
            bos.write(0x00)

            return bos.toByteArray()
        }
    }

    // Converts a grayscale/color Bitmap into ESC/POS monochrome print bytes using GS v 0 command
    fun convertBitmapToEscPosBytes(bitmap: Bitmap, threshold: Int = 128): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        
        // Width in bytes must be a multiple of 8
        val widthBytes = (width + 7) / 8
        val totalBytes = widthBytes * height
        
        val data = ByteArray(totalBytes)
        
        var byteIndex = 0
        for (y in 0 until height) {
            for (xb in 0 until widthBytes) {
                var currentByte = 0
                for (bit in 0 until 8) {
                    val x = xb * 8 + bit
                    var isBlack = false
                    if (x < width) {
                        val pixel = bitmap.getPixel(x, y)
                        val r = Color.red(pixel)
                        val g = Color.green(pixel)
                        val b = Color.blue(pixel)
                        val alpha = Color.alpha(pixel)
                        
                        // If transparent or white, it's white. Otherwise, check luminance.
                        if (alpha < 50) {
                            isBlack = false
                        } else {
                            val luminance = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
                            isBlack = luminance < threshold
                        }
                    }
                    if (isBlack) {
                        // In ESC/POS monochrome, 1 is black, 0 is white.
                        // The MSB (most significant bit) is the leftmost pixel.
                        currentByte = currentByte or (1 shl (7 - bit))
                    }
                }
                data[byteIndex++] = currentByte.toByte()
            }
        }
        
        val bos = ByteArrayOutputStream()
        // GS v 0 m xL xH yL yH d1...dk
        bos.write(0x1D)
        bos.write(0x76)
        bos.write(0x30)
        bos.write(0) // Mode: 0 (Normal)
        
        // xL, xH (width in bytes)
        bos.write(widthBytes and 0xFF)
        bos.write((widthBytes shr 8) and 0xFF)
        
        // yL, yH (height in pixels)
        bos.write(height and 0xFF)
        bos.write((height shr 8) and 0xFF)
        
        // Print data
        bos.write(data)
        
        return bos.toByteArray()
    }
}
