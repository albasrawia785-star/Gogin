package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.Customer
import com.example.data.model.InstallmentBill
import com.example.data.model.Sale
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class AppScreen {
    SPLASH, HOME, ADD_INSTALLMENT, CUSTOMERS, CUSTOMER_DETAILS, ALERTS, SETTINGS
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = AppRepository(
        db.customerDao(),
        db.saleDao(),
        db.installmentBillDao()
    )

    private val sharedPrefs = application.getSharedPreferences("sales_installments_prefs", Context.MODE_PRIVATE)

    // Store Name setting (Immutable from coco configuration file)
    val storeName: String = com.example.BuildConfig.STORE_NAME

    fun updateStoreName(newName: String) {
        // No-op: Store name is managed from coco / coco.json
    }

    // ==========================================
    // LOGIN AND SESSION SYSTEM (OFFLINE)
    // ==========================================
    var isLoggedIn by mutableStateOf(sharedPrefs.getBoolean("is_logged_in", false))
        private set

    var isTrial by mutableStateOf(sharedPrefs.getBoolean("is_trial", false))
        private set

    var trialExpiredMessage by mutableStateOf<String?>(null)
        private set

    var trialTimeRemainingString by mutableStateOf("")
        private set

    init {
        checkTrialStatus()
    }

    fun checkTrialStatus() {
        if (isLoggedIn && isTrial) {
            val startTime = sharedPrefs.getLong("trial_start_time", 0L)
            if (startTime != 0L) {
                val elapsed = System.currentTimeMillis() - startTime
                val limit = 24 * 60 * 60 * 1000L // 24 hours in milliseconds
                if (elapsed >= limit) {
                    // Force log out
                    isLoggedIn = false
                    isTrial = false
                    sharedPrefs.edit().putBoolean("is_logged_in", false).putBoolean("is_trial", false).apply()
                    trialExpiredMessage = "انتهت المدة التجريبية (24 ساعة)، يرجى التواصل مع المطور لشراء النسخة الأصلية وتفعيل الحساب"
                    currentScreen = AppScreen.HOME
                } else {
                    val remaining = limit - elapsed
                    val hours = remaining / (1000 * 60 * 60)
                    val minutes = (remaining % (1000 * 60 * 60)) / (1000 * 60)
                    trialTimeRemainingString = "المتبقي من الفترة التجريبية: $hours ساعة و $minutes دقيقة"
                }
            }
        }
    }

    fun performLogin(usernameOrPhone: String, password: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val trimmed = usernameOrPhone.trim()
        val currentTime = System.currentTimeMillis()
        val limit = 24 * 60 * 60 * 1000L // 24 hours

        // Check if trial is already expired
        val savedStartTime = sharedPrefs.getLong("trial_start_time", 0L)
        val hasTrialExpired = savedStartTime != 0L && (currentTime - savedStartTime >= limit)

        if ((trimmed == "ali" || trimmed == "07810936407") && password == "19971997") {
            isLoggedIn = true
            isTrial = false
            trialExpiredMessage = null
            sharedPrefs.edit()
                .putBoolean("is_logged_in", true)
                .putBoolean("is_trial", false)
                .apply()
            onSuccess()
        } else if (trimmed == "1" && password == "1") {
            if (hasTrialExpired) {
                onError("انتهت المدة التجريبية (24 ساعة)، يرجى التواصل مع المطور لشراء النسخة الأصلية وتفعيل الحساب")
            } else {
                // If start time is not set, set it now
                val startTimeToSave = if (savedStartTime == 0L) currentTime else savedStartTime
                isLoggedIn = true
                isTrial = true
                trialExpiredMessage = null
                sharedPrefs.edit()
                    .putBoolean("is_logged_in", true)
                    .putBoolean("is_trial", true)
                    .putLong("trial_start_time", startTimeToSave)
                    .apply()
                checkTrialStatus()
                onSuccess()
            }
        } else {
            onError("اسم المستخدم/الهاتف أو كلمة المرور غير صحيحة")
        }
    }

    fun performLogout() {
        isLoggedIn = false
        isTrial = false
        sharedPrefs.edit()
            .putBoolean("is_logged_in", false)
            .putBoolean("is_trial", false)
            .apply()
        currentScreen = AppScreen.HOME
    }

    // ==========================================
    // PRINTER INTEGRATION STATES & HELPERS
    // ==========================================
    var pendingContractSale by mutableStateOf<Sale?>(null)
    var pendingContractCustomer by mutableStateOf<Customer?>(null)

    var pendingPaymentBill by mutableStateOf<InstallmentBill?>(null)
    var pendingPaymentSale by mutableStateOf<Sale?>(null)
    var pendingPaymentCustomer by mutableStateOf<Customer?>(null)
    var pendingPaymentAllBills by mutableStateOf<List<InstallmentBill>>(emptyList())

    fun clearPendingContractPrint() {
        pendingContractSale = null
        pendingContractCustomer = null
    }

    fun clearPendingPaymentPrint() {
        pendingPaymentBill = null
        pendingPaymentSale = null
        pendingPaymentCustomer = null
        pendingPaymentAllBills = emptyList()
    }

    fun printContract(context: Context, sale: Sale, customer: Customer) {
        val printerManager = com.example.utils.BluetoothPrinterManager.getInstance(context)
        val totalStr = String.format(Locale.US, "%,.0f د.ع", sale.installmentPrice)
        val downStr = String.format(Locale.US, "%,.0f د.ع", sale.downPayment)
        val remainingStr = String.format(Locale.US, "%,.0f د.ع", sale.installmentPrice - sale.downPayment)
        
        printerManager.printContractInvoice(
            storeName = storeName,
            contractNum = sale.id.toString(),
            date = sale.saleDate,
            customerName = customer.name,
            phone = customer.phone,
            productName = sale.itemName,
            totalPrice = totalStr,
            downPayment = downStr,
            remaining = remainingStr,
            firstDueDate = sale.firstDueDate
        )
    }

    fun printReceipt(context: Context, bill: InstallmentBill, sale: Sale, customer: Customer, allBillsForSale: List<InstallmentBill>) {
        val printerManager = com.example.utils.BluetoothPrinterManager.getInstance(context)
        
        val paidBills = allBillsForSale.filter { it.isPaid }
        val totalPaid = paidBills.sumOf { it.amountPaid }
        val remaining = (sale.installmentPrice - totalPaid).coerceAtLeast(0.0)
        
        val nextUnpaidBill = allBillsForSale.filter { !it.isPaid }.minByOrNull { it.dueDate }
        val nextDueDateStr = nextUnpaidBill?.dueDate ?: "لا يوجد (مسدد بالكامل)"
        
        val amountPaidStr = String.format(Locale.US, "%,.0f د.ع", bill.amountPaid)
        val totalPaidStr = String.format(Locale.US, "%,.0f د.ع", totalPaid)
        val remainingStr = String.format(Locale.US, "%,.0f د.ع", remaining)
        
        printerManager.printPaymentReceipt(
            storeName = storeName,
            transactionNum = bill.id.toString(),
            contractNum = bill.saleId.toString(),
            customerName = customer.name,
            date = bill.paymentDate ?: bill.dueDate,
            amountPaid = amountPaidStr,
            totalPaid = totalPaidStr,
            remaining = remainingStr,
            nextDueDate = nextDueDateStr
        )
    }

    // Navigation State
    var currentScreen by mutableStateOf(AppScreen.HOME)
    val selectedCustomerId = MutableStateFlow<Long?>(null)

    // Data Flows
    val customers = repository.getAllCustomers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sales = repository.getAllSales().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val bills = repository.getAllBills().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filter State
    val customerSearchQuery = MutableStateFlow("")
    val customerStatusFilter = MutableStateFlow("ALL") // ALL, OVERDUE, ACTIVE
    val customerSortBy = MutableStateFlow("NAME") // NAME, DATE

    // Derived filtered customers computed entirely in background thread (Dispatchers.Default)
    val filteredCustomers = combine(customers, bills, customerSearchQuery, customerStatusFilter) { customersList, allBills, query, filter ->
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = sdf.format(Date())
        val today = try { sdf.parse(todayStr) } catch (e: Exception) { null }

        customersList.filter { customer ->
            val matchesSearch = if (query.isEmpty()) true else {
                customer.name.contains(query, ignoreCase = true) || customer.phone.contains(query)
            }

            val customerBills = allBills.filter { it.customerId == customer.id }
            val isOverdue = customerBills.any { bill ->
                if (bill.isPaid) false else {
                    try {
                        val dueDate = sdf.parse(bill.dueDate)
                        dueDate != null && today != null && dueDate.before(today)
                    } catch (e: Exception) {
                        false
                    }
                }
            }

            val matchesFilter = when (filter) {
                "OVERDUE" -> isOverdue
                "ACTIVE" -> !isOverdue && customerBills.any { !it.isPaid }
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Derived statistics
    val totalCustomersCount = customers.map { it.size }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    
    val dashboardStats = combine(sales, bills) { allSales, allBills ->
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = sdf.format(Date())
        val today = sdf.parse(todayStr) ?: Date()

        var totalSalesAmount = 0.0
        var totalProfits = 0.0
        var overdueCount = 0
        var dueTodayCount = 0
        var upcomingCount = 0

        allSales.forEach { sale ->
            totalSalesAmount += sale.installmentPrice
            totalProfits += (sale.installmentPrice - sale.cashPrice)
        }

        allBills.forEach { bill ->
            if (!bill.isPaid) {
                try {
                    val dueDate = sdf.parse(bill.dueDate)
                    if (dueDate != null) {
                        when {
                            dueDate.before(today) -> overdueCount++
                            dueDate.equals(today) -> dueTodayCount++
                            dueDate.after(today) && dueDate.time - today.time <= 7 * 24 * 60 * 60 * 1000L -> upcomingCount++
                        }
                    }
                } catch (e: Exception) {
                    // Ignore parsing error
                }
            }
        }

        DashboardStats(
            overdueCount = overdueCount,
            dueTodayCount = dueTodayCount,
            upcomingCount = upcomingCount,
            totalSales = totalSalesAmount,
            totalProfits = totalProfits
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // Selected Customer Details flow
    val selectedCustomer = selectedCustomerId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else repository.getCustomerByIdFlow(id)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedCustomerSales = selectedCustomerId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getSalesByCustomerId(id)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedCustomerBills = selectedCustomerId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getBillsByCustomerId(id)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // ==========================================
    // STEPPER STATE FOR ADDING NEW INSTALLMENT
    // ==========================================
    var currentStep by mutableStateOf(1)

    // Stage 1: Customer Details
    var stepCustomerHasGuarantor by mutableStateOf(false)
    var stepCustomerName by mutableStateOf("")
    var stepCustomerPhone by mutableStateOf("")
    var stepCustomerJob by mutableStateOf("")
    var stepCustomerNationalId by mutableStateOf("")
    var stepCustomerProvince by mutableStateOf("بغداد")
    var stepCustomerLandmark by mutableStateOf("")
    var stepCustomerRegDate by mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))

    // Guarantor details (if hasGuarantor)
    var stepGuarantorName by mutableStateOf("")
    var stepGuarantorPhone by mutableStateOf("")
    var stepGuarantorJob by mutableStateOf("")
    var stepGuarantorNationalId by mutableStateOf("")

    // Stage 2: Item Details
    var stepItemName by mutableStateOf("")
    var stepItemDescription by mutableStateOf("")

    // Stage 3: Calculations
    var stepCashPrice by mutableStateOf("")
    var stepInstallmentPrice by mutableStateOf("")
    var stepDownPayment by mutableStateOf("")
    var stepMonthsCount by mutableStateOf("12")
    var stepDueDay by mutableStateOf("1")
    var stepFirstDueDate by mutableStateOf("")

    init {
        // Set default first due date to 1 month from now
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        stepFirstDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        stepDueDay = cal.get(Calendar.DAY_OF_MONTH).toString()

        // Boot and prepopulate database
        viewModelScope.launch {
            try {
                val dummyCleared = sharedPrefs.getBoolean("dummy_data_cleared_v4", false)
                if (!dummyCleared) {
                    repository.clearAllData()
                    sharedPrefs.edit().putBoolean("dummy_data_cleared_v4", true).apply()
                }
                repository.prepopulateIfEmpty()
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Error prepopulating database", e)
            }
            
            // Auto-reconnect to saved Bluetooth printer on app launch
            try {
                com.example.utils.BluetoothPrinterManager.getInstance(application).autoReconnect()
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Error auto-reconnecting to printer", e)
            }
        }
    }

    // Reactive automated monthly installment calculation
    val stepMonthlyInstallment: Double
        get() = 0.0

    val stepRemainingAmount: Double
        get() {
            val instPrice = com.example.ui.components.Formatter.sanitizeAmount(stepInstallmentPrice)
            val downPay = com.example.ui.components.Formatter.sanitizeAmount(stepDownPayment)
            return (instPrice - downPay).coerceAtLeast(0.0)
        }

    fun resetStepper() {
        currentStep = 1
        stepCustomerHasGuarantor = false
        stepCustomerName = ""
        stepCustomerPhone = ""
        stepCustomerJob = ""
        stepCustomerNationalId = ""
        stepCustomerProvince = "بغداد"
        stepCustomerLandmark = ""
        stepCustomerRegDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        stepGuarantorName = ""
        stepGuarantorPhone = ""
        stepGuarantorJob = ""
        stepGuarantorNationalId = ""

        stepItemName = ""
        stepItemDescription = ""

        stepCashPrice = ""
        stepInstallmentPrice = ""
        stepDownPayment = ""
        stepMonthsCount = "12"

        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 1)
        stepFirstDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        stepDueDay = cal.get(Calendar.DAY_OF_MONTH).toString()
    }

    fun saveNewInstallment(context: Context, onError: (String) -> Unit, onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    // 1. Create/Save Customer
                    val customer = Customer(
                        name = stepCustomerName,
                        phone = stepCustomerPhone,
                        job = stepCustomerJob,
                        nationalId = stepCustomerNationalId,
                        province = stepCustomerProvince,
                        nearestLandmark = stepCustomerLandmark,
                        registrationDate = stepCustomerRegDate,
                        hasGuarantor = stepCustomerHasGuarantor,
                        guarantorName = if (stepCustomerHasGuarantor) stepGuarantorName else "",
                        guarantorPhone = if (stepCustomerHasGuarantor) stepGuarantorPhone else "",
                        guarantorJob = if (stepCustomerHasGuarantor) stepGuarantorJob else "",
                        guarantorNationalId = if (stepCustomerHasGuarantor) stepGuarantorNationalId else ""
                    )
                    val customerId = repository.insertCustomer(customer)

                    // 2. Create Sale
                    val cashVal = com.example.ui.components.Formatter.sanitizeAmount(stepCashPrice)
                    val instVal = com.example.ui.components.Formatter.sanitizeAmount(stepInstallmentPrice)
                    val downVal = com.example.ui.components.Formatter.sanitizeAmount(stepDownPayment)
                    val dueDayVal = stepDueDay.toIntOrNull() ?: 1
                    val monthsCountVal = stepMonthsCount.toIntOrNull() ?: 12
                    val remaining = instVal - downVal
                    val monthlyInstallmentVal = if (monthsCountVal > 0) remaining / monthsCountVal else 0.0

                    val sale = Sale(
                        customerId = customerId,
                        itemName = stepItemName,
                        itemDescription = stepItemDescription,
                        cashPrice = cashVal,
                        installmentPrice = instVal,
                        downPayment = downVal,
                        monthsCount = monthsCountVal,
                        monthlyInstallment = monthlyInstallmentVal,
                        dueDay = dueDayVal,
                        firstDueDate = stepFirstDueDate,
                        saleDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                        status = if (instVal - downVal <= 0.0) "COMPLETED" else "ACTIVE"
                    )

                    // 3. Generate Installment Bills schedule
                    val billsList = mutableListOf<InstallmentBill>()
                    
                    // First: insert the down payment as a paid InstallmentBill (if downVal > 0)
                    if (downVal > 0.0) {
                        billsList.add(
                            InstallmentBill(
                                saleId = 0, // will be overwritten in repository
                                customerId = customerId,
                                billNumber = 0, // 0 indicates down payment
                                dueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                amount = downVal,
                                amountPaid = downVal,
                                paymentDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                isPaid = true,
                                notes = "الدفعة الأولى (مقدم العقد)"
                            )
                        )
                    }

                    // Second: insert monthly installments for the remaining amount
                    if (remaining > 0.0 && monthsCountVal > 0) {
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        val firstDate = sdf.parse(stepFirstDueDate) ?: Date()
                        
                        for (i in 0 until monthsCountVal) {
                            val cal = Calendar.getInstance()
                            cal.time = firstDate
                            cal.add(Calendar.MONTH, i)
                            
                            val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                            val dayToSet = if (dueDayVal > maxDay) maxDay else dueDayVal
                            cal.set(Calendar.DAY_OF_MONTH, dayToSet)
                            
                            val dueDateStr = sdf.format(cal.time)
                            
                            billsList.add(
                                InstallmentBill(
                                    saleId = 0,
                                    customerId = customerId,
                                    billNumber = i + 1,
                                    dueDate = dueDateStr,
                                    amount = monthlyInstallmentVal,
                                    amountPaid = 0.0,
                                    paymentDate = null,
                                    isPaid = false,
                                    notes = "القسط الشهري رقم ${i + 1}"
                                )
                            )
                        }
                    }

                    val saleId = repository.insertSale(sale, billsList)
                    val finalSale = sale.copy(id = saleId)
                    val finalCustomer = customer.copy(id = customerId)
                    
                    pendingContractSale = finalSale
                    pendingContractCustomer = finalCustomer
                }

                resetStepper()
                onComplete()
            } catch (e: Exception) {
                e.printStackTrace()
                onError("تعذر حفظ البيانات محلياً، يرجى المحاولة لاحقاً")
            }
        }
    }

    fun printOfflineReceipt(context: Context, customer: Customer, sale: Sale) {
        val printerManager = com.example.utils.BluetoothPrinterManager.getInstance(context)
        val cashStr = String.format(Locale.US, "%,.0f د.ع", sale.cashPrice)
        val downStr = String.format(Locale.US, "%,.0f د.ع", sale.downPayment)
        val remainingStr = String.format(Locale.US, "%,.0f د.ع", sale.installmentPrice - sale.downPayment)
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
        
        printerManager.printNewCustomerOfflineReceipt(
            storeName = storeName,
            customerName = customer.name,
            customerPhone = customer.phone,
            itemName = sale.itemName,
            cashPrice = cashStr,
            downPayment = downStr,
            remaining = remainingStr,
            nextDueDate = sale.firstDueDate,
            todayDate = todayStr
        )
    }

    // ==========================================
    // PAYMENT PROCESSING - NEW TRANSACTION-BASED SYSTEM
    // ==========================================
    fun addNewPayment(saleId: Long, customerId: Long, amount: Double, dateStr: String, notes: String, onError: (String) -> Unit, onSuccess: () -> Unit) {
        viewModelScope.launch {
            try {
                val isError = withContext(Dispatchers.IO) {
                    val sale = repository.getSaleById(saleId) ?: return@withContext "عقد البيع غير موجود"
                    val bills = repository.getBillsBySaleId(saleId).first()
                    
                    // Filter normal unpaid installments (typically billNumber != 0, as 0 is down payment)
                    val unpaidBills = bills.filter { !it.isPaid && it.billNumber != 0 }.sortedWith(compareBy({ it.dueDate }, { it.billNumber }))
                    
                    if (unpaidBills.isEmpty()) {
                        return@withContext "جميع أقساط هذا العقد مدفوعة بالكامل"
                    }
                    
                    val totalUnpaid = unpaidBills.sumOf { it.amount - it.amountPaid }
                    if (amount > totalUnpaid + 0.01) {
                        return@withContext "قيمة الدفعة أكبر من إجمالي الأقساط المتبقية للغلق"
                    }
                    
                    var remainingPayment = amount
                    val billsToUpdate = mutableListOf<InstallmentBill>()
                    
                    for (bill in unpaidBills) {
                        if (remainingPayment <= 0.0) break
                        
                        val neededToFullyPay = bill.amount - bill.amountPaid
                        if (remainingPayment >= neededToFullyPay - 0.01) {
                            // Fully pay this installment
                            val updatedBill = bill.copy(
                                amountPaid = bill.amount,
                                isPaid = true,
                                paymentDate = dateStr,
                                notes = if (notes.isNotEmpty()) notes else "سداد قسط رقم ${bill.billNumber}"
                            )
                            billsToUpdate.add(updatedBill)
                            remainingPayment -= neededToFullyPay
                        } else {
                            // Partially pay this installment
                            val updatedBill = bill.copy(
                                amountPaid = bill.amountPaid + remainingPayment,
                                isPaid = false,
                                paymentDate = dateStr,
                                notes = if (notes.isNotEmpty()) notes else "سداد جزئي قسط رقم ${bill.billNumber}"
                            )
                            billsToUpdate.add(updatedBill)
                            remainingPayment = 0.0
                        }
                    }
                    
                    // Update database
                    billsToUpdate.forEach { repository.updateBill(it) }
                    
                    // Recalculate contract state
                    recalculateContractState(saleId)
                    
                    try {
                        val updatedBills = repository.getBillsBySaleId(saleId).first()
                        val latestPaidBill = billsToUpdate.lastOrNull() ?: updatedBills.first()
                        val customer = repository.getCustomerById(customerId)
                        
                        pendingPaymentBill = latestPaidBill
                        pendingPaymentSale = sale
                        pendingPaymentCustomer = customer
                        pendingPaymentAllBills = updatedBills
                    } catch (e: Exception) {
                        android.util.Log.e("MainViewModel", "Error setting pending payment print state", e)
                    }
                    null
                }
                
                if (isError != null) {
                    onError(isError)
                } else {
                    onSuccess()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                onError(e.message ?: "تعذر التخزين محلياً")
            }
        }
    }

    fun deletePayment(bill: InstallmentBill) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    // Under the fixed monthly schedule system, we don't delete the bill record (which represents the installment slot).
                    // We simply reset it to be unpaid and clear its payment details.
                    val updatedBill = bill.copy(
                        isPaid = false,
                        amountPaid = 0.0,
                        paymentDate = null,
                        notes = "تم إلغاء السداد"
                    )
                    repository.updateBill(updatedBill)
                    recalculateContractState(bill.saleId)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun editPayment(bill: InstallmentBill, newAmount: Double, newDate: String, newNotes: String, onError: (String) -> Unit, onSuccess: () -> Unit) {
        viewModelScope.launch {
            try {
                val isError = withContext(Dispatchers.IO) {
                    val sale = repository.getSaleById(bill.saleId) ?: return@withContext "عقد البيع غير موجود"
                    
                    if (newAmount > bill.amount) {
                        return@withContext "المبلغ المدخل أكبر من قيمة القسط الأصلية (${bill.amount} د.ع)"
                    }
                    
                    val updatedBill = bill.copy(
                        amountPaid = newAmount,
                        paymentDate = newDate,
                        isPaid = newAmount >= bill.amount - 0.01,
                        notes = newNotes
                    )
                    repository.updateBill(updatedBill)
                    
                    recalculateContractState(bill.saleId)
                    null
                }
                
                if (isError != null) {
                    onError(isError)
                } else {
                    onSuccess()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                onError(e.message ?: "تعذر التخزين محلياً")
            }
        }
    }

    private suspend fun recalculateContractState(saleId: Long) {
        val sale = repository.getSaleById(saleId) ?: return
        val allBills = repository.getBillsBySaleId(saleId).first()
        
        // Count total paid amount
        val totalPaid = allBills.filter { it.isPaid }.sumOf { it.amountPaid }
        val remaining = sale.installmentPrice - totalPaid
        
        if (remaining <= 0.0) {
            repository.updateSale(sale.copy(status = "COMPLETED"))
        } else {
            repository.updateSale(sale.copy(status = "ACTIVE"))
        }
    }

    private fun addOneMonth(dateStr: String): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        try {
            val date = sdf.parse(dateStr)
            if (date != null) {
                cal.time = date
                cal.add(Calendar.MONTH, 1)
                return sdf.format(cal.time)
            }
        } catch (e: Exception) {
            // fallback
        }
        return dateStr
    }


    // ==========================================
    // EXPORT / IMPORT ZIP BACKUPS
    // ==========================================
    fun exportBackup(context: Context, onSuccess: (File) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                // Close DB connection safely
                db.close()
                val dbFile = context.getDatabasePath("sales_installments_db")
                val backupZipFile = File(context.cacheDir, "sales_backup.zip")
                
                ZipOutputStream(FileOutputStream(backupZipFile)).use { zos ->
                    if (dbFile.exists()) {
                        zos.putNextEntry(ZipEntry("sales_installments_db"))
                        FileInputStream(dbFile).use { fis ->
                            fis.copyTo(zos)
                        }
                        zos.closeEntry()
                    }
                    // Include -wal and -shm if they exist
                    val walFile = File(dbFile.path + "-wal")
                    if (walFile.exists()) {
                        zos.putNextEntry(ZipEntry("sales_installments_db-wal"))
                        FileInputStream(walFile).use { fis -> fis.copyTo(zos) }
                        zos.closeEntry()
                    }
                    val shmFile = File(dbFile.path + "-shm")
                    if (shmFile.exists()) {
                        zos.putNextEntry(ZipEntry("sales_installments_db-shm"))
                        FileInputStream(shmFile).use { fis -> fis.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
                
                // Reopen database
                AppDatabase.getDatabase(context)
                onSuccess(backupZipFile)
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "حدث خطأ أثناء تصدير النسخة الاحتياطية")
            }
        }
    }

    fun importBackup(context: Context, zipFile: File, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                db.close()
                val dbFile = context.getDatabasePath("sales_installments_db")
                
                ZipInputStream(FileInputStream(zipFile)).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val targetFile = File(dbFile.parentFile, entry.name)
                        FileOutputStream(targetFile).use { fos ->
                            zis.copyTo(fos)
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }

                // Reopen database
                AppDatabase.getDatabase(context)
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "حدث خطأ أثناء استيراد النسخة الاحتياطية")
            }
        }
    }

    fun deleteCustomerFully(customer: Customer, onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    // Delete all bills for this customer
                    val billsList = repository.getBillsByCustomerId(customer.id).first()
                    billsList.forEach { repository.deleteBill(it) }

                    // Delete all sales for this customer
                    val salesList = repository.getSalesByCustomerId(customer.id).first()
                    salesList.forEach { repository.deleteSale(it) }

                    // Delete customer itself
                    repository.deleteCustomer(customer)
                }
                onComplete()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

data class DashboardStats(
    val overdueCount: Int = 0,
    val dueTodayCount: Int = 0,
    val upcomingCount: Int = 0,
    val totalSales: Double = 0.0,
    val totalProfits: Double = 0.0
)
