import { doc, setDoc, deleteDoc, onSnapshot, collection } from "firebase/firestore";
import { db } from "./config/firebase";
import { COLLECTIONS, DOCUMENTS } from "./config/firestore";

export interface Payment {
  date: string;
  amount: number;
}

export interface CustomerImages {
  personal: string;
  resFront: string;
  resBack: string;
  idFront: string;
  idBack: string;
}

export interface GuarantorImages {
  personal?: string;
  idFront?: string;
  idBack?: string;
  resFront?: string;
  resBack?: string;
}

export interface Guarantor {
  name: string;
  phone: string;
  address: string;
  images?: GuarantorImages;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  productName: string;
  productSerial: string;
  totalAmount: number;
  upfront: number;
  monthlyAmount: number;
  remainingAmount: number;
  dueDay: number;
  images: CustomerImages;
  payments: Payment[];
  status: 'active' | 'done';
  dateAdded: string;
  hasGuarantor?: boolean;
  guarantor?: Guarantor;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  
  // Do not throw for LIST or GET operations to allow graceful offline/cached operation
  if (operationType !== OperationType.LIST && operationType !== OperationType.GET) {
    throw new Error(JSON.stringify(errInfo));
  }
}

/**
 * Saves or updates a customer in Firebase Firestore
 */
export async function saveCustomer(customer: Customer): Promise<void> {
  const path = `${COLLECTIONS.CUSTOMERS}/${customer.id}`;
  try {
    const customerRef = doc(db, COLLECTIONS.CUSTOMERS, customer.id);
    await setDoc(customerRef, customer);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Deletes a customer from Firebase Firestore
 */
export async function deleteCustomerFromDb(id: string): Promise<void> {
  const path = `${COLLECTIONS.CUSTOMERS}/${id}`;
  try {
    const customerRef = doc(db, COLLECTIONS.CUSTOMERS, id);
    await deleteDoc(customerRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Subscribes to real-time changes of the customers list in Firestore
 */
export function subscribeToCustomers(callback: (customers: Customer[]) => void): () => void {
  const path = COLLECTIONS.CUSTOMERS;
  const customersCollection = collection(db, path);
  const unsubscribe = onSnapshot(customersCollection, (snapshot) => {
    const list: Customer[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      list.push({
        id: docSnap.id,
        name: data.name || "",
        phone: data.phone || "",
        productName: data.productName || "",
        productSerial: data.productSerial || "",
        totalAmount: data.totalAmount || 0,
        upfront: data.upfront || 0,
        monthlyAmount: data.monthlyAmount || 0,
        remainingAmount: data.remainingAmount || 0,
        dueDay: data.dueDay || 1,
        images: data.images || { personal: '', resFront: '', resBack: '', idFront: '', idBack: '' },
        payments: data.payments || [],
        status: data.status || 'active',
        dateAdded: data.dateAdded || "",
        hasGuarantor: data.hasGuarantor || false,
        guarantor: data.guarantor || undefined
      });
    });
    callback(list);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
  });
  return unsubscribe;
}

export interface SystemCredentials {
  username?: string;
  password?: string;
  fullName?: string;
  age?: string;
  phone?: string;
}

/**
 * Saves or updates system credentials in Firestore
 */
export async function saveSystemCredentials(creds: SystemCredentials): Promise<void> {
  const path = `${COLLECTIONS.SYSTEM}/${DOCUMENTS.CREDENTIALS}`;
  try {
    const docRef = doc(db, COLLECTIONS.SYSTEM, DOCUMENTS.CREDENTIALS);
    await setDoc(docRef, creds, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Subscribes to real-time changes of system credentials in Firestore
 */
export function subscribeToSystemCredentials(callback: (creds: SystemCredentials | null) => void): () => void {
  const path = `${COLLECTIONS.SYSTEM}/${DOCUMENTS.CREDENTIALS}`;
  const docRef = doc(db, COLLECTIONS.SYSTEM, DOCUMENTS.CREDENTIALS);
  const unsubscribe = onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      const data = docSnap.data();
      callback({
        username: data.username || "",
        password: data.password || "",
        fullName: data.fullName || "",
        age: data.age || "",
        phone: data.phone || ""
      });
    } else {
      callback(null);
    }
  }, (error) => {
    console.error("Error subscribing to system credentials:", error);
    callback(null);
  });
  return unsubscribe;
}

