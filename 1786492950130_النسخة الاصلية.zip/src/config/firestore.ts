// Centralized Firestore collection and document names, and storage paths
export const COLLECTIONS = {
  CUSTOMERS: "customers",
  SYSTEM: "system",
} as const;

export const DOCUMENTS = {
  CREDENTIALS: "credentials",
} as const;

export const STORAGE_PATHS = {
  // Add storage paths if needed in the future
} as const;

// Database constants
export const DB_CONSTANTS = {
  DEFAULT_DUE_DAY: 1,
} as const;
