import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFunctions } from "firebase/functions";

// Centralized Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCXiWUKVR6Thwbpdbk3d1j0ri4cQZhWkvE",
  authDomain: "ali-test-b8d51.firebaseapp.com",
  projectId: "ali-test-b8d51",
  storageBucket: "ali-test-b8d51.firebasestorage.app",
  messagingSenderId: "252314003864",
  appId: "1:252314003864:web:f6732e6d9ae8d784bbe3ed",
  measurementId: "G-SNRJHYEDFK"
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize and export Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);

export default app;
