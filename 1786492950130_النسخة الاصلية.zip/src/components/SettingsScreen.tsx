import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { User, Lock, Save, Key, RefreshCw, AlertCircle, Phone, Calendar, UserCheck } from "lucide-react";
import { saveSystemCredentials, SystemCredentials } from "../firebase";

interface SettingsScreenProps {
  currentCredentials: SystemCredentials | null;
  onCredentialsChange: (newCreds: SystemCredentials) => void;
  showToast: (msg: string, type: "success" | "danger" | "info") => void;
}

export default function SettingsScreen({
  currentCredentials,
  onCredentialsChange,
  showToast
}: SettingsScreenProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [age, setAge] = useState("");
  const [phone, setPhone] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Initialize form with current credentials
  useEffect(() => {
    if (currentCredentials) {
      setUsername(currentCredentials.username || "ali");
      setPassword(currentCredentials.password || "0");
      setFullName(currentCredentials.fullName || "");
      setAge(currentCredentials.age || "");
      setPhone(currentCredentials.phone || "");
    } else {
      setUsername("ali");
      setPassword("0");
      setFullName("");
      setAge("");
      setPhone("");
    }
  }, [currentCredentials]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!username.trim()) {
      showToast("❌ يرجى إدخال اسم مستخدم صالح", "danger");
      return;
    }
    if (!password.trim()) {
      showToast("❌ يرجى إدخال كلمة مرور صالحة", "danger");
      return;
    }

    setIsSaving(true);
    try {
      const newCreds: SystemCredentials = {
        ...currentCredentials,
        username: username.trim(),
        password: password.trim(),
        fullName: fullName.trim(),
        age: age.trim(),
        phone: phone.trim()
      };

      // 1. Save to Firestore
      await saveSystemCredentials(newCreds);

      // 2. Notify parent to update local state immediately
      onCredentialsChange(newCreds);

      showToast("✨ تم حفظ وتزامن بيانات الدخول ومعلومات الاسترداد مع السحاب بنجاح!", "success");
    } catch (error) {
      console.error("Error saving credentials:", error);
      showToast("❌ عذراً، فشل مزامنة البيانات السحابية. تم تطبيقها محلياً مؤقتاً.", "danger");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="h-full flex flex-col overflow-hidden text-right"
      dir="rtl"
    >
      <div className="flex-shrink-0 space-y-4 pb-2">
        {/* Title Header */}
        <div className="bg-gradient-to-l from-indigo-900 to-slate-900 rounded-[28px] p-5 text-white shadow-lg space-y-2 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -translate-x-8 -translate-y-8" />
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl translate-x-4 translate-y-4" />
          
          <h2 className="text-xl font-extrabold flex items-center gap-2.5">
            <span>⚙️ إعدادات الحساب والأمان</span>
          </h2>
          <p className="text-xs text-indigo-200/90 leading-relaxed">
            من هنا يمكنك تخصيص بيانات الدخول وتحديث اسم المستخدم ورمز المرور الخاص بالنظام بشكل آمن ومحمي بالكامل في السحاب.
          </p>
        </div>

        {/* Info Notice card */}
        <div className="bg-amber-50 border border-amber-200/60 rounded-2xl p-4 flex gap-3 items-start shadow-sm">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-extrabold text-amber-900">ملاحظة أمان هامة</h4>
            <p className="text-[11px] text-amber-800 leading-relaxed font-semibold">
              عند تغيير كلمة المرور أو اسم المستخدم وحفظها، سيتم إلغاء البيانات القديمة فوراً (بما فيها رمز "ali" و"0" الافتراضي) ولن يكون بالإمكان تسجيل الدخول بها مرة أخرى. تأكد من تذكر البيانات الجديدة جيداً.
            </p>
          </div>
        </div>
      </div>

      {/* Form Credentials Card */}
      <form onSubmit={handleSave} className="flex-1 overflow-y-auto pb-4 px-1 bg-white rounded-3xl p-6 border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.04)] space-y-6 -webkit-overflow-scrolling: touch;">
        
        {/* Username Field */}
        <div className="space-y-2">
          <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
            <User className="w-4 h-4 text-indigo-600" />
            <span>اسم المستخدم الجديد:</span>
          </label>
          <div className="relative">
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="مثال: admin"
              className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
              <User className="w-4 h-4" />
            </div>
          </div>
          <span className="text-[10px] text-slate-400 font-medium block pr-1">
            يُسْتَخْدَم هذا الاسم لتسجيل الدخول إلى لوحة التحكم بدلاً من "ali".
          </span>
        </div>

        {/* Password Field */}
        <div className="space-y-2">
          <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
            <Lock className="w-4 h-4 text-indigo-600" />
            <span>كلمة المرور الجديدة:</span>
          </label>
          <div className="relative">
            <input
              type="text" // Use text or standard viewable input for quick and clear entry of credentials
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="أدخل كلمة المرور الجديدة"
              className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right font-mono"
            />
            <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
              <Key className="w-4 h-4" />
            </div>
          </div>
          <span className="text-[10px] text-slate-400 font-medium block pr-1">
            يجب أن تكون كلمة مرور قوية يسهل عليك تذكرها لتأمين لوحة البيانات.
          </span>
        </div>

        {/* Recovery Information Header divider */}
        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div className="bg-indigo-50/50 border border-indigo-100/40 rounded-2xl p-4 space-y-1">
            <h4 className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
              <span>🔒 معلومات استعادة كلمة المرور (في حال نسيانها)</span>
            </h4>
            <p className="text-[10px] text-indigo-700 font-semibold leading-relaxed">
              قم بملء هذه البيانات الشخصية بدقة. في حال نسيت كلمة المرور مستقبلاً، سيمكنك استردادها فوراً من صفحة تسجيل الدخول عن طريق إدخال ومطابقة هذه التفاصيل الشخصية بنجاح.
            </p>
          </div>

          {/* Full Name Field */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
              <UserCheck className="w-4 h-4 text-indigo-600" />
              <span>الاسم الكامل (للاسترداد):</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="مثال: علي محمد أحمد"
                className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
              />
              <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
                <UserCheck className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Age Field */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
              <Calendar className="w-4 h-4 text-indigo-600" />
              <span>العمر (للاسترداد):</span>
            </label>
            <div className="relative">
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="مثال: 29"
                className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
              />
              <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
                <Calendar className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Phone Field */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
              <Phone className="w-4 h-4 text-indigo-600" />
              <span>رقم الهاتف الخاص بك (للاسترداد):</span>
            </label>
            <div className="relative">
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="مثال: 07701234567"
                className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
              />
              <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
                <Phone className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          type="submit"
          disabled={isSaving}
          className="w-full h-12 bg-[#5F2E9F] hover:bg-[#50248A] disabled:bg-indigo-400 text-white font-extrabold rounded-xl text-sm transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.98] mt-4"
        >
          {isSaving ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>جاري المزامنة والحفظ سحابياً...</span>
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              <span>حفظ التعديلات ومزامنتها</span>
            </>
          )}
        </button>

      </form>
    </motion.div>
  );
}
