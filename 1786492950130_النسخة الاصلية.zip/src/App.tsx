import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  User,
  PlusCircle,
  Search,
  MessageCircle,
  Trash2,
  Camera,
  Check,
  FileText,
  Phone,
  DollarSign,
  TrendingUp,
  Calendar,
  ArrowLeft,
  ArrowRight,
  AlertCircle,
  Clock,
  CheckCircle2,
  Image as ImageIcon,
  UserPlus,
  X,
  Lock,
  LogIn,
  LogOut,
  Bell,
  BellOff,
  Settings,
  Eye,
  EyeOff,
  ChevronLeft,
  CreditCard,
  Sparkles
} from "lucide-react";
import {
  subscribeToCustomers,
  saveCustomer,
  deleteCustomerFromDb,
  Customer,
  Payment,
  CustomerImages,
  Guarantor,
  GuarantorImages,
  subscribeToSystemCredentials,
  saveSystemCredentials,
  SystemCredentials
} from "./firebase";
import { CREDENTIALS } from "./password";
import SettingsScreen from "./components/SettingsScreen";

// --- SAFE NEXT DUE DATE CALCULATION UTILITIES ---

function getSafeDate(year: number, month: number, targetDay: number): Date {
  const lastDayOfTargetMonth = new Date(year, month + 1, 0).getDate();
  const safeDay = Math.min(targetDay, lastDayOfTargetMonth);
  return new Date(year, month, safeDay);
}

function parseCustomerDateAdded(dateAddedStr: string): { year: number; month: number; day: number } {
  const cleanStr = (dateAddedStr || "").replace(/\//g, "-");
  const parts = cleanStr.split("-");
  const year = parseInt(parts[0], 10) || 2026;
  const month = (parseInt(parts[1], 10) || 7) - 1; // 0-indexed month
  const day = parseInt(parts[2], 10) || 6;
  return { year, month, day };
}

function getCustomerNextDueDate(customer: Customer): Date {
  const { year: regYear, month: regMonth } = parseCustomerDateAdded(customer.dateAdded);
  
  // Total paid installments amount:
  const totalPaidInstallmentsAmount = (customer.totalAmount - customer.upfront) - customer.remainingAmount;
  // Number of paid installments:
  const paidCount = Math.floor(totalPaidInstallmentsAmount / customer.monthlyAmount);
  
  // Next due date is (paidCount + 1) months after registration month
  const targetYear = regYear;
  const targetMonth = regMonth + (paidCount + 1);
  const targetDay = customer.dueDay || 1;
  
  return getSafeDate(targetYear, targetMonth, targetDay);
}

function formatNextDueDate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}/${month}/${day}`;
}

function isCustomerDue(customer: Customer): boolean {
  if (customer.status !== "active") return false;
  
  const nextDueDate = getCustomerNextDueDate(customer);
  
  // Get today's date set to midnight
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Set nextDueDate to midnight to compare only dates
  const nextDueMidnight = new Date(nextDueDate);
  nextDueMidnight.setHours(0, 0, 0, 0);
  
  // Due if today is greater than or equal to nextDueMidnight
  return today.getTime() >= nextDueMidnight.getTime();
}

interface CustomerAlertInfo {
  nextDueDate: Date;
  daysRemaining: number;
  status: "approaching" | "due_today" | "overdue" | "not_due";
  statusText: string;
}

function getCustomerAlertInfo(customer: Customer): CustomerAlertInfo {
  const nextDueDate = getCustomerNextDueDate(customer);
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const nextDueMidnight = new Date(nextDueDate);
  nextDueMidnight.setHours(0, 0, 0, 0);
  
  const diffTime = nextDueMidnight.getTime() - today.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
  
  if (customer.status !== "active" || customer.remainingAmount <= 0) {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "not_due",
      statusText: "مكتمل السداد"
    };
  }
  
  if (diffDays < 0) {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "overdue",
      statusText: "متأخر عن السداد"
    };
  } else if (diffDays === 0) {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "due_today",
      statusText: "مستحق اليوم"
    };
  } else if (diffDays === 1 || diffDays === 2 || diffDays === 3) {
    const remainingText = diffDays === 1 ? "يوم واحد" : diffDays === 2 ? "يومان" : "3 أيام";
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "approaching",
      statusText: `يقترب موعد السداد (متبقي ${remainingText})`
    };
  } else {
    return {
      nextDueDate,
      daysRemaining: diffDays,
      status: "not_due",
      statusText: `متبقي ${diffDays} يوم`
    };
  }
}

export default function App() {
  // Track initial layout height & keyboard state to prevent layout jumping when keyboard appears
  const [initialHeight, setInitialHeight] = useState<number>(() => window.innerHeight);
  const [isKeyboardActive, setIsKeyboardActive] = useState(false);

  useEffect(() => {
    // Lock initial height on mount
    setInitialHeight(window.innerHeight);

    // Update initial height if screen orientation/width changes
    let lastWidth = window.innerWidth;
    const handleResize = () => {
      if (window.innerWidth !== lastWidth) {
        setInitialHeight(window.innerHeight);
        lastWidth = window.innerWidth;
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (!window.visualViewport) return;

    const handleVisualViewportResize = () => {
      const vv = window.visualViewport;
      if (!vv) return;
      
      // If the visible height is significantly smaller than the total layout height, the soft keyboard is open.
      const isKeyboard = vv.height < window.innerHeight * 0.85;
      setIsKeyboardActive(isKeyboard);
    };

    window.visualViewport.addEventListener("resize", handleVisualViewportResize);
    // Initial check
    handleVisualViewportResize();

    return () => {
      window.visualViewport?.removeEventListener("resize", handleVisualViewportResize);
    };
  }, []);

  // Smooth scroll to focused inputs when keyboard is active
  useEffect(() => {
    const handleFocus = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT")) {
        setTimeout(() => {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 150);
      }
    };

    document.addEventListener("focusin", handleFocus);
    return () => document.removeEventListener("focusin", handleFocus);
  }, []);

  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem("isLoggedIn") === "true";
  });
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Account Recovery (Forgot Password) States
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [recoveryFullName, setRecoveryFullName] = useState("");
  const [recoveryAge, setRecoveryAge] = useState("");
  const [recoveryPhone, setRecoveryPhone] = useState("");
  const [recoveryError, setRecoveryError] = useState("");
  const [recoveredPassword, setRecoveredPassword] = useState("");
  const [recoveredUsername, setRecoveredUsername] = useState("");

  const [systemCredentials, setSystemCredentials] = useState<SystemCredentials | null>(() => {
    const cached = localStorage.getItem("cached_system_credentials");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error("Error parsing cached credentials:", e);
      }
    }
    return null;
  });

  // Trial States
  const [isTrialExpired, setIsTrialExpired] = useState(() => {
    const isTrialUser = localStorage.getItem("is_trial_user") === "true";
    const trialStartTime = Number(localStorage.getItem("trial_login_start_time") || 0);
    if (isTrialUser && trialStartTime) {
      return Date.now() - trialStartTime > 60 * 60 * 1000; // 1 hour
    }
    return false;
  });
  const [trialTimeRemaining, setTrialTimeRemaining] = useState<string>("");
  const [devPhoneClicks, setDevPhoneClicks] = useState(0);
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);

  // Notification states
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      return Notification.permission;
    }
    return "default";
  });

  // Navigation & State - with persistence to handle browser camera memory-reload suspends
  const [currentScreen, setCurrentScreen] = useState<"add" | "list" | "detail" | "alerts" | "settings">(() => {
    const saved = localStorage.getItem("app_currentScreen");
    if (saved === "home") return "add";
    return (saved as any) || "add";
  });
  const [showBalance, setShowBalance] = useState<boolean>(() => {
    return localStorage.getItem("app_showBalance") !== "false";
  });
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(() => {
    return localStorage.getItem("app_selectedCustomerId") || null;
  });
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const cached = localStorage.getItem("cached_customers");
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error("Error reading cached customers:", e);
      }
    }
    return [];
  });
  
  // Multi-step Form Active Step (1: Owner info, 2: Product details, 3: Installment maths, 4: Docs & Camera)
  const [formStep, setFormStep] = useState<1 | 2 | 3 | 4>(() => {
    return (Number(localStorage.getItem("draft_formStep")) as 1 | 2 | 3 | 4) || 1;
  });

  // Client-side Infinite Scroll / Lazy Loading limit
  const [visibleCount, setVisibleCount] = useState(10);
  
  // Search and Filter State
  const [searchText, setSearchText] = useState("");
  const [currentFilter, setCurrentFilter] = useState<"all" | "due">("all");
  const [alertFilter, setAlertFilter] = useState<"all" | "overdue" | "due_today" | "approaching">("all");

  // Form Fields State - recovered from draft persistence
  const [custName, setCustName] = useState(() => localStorage.getItem("draft_custName") || "");
  const [custPhone, setCustPhone] = useState(() => localStorage.getItem("draft_custPhone") || "");
  const [prodName, setProdName] = useState(() => localStorage.getItem("draft_prodName") || "");
  const [prodSerial, setProdSerial] = useState(() => localStorage.getItem("draft_prodSerial") || "");
  const [custTotalAmount, setCustTotalAmount] = useState(() => localStorage.getItem("draft_custTotalAmount") || "");
  const [custUpfront, setCustUpfront] = useState(() => localStorage.getItem("draft_custUpfront") || "");
  const [custMonthly, setCustMonthly] = useState(() => localStorage.getItem("draft_custMonthly") || "");
  const [custDueDay, setCustDueDay] = useState(() => localStorage.getItem("draft_custDueDay") || new Date().getDate().toString());

  // Guarantor Fields State - recovered from draft persistence
  const [hasGuarantor, setHasGuarantor] = useState<boolean>(() => localStorage.getItem("draft_hasGuarantor") === "true");
  const [guarantorName, setGuarantorName] = useState(() => localStorage.getItem("draft_guarantorName") || "");
  const [guarantorPhone, setGuarantorPhone] = useState(() => localStorage.getItem("draft_guarantorPhone") || "");
  const [guarantorAddress, setGuarantorAddress] = useState(() => localStorage.getItem("draft_guarantorAddress") || "");
  const [guarantorImages, setGuarantorImages] = useState<GuarantorImages>(() => {
    const saved = localStorage.getItem("draft_guarantorImages");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error reading draft guarantor images:", e);
      }
    }
    return {
      personal: "",
      idFront: "",
      idBack: "",
      resFront: "",
      resBack: ""
    };
  });

  const [compressingKeys, setCompressingKeys] = useState<string[]>([]);

  // Registration/Sale & Payment Dates
  const [custDateAdded, setCustDateAdded] = useState<string>(() => {
    const saved = localStorage.getItem("draft_custDateAdded");
    if (saved) return saved;
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });
  const [payDateInput, setPayDateInput] = useState<string>(() => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });

  // Modal / Confirm States
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [showNoDocsConfirm, setShowNoDocsConfirm] = useState(false);
  
  // Image Upload State - recovered from draft persistence
  const [images, setImages] = useState<CustomerImages>(() => {
    const saved = localStorage.getItem("draft_images");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error reading draft images:", e);
      }
    }
    return {
      personal: "",
      resFront: "",
      resBack: "",
      idFront: "",
      idBack: ""
    };
  });

  // Submission Guard State
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Ready-made Message Templates Modal State
  const [templateModalCustomer, setTemplateModalCustomer] = useState<Customer | null>(null);

  // Custom Toast Alert state
  const [toast, setToast] = useState<{ message: string; type: "success" | "danger" | "info" } | null>(null);

  // Payment Recording State
  const [payAmountInput, setPayAmountInput] = useState("");

  // Fullscreen Image Preview Modal State
  const [previewImageSrc, setPreviewImageSrc] = useState<string | null>(null);

  // Sync state values back to localStorage drafts
  useEffect(() => {
    localStorage.setItem("app_currentScreen", currentScreen);
  }, [currentScreen]);

  useEffect(() => {
    if (selectedCustomerId) {
      localStorage.setItem("app_selectedCustomerId", selectedCustomerId);
    } else {
      localStorage.removeItem("app_selectedCustomerId");
    }
  }, [selectedCustomerId]);

  useEffect(() => {
    localStorage.setItem("draft_custName", custName);
  }, [custName]);

  useEffect(() => {
    localStorage.setItem("draft_custPhone", custPhone);
  }, [custPhone]);

  useEffect(() => {
    localStorage.setItem("draft_prodName", prodName);
  }, [prodName]);

  useEffect(() => {
    localStorage.setItem("draft_prodSerial", prodSerial);
  }, [prodSerial]);

  useEffect(() => {
    localStorage.setItem("draft_custTotalAmount", custTotalAmount);
  }, [custTotalAmount]);

  useEffect(() => {
    localStorage.setItem("draft_custUpfront", custUpfront);
  }, [custUpfront]);

  useEffect(() => {
    localStorage.setItem("draft_custMonthly", custMonthly);
  }, [custMonthly]);

  useEffect(() => {
    localStorage.setItem("draft_custDueDay", custDueDay);
  }, [custDueDay]);

  useEffect(() => {
    localStorage.setItem("draft_custDateAdded", custDateAdded);
  }, [custDateAdded]);

  useEffect(() => {
    localStorage.setItem("draft_images", JSON.stringify(images));
  }, [images]);

  useEffect(() => {
    localStorage.setItem("draft_hasGuarantor", String(hasGuarantor));
  }, [hasGuarantor]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorName", guarantorName);
  }, [guarantorName]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorPhone", guarantorPhone);
  }, [guarantorPhone]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorAddress", guarantorAddress);
  }, [guarantorAddress]);

  useEffect(() => {
    localStorage.setItem("draft_guarantorImages", JSON.stringify(guarantorImages));
  }, [guarantorImages]);

  useEffect(() => {
    localStorage.setItem("draft_formStep", formStep.toString());
  }, [formStep]);

  // Client-side Infinite Scroll / Lazy Loading scroll handler
  useEffect(() => {
    if (currentScreen !== "list") return;

    const handleScroll = () => {
      // If we are within 150px of the bottom of the document, load 10 more records
      const threshold = 150;
      const totalHeight = document.documentElement.scrollHeight;
      const currentScrollPosition = window.innerHeight + window.scrollY;

      if (totalHeight - currentScrollPosition <= threshold) {
        setVisibleCount((prev) => prev + 10);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [currentScreen]);

  // Reset infinite scroll limit when screen or filters change to keep memory usage & DOM clean
  useEffect(() => {
    setVisibleCount(10);
  }, [currentScreen, searchText, currentFilter]);

  // Helper function to clear drafts upon successful registration
  const clearFormDrafts = () => {
    localStorage.removeItem("draft_custName");
    localStorage.removeItem("draft_custPhone");
    localStorage.removeItem("draft_prodName");
    localStorage.removeItem("draft_prodSerial");
    localStorage.removeItem("draft_custTotalAmount");
    localStorage.removeItem("draft_custUpfront");
    localStorage.removeItem("draft_custMonthly");
    localStorage.removeItem("draft_custDueDay");
    localStorage.removeItem("draft_custDateAdded");
    localStorage.removeItem("draft_images");
    localStorage.removeItem("draft_hasGuarantor");
    localStorage.removeItem("draft_guarantorName");
    localStorage.removeItem("draft_guarantorPhone");
    localStorage.removeItem("draft_guarantorAddress");
    localStorage.removeItem("draft_guarantorImages");
    localStorage.removeItem("draft_formStep");
    
    setHasGuarantor(false);
    setGuarantorName("");
    setGuarantorPhone("");
    setGuarantorAddress("");
    setGuarantorImages({
      personal: "",
      idFront: "",
      idBack: "",
      resFront: "",
      resBack: ""
    });
    setFormStep(1);
  };

  // Sync with Firebase Firestore and keep local cache updated
  useEffect(() => {
    if (!isLoggedIn) return;

    const unsubscribe = subscribeToCustomers((list) => {
      setCustomers(list);
      localStorage.setItem("cached_customers", JSON.stringify(list));
    });
    return () => unsubscribe();
  }, [isLoggedIn]);

  // Subscribe to real-time system credentials changes
  useEffect(() => {
    const unsubscribe = subscribeToSystemCredentials((creds) => {
      if (creds) {
        setSystemCredentials(creds);
        localStorage.setItem("cached_system_credentials", JSON.stringify(creds));
      } else {
        setSystemCredentials(null);
        localStorage.removeItem("cached_system_credentials");
      }
    });
    return () => unsubscribe();
  }, []);

  // Register Service Worker for background capabilities
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js")
        .then((reg) => {
          console.log("Service Worker registered successfully!", reg);
        })
        .catch((err) => {
          console.error("Service Worker registration failed:", err);
        });
    }
  }, []);

  // دالة لمراقبة حالة التركيز على الحقول (إدخال أو نص) لإخفاء شريط التنقل السفلي عند فتح لوحة المفاتيح
  useEffect(() => {
    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
        setIsKeyboardOpen(true);
        // تمرير الحقل النشط بشكل سلس لمنتصف الشاشة لتفادي نزوله تحت لوحة المفاتيح (الكيبورد)
        setTimeout(() => {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 150);
      }
    };

    const handleFocusOut = (e: FocusEvent) => {
      setTimeout(() => {
        const activeEl = document.activeElement;
        if (!activeEl || (activeEl.tagName !== "INPUT" && activeEl.tagName !== "TEXTAREA")) {
          setIsKeyboardOpen(false);
        }
      }, 100);
    };

    document.addEventListener("focusin", handleFocusIn);
    document.addEventListener("focusout", handleFocusOut);

    // مراقبة حجم العرض المرئي (مفيد جداً على هواتف الأندرويد والآيفون عند فتح الكيبورد)
    const handleViewportResize = () => {
      if (window.visualViewport) {
        const isShrunk = window.visualViewport.height < window.innerHeight * 0.75;
        if (isShrunk) {
          setIsKeyboardOpen(true);
        } else {
          const activeEl = document.activeElement;
          if (!activeEl || (activeEl.tagName !== "INPUT" && activeEl.tagName !== "TEXTAREA")) {
            setIsKeyboardOpen(false);
          }
        }
      }
    };

    if (window.visualViewport) {
      window.visualViewport.addEventListener("resize", handleViewportResize);
    }

    return () => {
      document.removeEventListener("focusin", handleFocusIn);
      document.removeEventListener("focusout", handleFocusOut);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener("resize", handleViewportResize);
      }
    };
  }, []);

  // Instant notification trigger helper
  const triggerInstantCheck = (list: Customer[]) => {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    
    const dueList = list.filter(c => isCustomerDue(c));
    
    if (dueList.length > 0) {
      const names = dueList.map(c => c.name).join("، ");
      const title = "⚠️ تنبيه بالأقساط المستحقة!";
      const body = `لديك ${dueList.length} أقساط مستحقة لكل من: ${names}.`;
      
      if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: "TRIGGER_INSTALLMENT_NOTIFICATION",
          title,
          body
        });
      } else {
        new Notification(title, { body, requireInteraction: true });
      }
    } else {
      const title = "🔔 نظام التنبيهات نشط";
      const body = "لا توجد أقساط مستحقة للدفعة الحالية. سنقوم بتنبيهك تلقائياً فور استحقاق أي قسط!";
      
      if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: "TRIGGER_INSTALLMENT_NOTIFICATION",
          title,
          body
        });
      } else {
        new Notification(title, { body });
      }
    }
  };

  // Check and notify daily on customers reload or log in
  useEffect(() => {
    if (isLoggedIn && customers.length > 0 && notificationPermission === "granted") {
      const today = new Date();
      const todayString = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
      
      // Only notify automatically once per calendar day
      if (localStorage.getItem("lastNotifiedDay") !== todayString) {
        const dueList = customers.filter(c => isCustomerDue(c));
        
        if (dueList.length > 0) {
          const names = dueList.map(c => c.name).join("، ");
          const title = "⚠️ تنبيه بالأقساط المستحقة!";
          const body = `لديك ${dueList.length} أقساط مستحقة لكل من: ${names}. يرجى مراجعة الجدول.`;
          
          if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage({
              type: "TRIGGER_INSTALLMENT_NOTIFICATION",
              title,
              body
            });
          } else {
            new Notification(title, { body, requireInteraction: true });
          }
          localStorage.setItem("lastNotifiedDay", todayString);
        }
      }
    }
  }, [customers, isLoggedIn, notificationPermission]);

  // Request browser permission for notifications
  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      showToast("⚠️ متصفحك لا يدعم الإشعارات البرمجية.", "danger");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      if (permission === "granted") {
        showToast("🔔 تم تفعيل نظام التنبيهات بنجاح!", "success");
        triggerInstantCheck(customers);
      } else if (permission === "denied") {
        showToast("❌ تم رفض استقبال الإشعارات. يرجى تعديل الإعدادات من شريط العنوان.", "danger");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Auto-set the installment day from the registration/sale date day
  useEffect(() => {
    if (custDateAdded) {
      const parts = custDateAdded.split("-");
      if (parts.length === 3) {
        const dayNum = parseInt(parts[2], 10);
        if (!isNaN(dayNum) && dayNum >= 1 && dayNum <= 31) {
          setCustDueDay(dayNum.toString());
        }
      }
    }
  }, [custDateAdded]);

  // Handle Account Recovery Submit
  const handleRecoverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError("");
    setRecoveredPassword("");
    setRecoveredUsername("");

    const storedFullName = systemCredentials?.fullName?.trim().toLowerCase() || "";
    const storedAge = systemCredentials?.age?.trim() || "";
    const storedPhone = systemCredentials?.phone?.trim() || "";

    if (!storedFullName && !storedAge && !storedPhone) {
      setRecoveryError("⚠️ لم يتم تعيين معلومات استعادة الحساب في الإعدادات مسبقاً! يرجى التواصل مع المطور لمساعدتك.");
      return;
    }

    const inputFullName = recoveryFullName.trim().toLowerCase();
    const inputAge = recoveryAge.trim();
    const inputPhone = recoveryPhone.trim();

    if (inputFullName === storedFullName && inputAge === storedAge && inputPhone === storedPhone) {
      const activeUsername = systemCredentials?.username ?? CREDENTIALS.username;
      const activePassword = systemCredentials?.password ?? CREDENTIALS.password;
      setRecoveredUsername(activeUsername);
      setRecoveredPassword(activePassword);
      showToast("🔑 تم التحقق من هويتك بنجاح ومطابقة البيانات السحابية!", "success");
    } else {
      setRecoveryError("❌ عذراً، المعلومات التي أدخلتها غير متطابقة مع البيانات المسجلة سحابياً!");
    }
  };

  // Handle Login submission
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Determine current active credentials (either custom synced or default fallback)
    const activeUsername = systemCredentials?.username ?? CREDENTIALS.username;
    const activePassword = systemCredentials?.password ?? CREDENTIALS.password;

    if (loginUsername === activeUsername && loginPassword === activePassword) {
      localStorage.removeItem("is_trial_user");
      localStorage.removeItem("trial_login_start_time");
      setIsTrialExpired(false);
      setIsLoggedIn(true);
      localStorage.setItem("isLoggedIn", "true");
      setLoginError("");
      setLoginUsername("");
      setLoginPassword("");
      showToast("🔐 تم تسجيل الدخول بنجاح!", "success");
    } else {
      setLoginError("❌ عذراً، اسم المستخدم أو كلمة المرور غير صحيحة!");
      setLoginPassword("");
    }
  };

  // وظيفة لتخطي انتهاء الفترة التجريبية عند الضغط 3 مرات متتالية على رقم هاتف المطور للرجوع للوحة الدخول
  const handleDevPhoneClick = () => {
    setDevPhoneClicks((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        setIsTrialExpired(false);
        setIsLoggedIn(false);
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("is_trial_user");
        localStorage.removeItem("trial_login_start_time");
        showToast("🔓 تم إظهار لوحة تسجيل الدخول بنجاح!", "success");
        return 0;
      }
      return next;
    });
  };

  // Handle Trial Login
  const handleTrialLogin = () => {
    const trialStartTime = Number(localStorage.getItem("trial_login_start_time") || 0);
    const isTrialUser = localStorage.getItem("is_trial_user") === "true";
    if (isTrialUser && trialStartTime && (Date.now() - trialStartTime > 60 * 60 * 1000)) {
      setIsTrialExpired(true);
      showToast("⚠️ لقد انتهت فترة التجربة الخاصة بك بالفعل!", "danger");
      return;
    }

    const now = Date.now();
    localStorage.setItem("is_trial_user", "true");
    if (!localStorage.getItem("trial_login_start_time")) {
      localStorage.setItem("trial_login_start_time", String(now));
    }
    localStorage.setItem("isLoggedIn", "true");
    setIsLoggedIn(true);
    setIsTrialExpired(false);
    showToast("⏱️ تم تفعيل الدخول التجريبي لمدة ساعة كاملة!", "info");
  };

  // Dynamic Trial Countdown Timer
  useEffect(() => {
    const isTrialUser = localStorage.getItem("is_trial_user") === "true";
    const trialStartTime = Number(localStorage.getItem("trial_login_start_time") || 0);

    if (isTrialUser && trialStartTime) {
      const updateTimer = () => {
        const elapsed = Date.now() - trialStartTime;
        const totalDuration = 60 * 60 * 1000; // 1 hour
        const remaining = totalDuration - elapsed;

        if (remaining <= 0) {
          setIsTrialExpired(true);
          setTrialTimeRemaining("00:00");
        } else {
          const minutes = Math.floor(remaining / 60000);
          const seconds = Math.floor((remaining % 60000) / 1000);
          const formatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
          setTrialTimeRemaining(formatted);
        }
      };

      updateTimer();
      const interval = setInterval(updateTimer, 1000);
      return () => clearInterval(interval);
    }
  }, [isLoggedIn]);

  // Show Toast helper
  const showToast = (message: string, type: "success" | "danger" | "info") => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 5000);
  };

  // دالة لمزامنة العمليات التي تمت بدون إنترنت تلقائياً عند عودة الاتصال
  const syncOfflineQueue = async () => {
    if (!navigator.onLine) return;

    const queueStr = localStorage.getItem("offline_sync_queue");
    if (!queueStr) return;

    try {
      const queue: Array<{ id: string; type: 'save' | 'delete'; customer?: Customer; customerId?: string }> = JSON.parse(queueStr);
      if (queue.length === 0) return;

      console.log("🔄 جاري مزامنة العمليات المحفوظة محلياً مع السحاب... العدد:", queue.length);
      
      const failedItems: typeof queue = [];

      for (const op of queue) {
        try {
          if (op.type === 'save' && op.customer) {
            await saveCustomer(op.customer);
          } else if (op.type === 'delete' && op.customerId) {
            await deleteCustomerFromDb(op.customerId);
          }
        } catch (err) {
          console.error("❌ فشل مزامنة العملية:", op, err);
          failedItems.push(op); // نحتفظ بها لإعادة المحاولة لاحقاً
        }
      }

      if (failedItems.length < queue.length) {
        localStorage.setItem("offline_sync_queue", JSON.stringify(failedItems));
        
        if (failedItems.length === 0) {
          showToast("🔄 تمت مزامنة جميع البيانات المحفوظة محلياً مع السحاب بنجاح!", "success");
        } else {
          showToast(`🔄 تم مزامنة بعض البيانات المعلقة، ومتبقي ${failedItems.length} عمليات.`, "info");
        }
      }
    } catch (e) {
      console.error("Error processing offline sync queue:", e);
    }
  };

  // تشغيل المزامنة التلقائية عند عودة الاتصال بالإنترنت أو بصفة دورية
  useEffect(() => {
    if (isLoggedIn) {
      syncOfflineQueue();

      window.addEventListener("online", syncOfflineQueue);
      const interval = setInterval(syncOfflineQueue, 10000);

      return () => {
        window.removeEventListener("online", syncOfflineQueue);
        clearInterval(interval);
      };
    }
  }, [isLoggedIn]);

  // Utility to clean numbers from commas
  const cleanNumber = (val: string | number): number => {
    if (!val) return 0;
    return parseFloat(val.toString().replace(/,/g, "")) || 0;
  };

  // Utility to format numbers with thousands commas
  const formatNumber = (num: number): string => {
    if (num === undefined || num === null || isNaN(num)) return "0";
    return num.toLocaleString("en-US");
  };

  // Helper to format input value with commas on change
  const handleMoneyInputChange = (
    val: string,
    setter: React.Dispatch<React.SetStateAction<string>>
  ) => {
    const clean = val.replace(/,/g, "");
    if (!isNaN(parseFloat(clean)) && clean !== "") {
      setter(parseFloat(clean).toLocaleString("en-US"));
    } else if (clean === "") {
      setter("");
    }
  };

  // Calculate remaining amount on-the-fly
  const totalVal = cleanNumber(custTotalAmount);
  const upfrontVal = cleanNumber(custUpfront);
  const remainingVal = Math.max(0, totalVal - upfrontVal);

  // Smart Alert Check - using the robust Next Due Date logic
  const dueCustomers = customers.filter((c) => isCustomerDue(c));

  // Detailed alerts calculation
  const customerAlerts = customers
    .filter((c) => c.status === "active")
    .map((c) => {
      const alertInfo = getCustomerAlertInfo(c);
      return {
        customer: c,
        ...alertInfo
      };
    })
    .filter((info) => info.status === "overdue" || info.status === "due_today" || info.status === "approaching");

  // Number of alerts (overdue, due_today, or approaching)
  const alertCount = customerAlerts.length;

  // Global Stat: Total Debt
  const totalDebt = customers.reduce((sum, c) => sum + c.remainingAmount, 0);

// Helper to compress base64 image using canvas to prevent Firebase "Write too large" errors and save storage space
const compressImage = (base64Str: string, maxWidth = 550, maxHeight = 550, quality = 0.15): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(img, 0, 0, width, height);
        const compressed = canvas.toDataURL("image/jpeg", quality);
        resolve(compressed);
      } else {
        resolve(base64Str);
      }
    };
    img.onerror = () => {
      resolve(base64Str);
    };
  });
};

  // Process selected file to base64 DataURL
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, key: keyof CustomerImages) => {
    const file = e.target.files?.[0];
    if (file) {
      const storageKey = 'customer_' + key;
      setCompressingKeys((prev) => [...prev, storageKey]);
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const originalBase64 = event.target.result as string;
          try {
            const compressedBase64 = await compressImage(originalBase64);
            setImages((prev) => ({
              ...prev,
              [key]: compressedBase64
            }));
          } catch (err) {
            console.error("Compression error:", err);
            setImages((prev) => ({
              ...prev,
              [key]: originalBase64
            }));
          } finally {
            setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
          }
        } else {
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        }
      };
      reader.onerror = () => {
        setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
      };
      reader.readAsDataURL(file);
    }
  };

  // Process selected guarantor file to base64 DataURL
  const handleGuarantorFileChange = (e: React.ChangeEvent<HTMLInputElement>, key: keyof GuarantorImages) => {
    const file = e.target.files?.[0];
    if (file) {
      const storageKey = 'guarantor_' + key;
      setCompressingKeys((prev) => [...prev, storageKey]);
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          const originalBase64 = event.target.result as string;
          try {
            const compressedBase64 = await compressImage(originalBase64);
            setGuarantorImages((prev) => ({
              ...prev,
              [key]: compressedBase64
            }));
          } catch (err) {
            console.error("Guarantor Compression error:", err);
            setGuarantorImages((prev) => ({
              ...prev,
              [key]: originalBase64
            }));
          } finally {
            setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
          }
        } else {
          setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
        }
      };
      reader.onerror = () => {
        setCompressingKeys((prev) => prev.filter((k) => k !== storageKey));
      };
      reader.readAsDataURL(file);
    }
  };

  // Direct WhatsApp Launch Function with prepared text
  const launchWhatsAppWithMessage = (phoneNumber: string, messageText: string) => {
    if (!phoneNumber) return;
    let cleanPhone = phoneNumber.toString().replace(/\s+/g, "");

    if (cleanPhone.startsWith("07")) {
      cleanPhone = "964" + cleanPhone.substring(1);
    } else if (cleanPhone.startsWith("7")) {
      cleanPhone = "964" + cleanPhone;
    } else if (cleanPhone.startsWith("+964")) {
      cleanPhone = cleanPhone.replace("+", "");
    }

    const encodedMsg = encodeURIComponent(messageText);
    window.open(`https://wa.me/${cleanPhone}?text=${encodedMsg}`, "_blank");
    setTemplateModalCustomer(null);
  };

  // Step Validation Helpers
  const validateGuarantor = () => {
    if (hasGuarantor) {
      if (!guarantorName.trim()) {
        showToast("⚠️ يرجى كتابة الاسم الثلاثي الكامل للكفيل!", "danger");
        return false;
      }
      if (!guarantorPhone.trim()) {
        showToast("⚠️ يرجى كتابة رقم هاتف الكفيل النشط!", "danger");
        return false;
      }
      if (!guarantorAddress.trim()) {
        showToast("⚠️ يرجى كتابة عنوان سكن الكفيل الحالي!", "danger");
        return false;
      }
    }
    return true;
  };

  const validateCustomer = () => {
    if (!custName.trim()) {
      showToast("⚠️ يرجى كتابة الاسم الثلاثي الكامل للعميل!", "danger");
      return false;
    }
    if (!custPhone.trim()) {
      showToast("⚠️ يرجى كتابة رقم الهاتف للعميل!", "danger");
      return false;
    }
    if (!custDateAdded.trim()) {
      showToast("⚠️ يرجى اختيار تاريخ تسجيل البيع والمعاملة!", "danger");
      return false;
    }
    return true;
  };

  const validateStep1 = () => {
    return validateGuarantor() && validateCustomer();
  };

  const validateStep2 = () => {
    if (!prodName.trim()) {
      showToast("⚠️ يرجى كتابة اسم السلعة المباعة!", "danger");
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (!custTotalAmount) {
      showToast("⚠️ يرجى تحديد السعر الكلي للسلعة!", "danger");
      return false;
    }
    if (!custMonthly) {
      showToast("⚠️ يرجى تحديد قيمة القسط الشهري!", "danger");
      return false;
    }
    if (!custDueDay) {
      showToast("⚠️ يرجى تحديد يوم السداد الشهري المحدد!", "danger");
      return false;
    }
    return true;
  };

  // Handle Form Submission
  const handleAddNewCustomer = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isSubmitting) return;

    // Final safety validations for all steps
    if (!validateStep1()) {
      setFormStep(1);
      return;
    }
    if (!validateStep2()) {
      setFormStep(2);
      return;
    }
    if (!validateStep3()) {
      setFormStep(3);
      return;
    }

    // Guard: Prevent duplicate customer with same name & phone number
    const alreadyExists = customers.some(
      (c) => c.name.trim() === custName.trim() && c.phone.trim() === custPhone.trim()
    );
    if (alreadyExists) {
      showToast("⚠️ هذا الزبون مسجل مسبقاً بنفس الاسم ورقم الهاتف لضمان عدم التكرار!", "danger");
      return;
    }

    // Check if main documents are missing (resFront, resBack, idFront, idBack)
    const hasMissingDocs = !images.resFront || !images.resBack || !images.idFront || !images.idBack;

    if (hasMissingDocs) {
      setShowNoDocsConfirm(true);
      return;
    }

    await executeSaveCustomer();
  };

  // Save customer helper supporting Offline Caching & Sync
  const persistCustomer = async (cust: Customer) => {
    // 1. Optimistic Update locally
    setCustomers((prev) => {
      const index = prev.findIndex((c) => c.id === cust.id);
      let updatedList = [...prev];
      if (index > -1) {
        updatedList[index] = cust;
      } else {
        updatedList.push(cust);
      }
      localStorage.setItem("cached_customers", JSON.stringify(updatedList));
      return updatedList;
    });

    // 2. Cloud Update
    if (navigator.onLine) {
      try {
        await saveCustomer(cust);
        return;
      } catch (err) {
        console.error("Firebase write failed, queuing for offline sync:", err);
      }
    }

    // 3. Offline queuing
    const queueStr = localStorage.getItem("offline_sync_queue") || "[]";
    let queue = [];
    try {
      queue = JSON.parse(queueStr);
    } catch (e) {
      queue = [];
    }

    queue = queue.filter((op: any) => !(op.type === "save" && op.customer?.id === cust.id));
    queue.push({
      id: Date.now().toString() + Math.random().toString(36).substring(2, 5),
      type: "save",
      customer: cust,
      timestamp: Date.now()
    });
    localStorage.setItem("offline_sync_queue", JSON.stringify(queue));
    showToast("⚠️ تم حفظ البيانات مؤقتاً في الهاتف لعدم وجود إنترنت، وسيتم رفعها للسحاب تلقائياً فور الاتصال!", "info");
  };

  // Delete customer helper supporting Offline Caching & Sync
  const persistDeleteCustomer = async (id: string) => {
    // 1. Optimistic Update locally
    setCustomers((prev) => {
      const filtered = prev.filter((c) => c.id !== id);
      localStorage.setItem("cached_customers", JSON.stringify(filtered));
      return filtered;
    });

    // 2. Cloud Delete
    if (navigator.onLine) {
      try {
        await deleteCustomerFromDb(id);
        return;
      } catch (err) {
        console.error("Firebase delete failed, queuing for offline sync:", err);
      }
    }

    // 3. Offline queuing
    const queueStr = localStorage.getItem("offline_sync_queue") || "[]";
    let queue = [];
    try {
      queue = JSON.parse(queueStr);
    } catch (e) {
      queue = [];
    }

    queue = queue.filter((op: any) => !(op.customer?.id === id));
    queue.push({
      id: Date.now().toString() + Math.random().toString(36).substring(2, 5),
      type: "delete",
      customerId: id,
      timestamp: Date.now()
    });
    localStorage.setItem("offline_sync_queue", JSON.stringify(queue));
    showToast("⚠️ تم حذف الزبون محلياً، وسيتم المزامنة السحابية فور عودة الإنترنت!", "info");
  };

  const executeSaveCustomer = async () => {
    setIsSubmitting(true);

    const newCustomer: Customer = {
      id: Date.now().toString(),
      name: custName.trim(),
      phone: custPhone.trim(),
      productName: prodName.trim(),
      productSerial: prodSerial.trim() || "غير مسجل",
      totalAmount: totalVal,
      upfront: upfrontVal,
      monthlyAmount: cleanNumber(custMonthly),
      remainingAmount: remainingVal,
      dueDay: parseInt(custDueDay) || 1,
      images: { ...images },
      payments: [],
      status: remainingVal <= 0 ? "done" : "active",
      dateAdded: custDateAdded.replace(/-/g, "/"),
      hasGuarantor: hasGuarantor,
      guarantor: hasGuarantor ? {
        name: guarantorName.trim(),
        phone: guarantorPhone.trim(),
        address: guarantorAddress.trim(),
        images: guarantorImages
      } : undefined
    };

    try {
      await persistCustomer(newCustomer);
      
      // Reset Form State
      setCustName("");
      setCustPhone("");
      setProdName("");
      setProdSerial("");
      setCustTotalAmount("");
      setCustUpfront("");
      setCustMonthly("");
      setCustDueDay(new Date().getDate().toString());
      setCustDateAdded(() => {
        const d = new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      });
      setImages({
        personal: "",
        resFront: "",
        resBack: "",
        idFront: "",
        idBack: ""
      });

      clearFormDrafts();

      const isTrial = localStorage.getItem("is_trial_user") === "true";
      showToast(`✅ تمت إضافة الزبون (${newCustomer.name}) ${isTrial ? "وحفظ بياناته محلياً في متصفحك" : "وحفظ بياناته سحابياً"} بنجاح!`, "success");
      
      // Switch to list
      setCurrentScreen("list");
      setShowNoDocsConfirm(false);
    } catch (error) {
      console.error(error);
      showToast("❌ فشل الاتصال بقاعدة البيانات. يرجى التحقق من الإنترنت والاتصال.", "danger");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Payment
  const handlePaymentSubmit = async (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId);
    if (!customer) return;

    const amount = cleanNumber(payAmountInput);
    if (amount <= 0) {
      showToast("⚠️ يرجى كتابة مبلغ سداد صحيح!", "danger");
      return;
    }
    if (amount > customer.remainingAmount) {
      showToast("⚠️ المبلغ المكتوب أكبر من المتبقي المطلوب ذمته!", "danger");
      return;
    }

    const updatedRemaining = customer.remainingAmount - amount;
    const paymentDateFormatted = payDateInput ? payDateInput.replace(/-/g, "/") : new Date().toLocaleDateString("ar-EG");

    const newPaymentRecord: Payment = {
      date: paymentDateFormatted,
      amount: amount
    };

    const updatedCustomer: Customer = {
      ...customer,
      remainingAmount: updatedRemaining,
      status: updatedRemaining <= 0 ? "done" : "active",
      payments: [...(customer.payments || []), newPaymentRecord]
    };

    try {
      await persistCustomer(updatedCustomer);
      showToast(`✅ تم تسجيل السداد بنجاح وخصم مبلغ ${formatNumber(amount)} د.ع لزبونك.`, "success");
      setPayAmountInput("");
    } catch (error) {
      console.error(error);
      showToast("❌ فشل تحديث السداد في قاعدة البيانات.", "danger");
    }
  };

  // Delete Customer Record
  const handleDeleteCustomer = async (id: string) => {
    const customer = customers.find((c) => c.id === id);
    const customerName = customer ? customer.name : "الزبون";

    try {
      await persistDeleteCustomer(id);
      showToast(`✅ تم حذف ملف الزبون (${customerName}) بالكامل بنجاح!`, "success");
      setCurrentScreen("list");
      setSelectedCustomerId(null);
      setDeleteConfirmId(null);
    } catch (error) {
      console.error(error);
      showToast("❌ فشل حذف الملف.", "danger");
    }
  };

  // Switch to details
  const viewCustomerDetails = (id: string) => {
    const customer = customers.find((c) => c.id === id);
    if (customer) {
      setSelectedCustomerId(id);
      setPayAmountInput(formatNumber(customer.monthlyAmount));
      
      const d = new Date();
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      setPayDateInput(`${year}-${month}-${day}`);
      
      setCurrentScreen("detail");
    }
  };

  // Filtered customers list
  const filteredCustomers = customers.filter((c) => {
    const term = searchText.toLowerCase();
    const matchesSearch =
      c.name.toLowerCase().includes(term) ||
      c.phone.includes(term) ||
      c.productName.toLowerCase().includes(term);

    if (currentFilter === "due") {
      return matchesSearch && isCustomerDue(c);
    }
    return matchesSearch;
  });

  return (
    <div 
      className="w-screen bg-slate-50 md:bg-slate-100 text-slate-800 flex justify-center items-center selection:bg-indigo-100 select-none overflow-hidden relative" 
      dir="rtl"
      style={{ height: initialHeight ? `${initialHeight}px` : '100dvh' }}
    >
      
      {/* Toast Notification Alert Overlay */}
      {toast && (
        <div className="absolute top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4">
          <div className={`p-4 rounded-2xl shadow-xl border text-xs font-extrabold flex items-center gap-2.5 animate-pulse ${
            toast.type === "success" 
              ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
              : toast.type === "danger"
              ? "bg-rose-50 border-rose-200 text-rose-800"
              : "bg-indigo-50 border-indigo-200 text-indigo-800"
          }`}>
            <AlertCircle className="w-5 h-5 text-indigo-900 flex-shrink-0" />
            <span className="leading-relaxed">{toast.message}</span>
          </div>
        </div>
      )}

      {isTrialExpired ? (
        <div className="w-full max-w-md bg-white rounded-3xl border border-rose-200 shadow-2xl p-8 space-y-6 mx-4 text-center relative z-50 overflow-y-auto max-h-[90%]">
          <div className="inline-flex p-4 bg-rose-50 text-rose-600 rounded-2xl animate-bounce">
            <Lock className="w-12 h-12" />
          </div>
          
          <h2 className="text-2xl font-black text-rose-950">انتهت فترة العرض التجريبي!</h2>
          
          <div className="space-y-3 text-slate-600 font-semibold text-sm leading-relaxed" dir="rtl">
            <p className="text-slate-700 font-bold text-center">
              لقد انتهت مدة الساعة الكاملة للدخول التجريبي بنجاح.
            </p>
            <p className="p-3.5 bg-rose-50 border border-rose-100 text-rose-800 rounded-2xl text-xs font-bold leading-relaxed text-center">
              للشراء النسخة الكاملة يرجى تواصل مع المطور عبر الواتساب.
            </p>
          </div>

          <div 
            onClick={handleDevPhoneClick}
            className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1 cursor-pointer hover:bg-slate-100 active:scale-95 transition-all select-none"
            title="انقر 3 مرات لإظهار لوحة تسجيل الدخول"
          >
            <span className="text-xs text-slate-400 font-bold">رقم تواصل المطور:</span>
            <span className="block text-lg font-black text-indigo-950 tracking-wider">07810936407</span>
          </div>

          <a
            href="https://wa.me/9647810936407?text=%D9%85%D8%B1%D8%AD%D8%A8%D8%A7%D9%8B%20%D8%A3%D8%AE%D9%8I%D8%9B%20%D9%84%D9%82%D8%AF%20%D8%AC%D8%B1%D8%A8%D8%AA%20%D8%A7%D9%84%D9%86%D8%B8%D8%A7%D9%85%20%D8%A7%D9%84%D8%AA%D8%AC%D8%B1%D9%8A%D8%A8%D9%8I%20%D9%88%D8%A3%D8%B1%D8%BA%D8%A8%20%D8%A8%D8%B4%D8%B1%D8%A7%D8%A1%20%D8%A7%D9%84%D9%86%D8%B8%D8%A7%D9%85%20%D8%A7%D9%84%D8%A3%D9%82%D8%B3%D8%A7%D8%B7."
            target="_blank"
            rel="noopener noreferrer"
            className="w-full h-12 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-600/20 active:scale-[0.98] outline-none"
          >
            <MessageCircle className="w-5 h-5 text-white fill-current" />
            <span>تواصل مع المطور عبر الواتساب</span>
          </a>
        </div>
      ) : !isLoggedIn ? (
        <div className="w-full max-w-md bg-white rounded-3xl border border-slate-200 shadow-2xl p-8 space-y-6 mx-4 text-right relative z-50 overflow-y-auto max-h-[90%]">
          <div className="text-center space-y-2">
            <div className="inline-flex p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
              <Lock className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-extrabold text-slate-950">نظام أقساط المطور</h2>
            <p className="text-xs text-slate-500 font-bold">يرجى تسجيل الدخول لمتابعة حسابات الزبائن</p>
          </div>

          {loginError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-2xl flex items-center gap-2 animate-pulse">
              <AlertCircle className="w-5 h-5 text-rose-500 flex-shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-600">اسم المستخدم</label>
              <input
                type="text"
                required
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                placeholder="اسم المستخدم"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
              />
            </div>

            <div className="space-y-1.5 font-sans">
              <label className="text-xs font-bold text-slate-600">كلمة المرور</label>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="••••"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
              />
            </div>

            <div className="flex justify-start items-center pt-1">
              <button
                type="button"
                onClick={() => {
                  setRecoveryError("");
                  setRecoveredPassword("");
                  setRecoveredUsername("");
                  setRecoveryFullName("");
                  setRecoveryAge("");
                  setRecoveryPhone("");
                  setShowRecoveryModal(true);
                }}
                className="text-xs font-bold text-[#5F2E9F] hover:underline cursor-pointer transition-all active:scale-95"
              >
                هل نسيت كلمة السر؟
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-[#5F2E9F] hover:bg-[#50248A] text-white font-extrabold rounded-xl text-sm transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/20 active:scale-[0.98]"
            >
              <LogIn className="w-5 h-5" />
              <span>دخول للنظام</span>
            </button>
          </form>

          {/* Recovery Modal */}
          <AnimatePresence>
            {showRecoveryModal && (
              <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 10 }}
                  className="bg-white rounded-[32px] w-full max-w-md p-6 text-right space-y-5 shadow-2xl border border-slate-100 relative"
                  dir="rtl"
                >
                  <div className="text-center space-y-2 pb-2 border-b border-slate-100">
                    <div className="inline-flex p-3 bg-indigo-50 text-[#5F2E9F] rounded-2xl">
                      <Lock className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-black text-slate-800">استرداد كلمة مرور النظام سحابياً</h3>
                    <p className="text-[11px] text-slate-400 font-bold">يرجى إدخال معلومات الهوية المسجلة للاستعادة</p>
                  </div>

                  {recoveryError && (
                    <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-2xl flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-rose-500 flex-shrink-0" />
                      <span>{recoveryError}</span>
                    </div>
                  )}

                  {recoveredPassword ? (
                    <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 space-y-4 text-right">
                      <div className="text-emerald-800 font-black text-xs text-center">✅ تم التحقق من هويتك واسترجاع الحساب بنجاح!</div>
                      
                      <div className="space-y-3">
                        <div className="space-y-1">
                          <span className="text-[10px] text-slate-500 font-bold block">اسم المستخدم المسترجع:</span>
                          <div className="bg-white border border-slate-100 rounded-xl py-2.5 px-4 font-semibold text-sm text-slate-700 text-center tracking-wide">
                            {recoveredUsername || systemCredentials?.username || CREDENTIALS.username}
                          </div>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[10px] text-slate-500 font-bold block">كلمة المرور المسترجعة:</span>
                          <div className="bg-white border border-slate-100 rounded-xl py-2.5 px-4 font-mono text-base font-black text-emerald-600 text-center tracking-wider">
                            {recoveredPassword}
                          </div>
                        </div>
                      </div>

                      <p className="text-[10px] text-emerald-700 text-center font-semibold leading-relaxed">
                        انقر على الزر أدناه لتعبئة اسم المستخدم وكلمة المرور تلقائياً وتسجيل الدخول.
                      </p>
                      
                      <button
                        type="button"
                        onClick={() => {
                          setLoginPassword(recoveredPassword);
                          setLoginUsername(recoveredUsername || systemCredentials?.username || CREDENTIALS.username);
                          setShowRecoveryModal(false);
                        }}
                        className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl transition-all cursor-pointer shadow-md shadow-emerald-700/10"
                      >
                        تعبئة الدخول التلقائي والمتابعة
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleRecoverySubmit} className="space-y-4">
                      {/* Name input */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 flex items-center gap-1.5 pr-1">
                          <User className="w-4 h-4 text-indigo-500" />
                          <span>الاسم الكامل:</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={recoveryFullName}
                          onChange={(e) => setRecoveryFullName(e.target.value)}
                          placeholder="مثال: علي محمد أحمد"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
                        />
                      </div>

                      {/* Age input */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 flex items-center gap-1.5 pr-1">
                          <Calendar className="w-4 h-4 text-indigo-500" />
                          <span>العمر:</span>
                        </label>
                        <input
                          type="number"
                          required
                          value={recoveryAge}
                          onChange={(e) => setRecoveryAge(e.target.value)}
                          placeholder="مثال: 29"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
                        />
                      </div>

                      {/* Phone input */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 flex items-center gap-1.5 pr-1">
                          <Phone className="w-4 h-4 text-indigo-500" />
                          <span>رقم الهاتف الخاص بك:</span>
                        </label>
                        <input
                          type="tel"
                          required
                          value={recoveryPhone}
                          onChange={(e) => setRecoveryPhone(e.target.value)}
                          placeholder="مثال: 07701234567"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold text-slate-800 text-right"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full mt-2 py-3.5 bg-[#5F2E9F] hover:bg-[#50248A] text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow"
                      >
                        مطابقة البيانات واسترداد كلمة السر
                      </button>
                    </form>
                  )}

                  <button
                    type="button"
                    onClick={() => setShowRecoveryModal(false)}
                    className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition-all cursor-pointer"
                  >
                    إغلاق نافذة الاسترداد
                  </button>
                </motion.div>
              </div>
            )}
          </AnimatePresence>
        </div>
      ) : (
        /* Main Container */
        <div className="w-full max-w-lg bg-[#FAF9FC] h-full max-h-full md:h-[94vh] md:max-h-[880px] md:my-auto flex flex-col md:rounded-[36px] md:shadow-[0_24px_50px_-12px_rgba(0,0,0,0.15)] md:border md:border-slate-200/80 overflow-hidden relative">
          
          {/* Header */}
          <header className="bg-white/90 backdrop-blur-md px-5 py-4 sticky top-0 z-40 flex justify-between items-center border-b border-slate-100/80">
            {/* Right side: Abstract spiral logo and Title */}
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-[#5F2E9F] font-bold shadow-sm">
                {/* SVG Logo matching the spiral loop in screenshot */}
                <svg className="w-5.5 h-5.5 text-[#5F2E9F]" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 9.25 20.88 6.76 19.07 4.93C18.68 4.54 18.05 4.54 17.66 4.93C17.27 5.32 17.27 5.95 17.66 6.34C19.11 7.8 20 9.8 20 12C20 16.42 16.42 20 12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C14.2 4 16.2 4.89 17.66 6.34C18.05 6.73 18.68 6.73 19.07 6.34C19.46 5.95 19.46 5.32 19.07 6.34C17.24 3.1 14.75 2 12 2Z" fill="currentColor"/>
                  <path d="M12 6C8.69 6 6 8.69 6 12C6 15.31 8.69 18 12 18C15.31 18 18 15.31 18 12C18 10.34 17.33 8.84 16.24 7.76C15.85 7.37 15.22 7.37 14.83 7.76C14.44 8.15 14.44 8.78 14.83 9.17C15.56 9.9 16 10.9 16 12C16 14.21 14.21 16 12 16C9.79 16 8 14.21 8 12C8 9.79 9.79 8 12 8C12.55 8 13 7.55 13 7C13 6.45 12.55 6 12 6Z" fill="currentColor"/>
                </svg>
              </div>
              <div className="flex flex-col text-right">
                <span className="text-sm font-extrabold text-[#1E152E]">
                  {currentScreen === "home" && "الرئيسية"}
                  {currentScreen === "add" && "إضافة قسط"}
                  {currentScreen === "list" && "قائمة العملاء"}
                  {currentScreen === "detail" && "تفاصيل القسط"}
                  {currentScreen === "alerts" && "تنبيهات الاستحقاقات"}
                  {currentScreen === "settings" && "إعدادات الأمان"}
                </span>
                <span className="text-[10px] text-slate-400 font-bold">الأقساط الذكية</span>
              </div>
            </div>

            {/* Left side: History, Notifications, Logout */}
            <div className="flex items-center gap-1.5">
              {/* History Button */}
              <button
                type="button"
                onClick={() => {
                  setCurrentScreen("list");
                  setSelectedCustomerId(null);
                }}
                title="سجل المعاملات والعملاء"
                className="w-8.5 h-8.5 rounded-full bg-slate-50 hover:bg-slate-100 border border-slate-100 flex items-center justify-center text-slate-600 transition-all cursor-pointer shadow-sm"
              >
                <Clock className="w-4.5 h-4.5" />
              </button>

              {/* Notification Button */}
              <button
                type="button"
                onClick={
                  notificationPermission === "granted"
                    ? () => triggerInstantCheck(customers)
                    : notificationPermission === "denied"
                    ? () => showToast("⚠️ الإشعارات محظورة بالمتصفح! يرجى تفعيلها من إعدادات الموقع بجانب شريط العنوان.", "danger")
                    : requestNotificationPermission
                }
                title={
                  notificationPermission === "granted"
                    ? "تنبيهات الأقساط نشطة (اضغط للاختبار)"
                    : notificationPermission === "denied"
                    ? "التنبيهات محظورة"
                    : "تفعيل تنبيهات الأقساط"
                }
                className={`w-8.5 h-8.5 rounded-full flex items-center justify-center border transition-all cursor-pointer relative shadow-sm ${
                  notificationPermission === "granted"
                    ? "bg-slate-50 hover:bg-slate-100 border-slate-100 text-slate-600"
                    : "bg-amber-50 hover:bg-amber-100 border-amber-100 text-amber-600 animate-pulse"
                }`}
              >
                <Bell className="w-4.5 h-4.5" />
                {alertCount > 0 && (
                  <span className="absolute top-0.5 right-0.5 w-2 h-2 bg-rose-500 rounded-full ring-1 ring-white" />
                )}
              </button>

              {/* Logout Button */}
              <button
                type="button"
                onClick={() => {
                  localStorage.removeItem("isLoggedIn");
                  setIsLoggedIn(false);
                  showToast("🔐 تم تسجيل الخروج بنجاح!", "info");
                }}
                title="تسجيل الخروج"
                className="w-8.5 h-8.5 rounded-full bg-rose-50 hover:bg-rose-100 border border-rose-100 flex items-center justify-center text-rose-600 transition-all cursor-pointer shadow-sm"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Trial Active Banner */}
          {localStorage.getItem("is_trial_user") === "true" && (
            <div className="bg-amber-500 text-slate-950 font-extrabold text-xs py-2.5 px-4 text-center flex items-center justify-center gap-1.5 shadow-inner" dir="rtl">
              <Clock className="w-4 h-4 text-slate-900" />
              <span>أنت تستخدم النسخة التجريبية (الوقت المتبقي: <span className="font-mono text-sm underline">{trialTimeRemaining || "59:59"}</span>)</span>
            </div>
          )}

        {/* Dynamic Screens */}
        <main className="flex-1 overflow-y-auto p-4 pb-28 relative -webkit-overflow-scrolling: touch;">
          
          {/* SCREEN 0: HOME / DASHBOARD */}
          {currentScreen === "home" && (
            <div className="space-y-6">
              
              {/* Wallet/Balance Card */}
              <div className="relative overflow-hidden bg-gradient-to-br from-[#7A3FC7] via-[#5F2E9F] to-[#481E7F] text-white rounded-[32px] p-6 shadow-[0_20px_40px_rgba(95,46,159,0.18)] border border-[#7139BB]/30">
                {/* Abstract background decorative patterns matching the wavy/spiral mesh in modern bank apps */}
                <div className="absolute inset-0 opacity-10 pointer-events-none">
                  <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path d="M0,50 Q25,20 50,50 T100,50" fill="none" stroke="white" strokeWidth="2" />
                    <path d="M0,70 Q25,40 50,70 T100,70" fill="none" stroke="white" strokeWidth="1" />
                  </svg>
                </div>

                <div className="flex justify-between items-center relative z-10 mb-5">
                  <div className="flex items-center gap-1.5 text-[#F3EEFA]/80">
                    <CreditCard className="w-4 h-4" />
                    <span className="text-xs font-bold tracking-wide">الرصيد الكلي غير المسترد</span>
                  </div>
                  
                  {/* Eye toggle button */}
                  <button
                    type="button"
                    onClick={() => {
                      const next = !showBalance;
                      setShowBalance(next);
                      localStorage.setItem("app_showBalance", String(next));
                    }}
                    className="p-1.5 hover:bg-white/10 rounded-full transition-all cursor-pointer"
                    title={showBalance ? "إخفاء الرصيد" : "إظهار الرصيد"}
                  >
                    {showBalance ? (
                      <EyeOff className="w-4.5 h-4.5 text-white/90" />
                    ) : (
                      <Eye className="w-4.5 h-4.5 text-white/90" />
                    )}
                  </button>
                </div>

                {/* Total Balance Amount */}
                <div className="relative z-10 mb-6 text-right">
                  {showBalance ? (
                    <div className="flex items-baseline justify-start gap-2 select-text" dir="rtl">
                      <span className="text-3xl font-black tracking-tight">{formatNumber(totalDebt)}</span>
                      <span className="text-sm font-extrabold text-[#F3EEFA]/90">دينار عراقي</span>
                    </div>
                  ) : (
                    <div className="text-3xl font-black tracking-widest text-[#F3EEFA]/60 py-1" dir="rtl">
                      •••••••• د.ع
                    </div>
                  )}
                </div>

                {/* Wallet stats sub-row */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10 relative z-10">
                  <div className="text-right">
                    <span className="block text-[10px] text-[#F3EEFA]/70 font-semibold mb-0.5">العملاء النشطين</span>
                    <span className="text-sm font-black text-white">{customers.length} زبائن</span>
                  </div>
                  <div className="text-right border-r border-white/10 pr-4">
                    <span className="block text-[10px] text-[#F3EEFA]/70 font-semibold mb-0.5">استحقاقات اليوم</span>
                    <span className="text-sm font-black text-amber-300">
                      {customerAlerts.length > 0 ? `${customerAlerts.length} أقساط عاجلة` : "لا توجد متأخرات"}
                    </span>
                  </div>
                </div>
              </div>

              {/* My Cards (بطاقاتي) Horizontal carousel */}
              <div className="space-y-3">
                <div className="flex justify-between items-center px-1">
                  <h3 className="text-sm font-black text-[#1E152E] flex items-center gap-1.5">
                    <span className="w-1.5 h-3.5 bg-[#5F2E9F] rounded-full inline-block" />
                    <span>المدفوعات والمستحقات الأخيرة</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setCurrentScreen("list")}
                    className="text-xs font-bold text-[#5F2E9F] hover:underline flex items-center gap-0.5"
                  >
                    <span>عرض الكل</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>

                {customers.length === 0 ? (
                  <div className="bg-white rounded-[24px] border border-dashed border-slate-200 p-8 text-center space-y-4">
                    <div className="w-12 h-12 rounded-full bg-[#F3EEFA] text-[#5F2E9F] flex items-center justify-center mx-auto shadow-sm">
                      <Sparkles className="w-5.5 h-5.5" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs font-black text-slate-800">لا توجد أقساط مسجلة بعد</p>
                      <p className="text-[10px] text-slate-400 font-medium">ابدأ بإضافة أول زبون وجدولة أقساطه الآن سحابياً.</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCurrentScreen("add")}
                      className="px-4 py-2 bg-[#5F2E9F] hover:bg-[#50248A] text-white text-xs font-black rounded-xl transition-all cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>إضافة أول زبون</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-4 overflow-x-auto pb-2 pt-1 scrollbar-none snap-x snap-mandatory -mx-4 px-4">
                    {customers.slice(-5).reverse().map((c) => {
                      // Calculate completed percentage
                      const paidInstallments = c.installments?.filter(inst => inst.status === "paid").length || 0;
                      const totalInstallments = c.installmentCount || 1;
                      const pct = Math.round((paidInstallments / totalInstallments) * 100);
                      
                      return (
                        <div
                          key={c.id}
                          onClick={() => {
                            setSelectedCustomerId(c.id);
                            localStorage.setItem("app_selectedCustomerId", c.id);
                            setCurrentScreen("detail");
                          }}
                          className="flex-shrink-0 w-[240px] bg-white rounded-[24px] border border-slate-100 p-4 shadow-[0_8px_20px_rgba(0,0,0,0.02)] hover:shadow-[0_12px_24px_rgba(95,46,159,0.04)] hover:border-[#5F2E9F]/10 transition-all cursor-pointer snap-start relative overflow-hidden group"
                        >
                          <div className="absolute top-0 right-0 w-24 h-24 bg-[#F3EEFA]/30 rounded-full blur-2xl pointer-events-none group-hover:bg-[#F3EEFA]/50 transition-all" />
                          
                          <div className="flex justify-between items-start mb-3 relative z-10">
                            <div className="flex flex-col text-right">
                              <span className="text-xs font-black text-slate-800 group-hover:text-[#5F2E9F] transition-colors">{c.name}</span>
                              <span className="text-[9px] text-slate-400 font-bold mt-0.5">{c.productName}</span>
                            </div>
                            <div className="bg-[#F3EEFA] text-[#5F2E9F] text-[9px] font-extrabold px-2 py-0.5 rounded-full">
                              مكتمل {pct}%
                            </div>
                          </div>

                          <div className="space-y-2 mt-4 relative z-10">
                            <div className="flex justify-between items-baseline">
                              <span className="text-[10px] text-slate-400 font-bold">المتبقي:</span>
                              <span className="text-xs font-black text-[#5F2E9F]" dir="rtl">
                                {formatNumber(c.remainingAmount)} د.ع
                              </span>
                            </div>
                            
                            {/* Progress bar */}
                            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div
                                className="bg-gradient-to-l from-[#7A3FC7] to-[#5F2E9F] h-full rounded-full transition-all duration-500"
                                style={{ width: `${pct}%` }}
                              />
                            </div>

                            <div className="flex justify-between text-[9px] text-slate-400 font-bold">
                              <span>قسط {paidInstallments} من {totalInstallments}</span>
                              <span>قيمة القسط: {formatNumber(c.monthlyAmount)} د.ع</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Favorite Services (الخدمات المفضلة) 2x2 grid */}
              <div className="space-y-3">
                <h3 className="text-sm font-black text-[#1E152E] px-1 flex items-center gap-1.5">
                  <span className="w-1.5 h-3.5 bg-[#5F2E9F] rounded-full inline-block" />
                  <span>الخدمات والأدوات الذكية</span>
                </h3>

                <div className="grid grid-cols-2 gap-3.5">
                  
                  {/* Card 1: Add customer */}
                  <div
                    onClick={() => setCurrentScreen("add")}
                    className="bg-white rounded-[24px] border border-slate-100 p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.01)] hover:shadow-[0_8px_24px_rgba(95,46,159,0.04)] hover:border-[#5F2E9F]/10 transition-all cursor-pointer flex flex-col justify-between h-28 relative group overflow-hidden"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#F3EEFA] text-[#5F2E9F] flex items-center justify-center transition-all group-hover:scale-110">
                      <PlusCircle className="w-5.5 h-5.5" />
                    </div>
                    <div className="text-right">
                      <span className="block text-xs font-black text-slate-800">إضافة قسط</span>
                      <span className="block text-[9px] text-slate-400 font-bold mt-0.5">جدولة الأقساط والزبائن</span>
                    </div>
                  </div>

                  {/* Card 2: Customers list */}
                  <div
                    onClick={() => {
                      setCurrentScreen("list");
                      setSelectedCustomerId(null);
                    }}
                    className="bg-white rounded-[24px] border border-slate-100 p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.01)] hover:shadow-[0_8px_24px_rgba(95,46,159,0.04)] hover:border-[#5F2E9F]/10 transition-all cursor-pointer flex flex-col justify-between h-28 relative group overflow-hidden"
                  >
                    <div className="w-10 h-10 rounded-full bg-slate-50 text-slate-600 flex items-center justify-center transition-all group-hover:scale-110">
                      <User className="w-5.5 h-5.5" />
                    </div>
                    <div className="text-right">
                      <span className="block text-xs font-black text-slate-800">الزبائن والأقساط</span>
                      <span className="block text-[9px] text-slate-400 font-bold mt-0.5">بحث وسجل كامل</span>
                    </div>
                  </div>

                  {/* Card 3: Due Alerts */}
                  <div
                    onClick={() => setCurrentScreen("alerts")}
                    className="bg-white rounded-[24px] border border-slate-100 p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.01)] hover:shadow-[0_8px_24px_rgba(95,46,159,0.04)] hover:border-[#5F2E9F]/10 transition-all cursor-pointer flex flex-col justify-between h-28 relative group overflow-hidden"
                  >
                    <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center transition-all group-hover:scale-110 relative">
                      <Bell className="w-5.5 h-5.5" />
                      {customerAlerts.length > 0 && (
                        <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[9px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center ring-2 ring-white">
                          {customerAlerts.length}
                        </span>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="block text-xs font-black text-slate-800">تنبيهات الاستحقاق</span>
                      <span className="block text-[9px] text-slate-400 font-bold mt-0.5">مواعيد الدفع القريبة</span>
                    </div>
                  </div>

                  {/* Card 4: Settings */}
                  <div
                    onClick={() => setCurrentScreen("settings")}
                    className="bg-white rounded-[24px] border border-slate-100 p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.01)] hover:shadow-[0_8px_24px_rgba(95,46,159,0.04)] hover:border-[#5F2E9F]/10 transition-all cursor-pointer flex flex-col justify-between h-28 relative group overflow-hidden"
                  >
                    <div className="w-10 h-10 rounded-full bg-slate-50 text-slate-600 flex items-center justify-center transition-all group-hover:scale-110">
                      <Settings className="w-5.5 h-5.5" />
                    </div>
                    <div className="text-right">
                      <span className="block text-xs font-black text-slate-800">إعدادات الأمان</span>
                      <span className="block text-[9px] text-slate-400 font-bold mt-0.5">تغيير الحساب والمزامنة</span>
                    </div>
                  </div>

                </div>
              </div>

            </div>
          )}

          {/* SCREEN 1: ADD CUSTOMER */}
          {currentScreen === "add" && (
            <div className="space-y-4">
              {/* Form Step Indicators */}
              <div className="bg-white rounded-[24px] p-4.5 border border-slate-100 shadow-[0_4px_16px_rgba(0,0,0,0.02)] flex items-center justify-between mb-1">
                {!hasGuarantor ? (
                  <div className="flex items-center gap-1 w-full justify-center">
                    {/* Step 1 indicator: Customer Details */}
                    <button
                      type="button"
                      onClick={() => {
                        if (formStep > 1) setFormStep(1);
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 1
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : formStep > 1
                          ? "bg-emerald-500 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {formStep > 1 ? "✓" : "١"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 1 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>صاحب القسط</span>
                    </button>

                    {/* Connector line 1 */}
                    <div className={`h-1 flex-1 max-w-[40px] rounded-full transition-all duration-300 ${
                      formStep > 1 ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 2 indicator: Sale Item */}
                    <button
                      type="button"
                      onClick={() => {
                        if (formStep > 2) {
                          setFormStep(2);
                        } else if (formStep === 1) {
                          if (validateCustomer()) setFormStep(2);
                        }
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 2
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : formStep > 2
                          ? "bg-emerald-500 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {formStep > 2 ? "✓" : "٢"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 2 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>المادة المباعة</span>
                    </button>

                    {/* Connector line 2 */}
                    <div className={`h-1 flex-1 max-w-[40px] rounded-full transition-all duration-300 ${
                      formStep > 2 ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 3 indicator: Calculations */}
                    <button
                      type="button"
                      onClick={() => {
                        if (formStep > 3) {
                          setFormStep(3);
                        } else {
                          if (validateCustomer() && validateStep2()) setFormStep(3);
                        }
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 3
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : formStep > 3
                          ? "bg-emerald-500 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {formStep > 3 ? "✓" : "٣"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 3 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>الأقساط والمبالغ</span>
                    </button>

                    {/* Connector line 3 */}
                    <div className={`h-1 flex-1 max-w-[40px] rounded-full transition-all duration-300 ${
                      formStep > 3 ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 4 indicator: Document Uploads */}
                    <button
                      type="button"
                      onClick={() => {
                        if (validateCustomer() && validateStep2() && validateStep3()) {
                          setFormStep(4);
                        }
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 4
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        ٤
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 4 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>تصوير المستمسكات</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 w-full justify-center">
                    {/* Step 1 indicator: Guarantor Details */}
                    <button
                      type="button"
                      onClick={() => {
                        setFormStep(1);
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 1
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : "bg-emerald-500 text-white"
                      }`}>
                        {formStep !== 1 ? "✓" : "١"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 1 ? "text-[#5F2E9F] font-black scale-105" : "text-slate-400 font-bold"
                      }`}>🛡️ الكفيل</span>
                    </button>

                    {/* Connector line 1 */}
                    <div className={`h-1 flex-1 max-w-[20px] rounded-full transition-all duration-300 ${
                      formStep !== 1 ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 5 indicator: Customer Details */}
                    <button
                      type="button"
                      onClick={() => {
                        if (validateGuarantor()) setFormStep(5);
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 5
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : (formStep !== 1 && formStep !== 5)
                          ? "bg-emerald-500 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {(formStep !== 1 && formStep !== 5) ? "✓" : "٢"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 5 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>👤 صاحب القسط</span>
                    </button>

                    {/* Connector line 2 */}
                    <div className={`h-1 flex-1 max-w-[20px] rounded-full transition-all duration-300 ${
                      (formStep !== 1 && formStep !== 5) ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 2 indicator: Sale Item */}
                    <button
                      type="button"
                      onClick={() => {
                        if (validateGuarantor() && validateCustomer()) setFormStep(2);
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 2
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : (formStep > 2 && formStep !== 5)
                          ? "bg-emerald-500 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {(formStep > 2 && formStep !== 5) ? "✓" : "٣"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 2 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>المادة</span>
                    </button>

                    {/* Connector line 3 */}
                    <div className={`h-1 flex-1 max-w-[20px] rounded-full transition-all duration-300 ${
                      (formStep > 2 && formStep !== 5) ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 3 indicator: Calculations */}
                    <button
                      type="button"
                      onClick={() => {
                        if (validateGuarantor() && validateCustomer() && validateStep2()) setFormStep(3);
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 3
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : (formStep > 3 && formStep !== 5)
                          ? "bg-emerald-500 text-white"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        {(formStep > 3 && formStep !== 5) ? "✓" : "٤"}
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 3 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>الأقساط</span>
                    </button>

                    {/* Connector line 4 */}
                    <div className={`h-1 flex-1 max-w-[20px] rounded-full transition-all duration-300 ${
                      (formStep > 3 && formStep !== 5) ? "bg-emerald-400" : "bg-slate-100"
                    }`} />

                    {/* Step 4 indicator: Customer Documents */}
                    <button
                      type="button"
                      onClick={() => {
                        if (validateGuarantor() && validateCustomer() && validateStep2() && validateStep3()) {
                          setFormStep(4);
                        }
                      }}
                      className="flex flex-col items-center flex-1 cursor-pointer focus:outline-none"
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-300 ${
                        formStep === 4
                          ? "bg-indigo-900 text-white ring-4 ring-indigo-100 shadow-md"
                          : "bg-slate-100 text-slate-400"
                      }`}>
                        ٥
                      </div>
                      <span className={`text-[10px] mt-1 font-extrabold transition-all whitespace-nowrap ${
                        formStep === 4 ? "text-indigo-950 font-black scale-105" : "text-slate-400 font-bold"
                      }`}>المستمسكات</span>
                    </button>
                  </div>
                )}
              </div>

              <form onSubmit={handleAddNewCustomer} className="space-y-4">
                <AnimatePresence mode="wait">
                  {formStep === 1 && (
                    <motion.div
                      key="step-1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-4"
                    >
                      {/* Guarantor Choice Selector (خيار الكفيل) */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-3">
                        <label className="text-xs font-black text-indigo-950 block border-b border-slate-100 pb-2">🛡️ نوع الضمان والتوثيق للمبيعة *</label>
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            type="button"
                            onClick={() => {
                              setHasGuarantor(false);
                              showToast("👤 تم اختيار إكمال المعاملة بدون كفيل", "info");
                            }}
                            className={`py-3 px-4 rounded-xl text-xs font-extrabold border transition-all flex items-center justify-center gap-2 ${
                              !hasGuarantor
                                ? "bg-indigo-900 text-white border-indigo-900 shadow-md shadow-indigo-900/10"
                                : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200"
                            }`}
                          >
                            <span>👤 بدون كفيل</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setHasGuarantor(true);
                              showToast("🛡️ تم تفعيل نموذج إضافة كفيل ضامن", "info");
                            }}
                            className={`py-3 px-4 rounded-xl text-xs font-extrabold border transition-all flex items-center justify-center gap-2 ${
                              hasGuarantor
                                ? "bg-indigo-900 text-white border-indigo-900 shadow-md shadow-indigo-900/10"
                                : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200"
                            }`}
                          >
                            <span>🛡️ وجود كفيل ضامن</span>
                          </button>
                        </div>
                      </div>

                      {/* Guarantor Personal & Documents Block */}
                      {hasGuarantor ? (
                        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
                          <div className="flex items-center gap-2 text-[#5F2E9F] font-bold border-b border-slate-100 pb-3">
                            <PlusCircle className="w-5 h-5 text-indigo-700" />
                            <span>🛡️ بيانات ومستمسكات الكفيل</span>
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">الاسم الثلاثي للكفيل *</label>
                            <input
                              type="text"
                              required={hasGuarantor}
                              placeholder="اكتب الاسم الكامل والمطابق للهوية"
                              value={guarantorName}
                              onChange={(e) => setGuarantorName(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">رقم الهاتف النشط للكفيل (الواتساب) *</label>
                            <input
                              type="tel"
                              required={hasGuarantor}
                              placeholder="مثال: 078xxxxxxxx"
                              value={guarantorPhone}
                              onChange={(e) => setGuarantorPhone(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold tracking-wide text-left text-slate-800 font-sans"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">عنوان السكن الفعلي للكفيل *</label>
                            <input
                              type="text"
                              required={hasGuarantor}
                              placeholder="المحافظة / المدينة / نقطة دالة"
                              value={guarantorAddress}
                              onChange={(e) => setGuarantorAddress(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                            />
                          </div>

                          {/* Guarantor Documents (Optional) */}
                          <div className="space-y-3 pt-2">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-extrabold text-[#5F2E9F]">🪪 وثائق الكفيل المرفقة (اختيارية):</span>
                              <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">معالجة وتقليل حجم تلقائي</span>
                            </div>

                            {/* Camera Face Snapshot capture */}
                            <div className="space-y-2">
                              <label className="flex items-center justify-center gap-2 px-4 py-3 border border-dashed border-slate-200 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-all active:scale-[0.99] select-none">
                                {compressingKeys.includes("guarantor_personal") ? (
                                  <>
                                    <span className="w-4 h-4 border-2 border-[#5F2E9F] border-t-transparent rounded-full animate-spin"></span>
                                    <span className="text-[11px] font-bold text-[#5F2E9F] animate-pulse">جاري ضغط وتقليل حجم الصورة...</span>
                                  </>
                                ) : guarantorImages.personal ? (
                                  <>
                                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                    <span className="text-[11px] font-bold text-emerald-600">تم تصوير وجه الكفيل بنجاح</span>
                                  </>
                                ) : (
                                  <>
                                    <Camera className="w-5 h-5 text-[#5F2E9F]" />
                                    <span className="text-[11px] font-extrabold text-slate-600">📸 التقاط لقطة وجه مباشرة للكفيل (صورة شخصية)</span>
                                  </>
                                )}
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="user"
                                  disabled={compressingKeys.includes("guarantor_personal")}
                                  onChange={(e) => handleGuarantorFileChange(e, "personal")}
                                  className="hidden"
                                />
                              </label>
                              {guarantorImages.personal && (
                                <div className="relative w-28 h-28 mx-auto group">
                                  <img
                                    src={guarantorImages.personal}
                                    alt="Guarantor Face"
                                    className="w-full h-full object-cover rounded-xl border-2 border-[#5F2E9F]/10 shadow-sm"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => setGuarantorImages(prev => ({ ...prev, personal: "" }))}
                                    className="absolute -top-1.5 -right-1.5 w-6 h-6 bg-rose-500 hover:bg-rose-600 text-white rounded-full flex items-center justify-center text-xs font-black shadow-md cursor-pointer transition-all"
                                  >
                                    ✕
                                  </button>
                                </div>
                              )}
                            </div>

                            {/* ID Front and Back capture */}
                            <div className="grid grid-cols-2 gap-3">
                              <label className="flex flex-col items-center justify-center gap-1.5 p-3.5 border border-dashed border-slate-200 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-all text-center select-none">
                                {compressingKeys.includes("guarantor_idFront") ? (
                                  <>
                                    <span className="w-4 h-4 border-2 border-[#5F2E9F] border-t-transparent rounded-full animate-spin"></span>
                                    <span className="text-[9px] font-bold text-[#5F2E9F] animate-pulse">جاري الضغط...</span>
                                  </>
                                ) : guarantorImages.idFront ? (
                                  <>
                                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                    <span className="text-[10px] font-bold text-emerald-600">الموحدة أمامي ✓</span>
                                  </>
                                ) : (
                                  <>
                                    <Camera className="w-5 h-5 text-[#5F2E9F]" />
                                    <span className="text-[10px] font-extrabold text-slate-600">📸 الموحدة أمامي</span>
                                  </>
                                )}
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  disabled={compressingKeys.includes("guarantor_idFront")}
                                  onChange={(e) => handleGuarantorFileChange(e, "idFront")}
                                  className="hidden"
                                />
                              </label>

                              <label className="flex flex-col items-center justify-center gap-1.5 p-3.5 border border-dashed border-slate-200 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-all text-center select-none">
                                {compressingKeys.includes("guarantor_idBack") ? (
                                  <>
                                    <span className="w-4 h-4 border-2 border-[#5F2E9F] border-t-transparent rounded-full animate-spin"></span>
                                    <span className="text-[9px] font-bold text-[#5F2E9F] animate-pulse">جاري الضغط...</span>
                                  </>
                                ) : guarantorImages.idBack ? (
                                  <>
                                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                    <span className="text-[10px] font-bold text-emerald-600">الموحدة خلفي ✓</span>
                                  </>
                                ) : (
                                  <>
                                    <Camera className="w-5 h-5 text-[#5F2E9F]" />
                                    <span className="text-[10px] font-extrabold text-slate-600">📸 الموحدة خلفي</span>
                                  </>
                                )}
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  disabled={compressingKeys.includes("guarantor_idBack")}
                                  onChange={(e) => handleGuarantorFileChange(e, "idBack")}
                                  className="hidden"
                                />
                              </label>
                            </div>

                            {/* Residence Card Front and Back capture */}
                            <div className="grid grid-cols-2 gap-3">
                              <label className="flex flex-col items-center justify-center gap-1.5 p-3.5 border border-dashed border-slate-200 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-all text-center select-none">
                                {compressingKeys.includes("guarantor_resFront") ? (
                                  <>
                                    <span className="w-4 h-4 border-2 border-[#5F2E9F] border-t-transparent rounded-full animate-spin"></span>
                                    <span className="text-[9px] font-bold text-[#5F2E9F] animate-pulse">جاري الضغط...</span>
                                  </>
                                ) : guarantorImages.resFront ? (
                                  <>
                                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                    <span className="text-[10px] font-bold text-emerald-600">بطاقة السكن أمامي ✓</span>
                                  </>
                                ) : (
                                  <>
                                    <Camera className="w-5 h-5 text-[#5F2E9F]" />
                                    <span className="text-[10px] font-extrabold text-slate-600">📸 بطاقة السكن أمامي</span>
                                  </>
                                )}
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  disabled={compressingKeys.includes("guarantor_resFront")}
                                  onChange={(e) => handleGuarantorFileChange(e, "resFront")}
                                  className="hidden"
                                />
                              </label>

                              <label className="flex flex-col items-center justify-center gap-1.5 p-3.5 border border-dashed border-slate-200 rounded-xl bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-all text-center select-none">
                                {compressingKeys.includes("guarantor_resBack") ? (
                                  <>
                                    <span className="w-4 h-4 border-2 border-[#5F2E9F] border-t-transparent rounded-full animate-spin"></span>
                                    <span className="text-[9px] font-bold text-[#5F2E9F] animate-pulse">جاري الضغط...</span>
                                  </>
                                ) : guarantorImages.resBack ? (
                                  <>
                                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                    <span className="text-[10px] font-bold text-emerald-600">بطاقة السكن خلفي ✓</span>
                                  </>
                                ) : (
                                  <>
                                    <Camera className="w-5 h-5 text-[#5F2E9F]" />
                                    <span className="text-[10px] font-extrabold text-slate-600">📸 بطاقة السكن خلفي</span>
                                  </>
                                )}
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  disabled={compressingKeys.includes("guarantor_resBack")}
                                  onChange={(e) => handleGuarantorFileChange(e, "resBack")}
                                  className="hidden"
                                />
                              </label>
                            </div>

                            {/* Previews for ID and Residence */}
                            {(guarantorImages.idFront || guarantorImages.idBack || guarantorImages.resFront || guarantorImages.resBack) && (
                              <div className="grid grid-cols-4 gap-2 mt-2 pt-1 border-t border-slate-100">
                                <div className="space-y-1 relative">
                                  <span className="text-[8px] font-bold text-slate-400 block text-center">موحدة أمامي</span>
                                  {guarantorImages.idFront ? (
                                    <>
                                      <img src={guarantorImages.idFront} className="h-10 w-full object-cover rounded border border-slate-200 cursor-zoom-in" onClick={() => setPreviewImageSrc(guarantorImages.idFront || null)} />
                                      <button type="button" onClick={() => setGuarantorImages(p => ({ ...p, idFront: "" }))} className="absolute top-3 right-0.5 bg-rose-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[8px] font-black">✕</button>
                                    </>
                                  ) : (
                                    <div className="h-10 bg-slate-100 rounded border border-slate-200"></div>
                                  )}
                                </div>
                                <div className="space-y-1 relative">
                                  <span className="text-[8px] font-bold text-slate-400 block text-center">موحدة خلفي</span>
                                  {guarantorImages.idBack ? (
                                    <>
                                      <img src={guarantorImages.idBack} className="h-10 w-full object-cover rounded border border-slate-200 cursor-zoom-in" onClick={() => setPreviewImageSrc(guarantorImages.idBack || null)} />
                                      <button type="button" onClick={() => setGuarantorImages(p => ({ ...p, idBack: "" }))} className="absolute top-3 right-0.5 bg-rose-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[8px] font-black">✕</button>
                                    </>
                                  ) : (
                                    <div className="h-10 bg-slate-100 rounded border border-slate-200"></div>
                                  )}
                                </div>
                                <div className="space-y-1 relative">
                                  <span className="text-[8px] font-bold text-slate-400 block text-center">سكن أمامي</span>
                                  {guarantorImages.resFront ? (
                                    <>
                                      <img src={guarantorImages.resFront} className="h-10 w-full object-cover rounded border border-slate-200 cursor-zoom-in" onClick={() => setPreviewImageSrc(guarantorImages.resFront || null)} />
                                      <button type="button" onClick={() => setGuarantorImages(p => ({ ...p, resFront: "" }))} className="absolute top-3 right-0.5 bg-rose-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[8px] font-black">✕</button>
                                    </>
                                  ) : (
                                    <div className="h-10 bg-slate-100 rounded border border-slate-200"></div>
                                  )}
                                </div>
                                <div className="space-y-1 relative">
                                  <span className="text-[8px] font-bold text-slate-400 block text-center">سكن خلفي</span>
                                  {guarantorImages.resBack ? (
                                    <>
                                      <img src={guarantorImages.resBack} className="h-10 w-full object-cover rounded border border-slate-200 cursor-zoom-in" onClick={() => setPreviewImageSrc(guarantorImages.resBack || null)} />
                                      <button type="button" onClick={() => setGuarantorImages(p => ({ ...p, resBack: "" }))} className="absolute top-3 right-0.5 bg-rose-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[8px] font-black">✕</button>
                                    </>
                                  ) : (
                                    <div className="h-10 bg-slate-100 rounded border border-slate-200"></div>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        /* If no guarantor, we show both guarantor choice AND customer details inside Step 1 itself! */
                        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
                          <div className="flex items-center gap-2 text-[#5F2E9F] font-bold border-b border-slate-100 pb-3">
                            <User className="w-5 h-5 text-indigo-700" />
                            <span>👤 بيانات صاحب القسط</span>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">الاسم الثلاثي للعميل *</label>
                            <input
                              type="text"
                              required
                              placeholder="اكتب الاسم الكامل والمطابق للهوية"
                              value={custName}
                              onChange={(e) => setCustName(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">رقم الهاتف النشط (الواتساب) *</label>
                            <input
                              type="tel"
                              required
                              placeholder="مثال: 078xxxxxxxx"
                              value={custPhone}
                              onChange={(e) => setCustPhone(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold tracking-wide text-left text-slate-800 font-sans"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">تاريخ تسجيل البيع / المعاملة *</label>
                            <input
                              type="date"
                              required
                              value={custDateAdded}
                              onChange={(e) => setCustDateAdded(e.target.value)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-bold text-slate-800 text-right"
                            />
                            <p className="text-[10px] text-slate-400 font-bold leading-relaxed mt-0.5">
                              سيتم تعيين يوم السداد الشهري تلقائياً بناءً على تاريخ اليوم المختار هنا (مثال: يوم {custDateAdded.split("-")[2] || "6"}).
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Navigation buttons */}
                      <button
                        type="button"
                        onClick={() => {
                          if (hasGuarantor) {
                            if (validateGuarantor()) {
                              setFormStep(5); // Advance to customer details in step 5
                            }
                          } else {
                            if (validateCustomer()) {
                              setFormStep(2); // Advance straight to sale item
                            }
                          }
                        }}
                        className="w-full py-4 bg-indigo-900 hover:bg-indigo-950 text-white font-extrabold rounded-xl shadow-lg shadow-indigo-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 text-base active:scale-[0.98]"
                      >
                        <span>{hasGuarantor ? "التالي: ملئ بيانات صاحب القسط" : "التالي: تفاصيل المادة المباعة"}</span>
                        <ArrowLeft className="w-5 h-5" />
                      </button>
                    </motion.div>
                  )}

                  {formStep === 5 && hasGuarantor && (
                    <motion.div
                      key="step-5"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-4"
                    >
                      {/* Card: Customer Personal Details (when guarantor is active) */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-[#5F2E9F] font-bold border-b border-slate-100 pb-3">
                          <User className="w-5 h-5 text-indigo-700" />
                          <span>👤 بيانات صاحب القسط</span>
                        </div>
                        
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">الاسم الثلاثي للعميل *</label>
                          <input
                            type="text"
                            required
                            placeholder="اكتب الاسم الكامل والمطابق للهوية"
                            value={custName}
                            onChange={(e) => setCustName(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">رقم الهاتف النشط (الواتساب) *</label>
                          <input
                            type="tel"
                            required
                            placeholder="مثال: 078xxxxxxxx"
                            value={custPhone}
                            onChange={(e) => setCustPhone(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold tracking-wide text-left text-slate-800 font-sans"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">تاريخ تسجيل البيع / المعاملة *</label>
                          <input
                            type="date"
                            required
                            value={custDateAdded}
                            onChange={(e) => setCustDateAdded(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-bold text-slate-800 text-right"
                          />
                          <p className="text-[10px] text-slate-400 font-bold leading-relaxed mt-0.5">
                            سيتم تعيين يوم السداد الشهري تلقائياً بناءً على تاريخ اليوم المختار هنا (مثال: يوم {custDateAdded.split("-")[2] || "6"}).
                          </p>
                        </div>
                      </div>

                      {/* Navigation buttons */}
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => {
                            setFormStep(1); // Go back to guarantor details
                          }}
                          className="py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-[0.98]"
                        >
                          <ArrowRight className="w-5 h-5" />
                          <span>سابق</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (validateCustomer()) {
                              setFormStep(2); // Go to sale item
                            }
                          }}
                          className="col-span-2 py-4 bg-indigo-900 hover:bg-indigo-950 text-white font-extrabold rounded-xl shadow-lg shadow-indigo-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 text-base active:scale-[0.98]"
                        >
                          <span>التالي: تفاصيل المادة</span>
                          <ArrowLeft className="w-5 h-5" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {formStep === 2 && (
                    <motion.div
                      key="step-2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-4"
                    >
                      {/* Card: Sale Item Details */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-indigo-900 font-bold border-b border-slate-100 pb-3">
                          <FileText className="w-5 h-5 text-indigo-700" />
                          <span>📦 تفاصيل المادة أو السلعة المباعة</span>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">اسم السلعة المباعة *</label>
                          <input
                            type="text"
                            required
                            placeholder="مثال: آيفون 15 برو ماكس 256 جيجا"
                            value={prodName}
                            onChange={(e) => setProdName(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">الرقم التسلسلي / السيريال <span className="text-slate-400 font-normal">(اختياري)</span></label>
                          <input
                            type="text"
                            placeholder="اكتب رقم السيريال للمنتج للتثبيت"
                            value={prodSerial}
                            onChange={(e) => setProdSerial(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
                          />
                        </div>
                      </div>

                      {/* Navigation and Actions */}
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setFormStep(hasGuarantor ? 5 : 1)}
                          className="py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl transition-all cursor-pointer text-sm"
                        >
                          السابق
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (validateStep2()) {
                              setFormStep(3);
                            }
                          }}
                          className="col-span-2 py-4 bg-indigo-900 hover:bg-indigo-950 text-white font-extrabold rounded-xl shadow-lg shadow-indigo-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 text-sm active:scale-[0.98]"
                        >
                          <span>التالي: حسابات الأقساط</span>
                          <ArrowLeft className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {formStep === 3 && (
                    <motion.div
                      key="step-3"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-4"
                    >
                      {/* Card: Calculations and installments */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-indigo-900 font-bold border-b border-slate-100 pb-3">
                          <DollarSign className="w-5 h-5 text-indigo-700" />
                          <span>💰 حسابات المبالغ والأقساط</span>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">السعر الكلي (دينار عراقي) *</label>
                          <input
                            type="text"
                            required
                            placeholder="0"
                            value={custTotalAmount}
                            onChange={(e) => handleMoneyInputChange(e.target.value, setCustTotalAmount)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-base font-bold text-indigo-900 text-right"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">المقدمة المدفوعة *</label>
                            <input
                              type="text"
                              required
                              placeholder="0"
                              value={custUpfront}
                              onChange={(e) => handleMoneyInputChange(e.target.value, setCustUpfront)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-bold text-emerald-700 text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-slate-600">القسط الشهري *</label>
                            <input
                              type="text"
                              required
                              placeholder="0"
                              value={custMonthly}
                              onChange={(e) => handleMoneyInputChange(e.target.value, setCustMonthly)}
                              className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-bold text-amber-700 text-right"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-600">يوم السداد الشهري المحدد (تاريخ الاستحقاق) *</label>
                          <input
                            type="number"
                            required
                            min="1"
                            max="31"
                            placeholder="مثال: 5 (أي يوم 5 من كل شهر)"
                            value={custDueDay}
                            onChange={(e) => setCustDueDay(e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-bold"
                          />
                        </div>

                        <div className="p-3.5 bg-slate-100 rounded-xl border border-slate-200 flex justify-between items-center">
                          <span className="text-xs font-bold text-slate-600">المبلغ المتبقي الصافي في الذمة:</span>
                          <span className="text-lg font-extrabold text-red-600">{formatNumber(remainingVal)} د.ع</span>
                        </div>
                      </div>

                      {/* Navigation Actions */}
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setFormStep(2)}
                          className="py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl transition-all cursor-pointer text-sm"
                        >
                          السابق
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (validateStep3()) {
                              setFormStep(4);
                            }
                          }}
                          className="col-span-2 py-4 bg-indigo-900 hover:bg-indigo-950 text-white font-extrabold rounded-xl shadow-lg shadow-indigo-900/10 transition-all cursor-pointer flex items-center justify-center gap-2 text-sm active:scale-[0.98]"
                        >
                          <span>التالي: تصوير المستمسكات</span>
                          <ArrowLeft className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                  {formStep === 4 && (
                    <motion.div
                      key="step-4"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-4"
                    >
                      {/* Card: Document Uploads with direct Camera capture="environment" for rear camera */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm space-y-4">
                        <div className="flex items-center gap-2 text-indigo-900 font-bold border-b border-slate-100 pb-3">
                          <Camera className="w-5 h-5 text-indigo-700" />
                          <span>🪪 فتح الكاميرا الخلفية وتصوير المستمسكات مباشرة</span>
                        </div>

                        {/* Personal Photo - optional */}
                        <div className="space-y-1.5">
                          <span className="text-xs font-bold text-slate-600 block">الصورة الشخصية للعميل (اختياري)</span>
                          <div className="relative">
                            <label className="flex flex-col items-center justify-center p-4 bg-slate-50 hover:bg-slate-100/70 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer transition-all text-center gap-1">
                              {compressingKeys.includes("customer_personal") ? (
                                <>
                                  <span className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></span>
                                  <span className="text-xs font-bold text-indigo-600 animate-pulse">جاري ضغط وتقليل حجم الصورة...</span>
                                </>
                              ) : images.personal ? (
                                <>
                                  <CheckCircle2 className="w-6 h-6 text-emerald-500 animate-bounce" />
                                  <span className="text-xs font-bold text-emerald-600">تم تحميل الصورة الشخصية</span>
                                </>
                              ) : (
                                <>
                                  <Camera className="w-6 h-6 text-indigo-600" />
                                  <span className="text-xs text-slate-500 font-bold">التقط صورة بالكاميرا أو اختر ملفاً</span>
                                </>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                capture="user"
                                disabled={compressingKeys.includes("customer_personal")}
                                onChange={(e) => handleFileChange(e, "personal")}
                                className="hidden"
                              />
                            </label>
                            {images.personal && (
                              <div className="mt-2 flex justify-center">
                                <img
                                  src={images.personal}
                                  alt="Personal Preview"
                                  className="h-20 w-20 object-cover rounded-full border border-slate-300 shadow-sm"
                                />
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Residence Card (Front & Back) - captures rear camera */}
                        <div className="space-y-2">
                          <span className="text-xs font-bold text-slate-600 block">بطاقة السكن للعميل (مطلوب) *</span>
                          <div className="grid grid-cols-2 gap-3">
                            <label className="flex flex-col items-center justify-center p-3 bg-slate-50 hover:bg-slate-100/70 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer transition-all text-center gap-1">
                              {compressingKeys.includes("customer_resFront") ? (
                                <>
                                  <span className="w-4 h-4 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></span>
                                  <span className="text-[10px] font-bold text-slate-500 animate-pulse">جاري الضغط...</span>
                                </>
                              ) : images.resFront ? (
                                <>
                                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                  <span className="text-[11px] font-bold text-emerald-600">تم تصوير الوجه الأمامي</span>
                                </>
                              ) : (
                                <>
                                  <Camera className="w-5 h-5 text-slate-500" />
                                  <span className="text-[11px] font-extrabold text-slate-600">📸 تصوير الأمامي</span>
                                </>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                capture="environment"
                                disabled={compressingKeys.includes("customer_resFront")}
                                onChange={(e) => handleFileChange(e, "resFront")}
                                className="hidden"
                              />
                            </label>

                            <label className="flex flex-col items-center justify-center p-3 bg-slate-50 hover:bg-slate-100/70 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer transition-all text-center gap-1">
                              {compressingKeys.includes("customer_resBack") ? (
                                <>
                                  <span className="w-4 h-4 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></span>
                                  <span className="text-[10px] font-bold text-slate-500 animate-pulse">جاري الضغط...</span>
                                </>
                              ) : images.resBack ? (
                                <>
                                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                  <span className="text-[11px] font-bold text-emerald-600">تم تصوير الوجه الخلفي</span>
                                </>
                              ) : (
                                <>
                                  <Camera className="w-5 h-5 text-slate-500" />
                                  <span className="text-[11px] font-extrabold text-slate-600">📸 تصوير الخلفي</span>
                                </>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                capture="environment"
                                disabled={compressingKeys.includes("customer_resBack")}
                                onChange={(e) => handleFileChange(e, "resBack")}
                                className="hidden"
                              />
                            </label>
                          </div>

                          {/* Previews for Residence Card */}
                          {(images.resFront || images.resBack) && (
                            <div className="grid grid-cols-2 gap-3 mt-1">
                              {images.resFront ? (
                                <img
                                  src={images.resFront}
                                  alt="Residence Card Front"
                                  className="h-20 w-full object-cover rounded-lg border border-slate-200"
                                />
                              ) : (
                                <div className="h-20 bg-slate-100 rounded-lg border border-slate-200"></div>
                              )}
                              {images.resBack ? (
                                <img
                                  src={images.resBack}
                                  alt="Residence Card Back"
                                  className="h-20 w-full object-cover rounded-lg border border-slate-200"
                                />
                              ) : (
                                <div className="h-20 bg-slate-100 rounded-lg border border-slate-200"></div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* National ID Unified (Front & Back) - captures rear camera */}
                        <div className="space-y-2">
                          <span className="text-xs font-bold text-slate-600 block">البطاقة الوطنية الموحدة (مطلوب) *</span>
                          <div className="grid grid-cols-2 gap-3">
                            <label className="flex flex-col items-center justify-center p-3 bg-slate-50 hover:bg-slate-100/70 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer transition-all text-center gap-1">
                              {compressingKeys.includes("customer_idFront") ? (
                                <>
                                  <span className="w-4 h-4 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></span>
                                  <span className="text-[10px] font-bold text-slate-500 animate-pulse">جاري الضغط...</span>
                                </>
                              ) : images.idFront ? (
                                <>
                                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                  <span className="text-[11px] font-bold text-emerald-600">تم تصوير الموحدة أمامي</span>
                                </>
                              ) : (
                                <>
                                  <Camera className="w-5 h-5 text-slate-500" />
                                  <span className="text-[11px] font-extrabold text-slate-600">📸 تصوير الموحدة أمامي</span>
                                </>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                capture="environment"
                                disabled={compressingKeys.includes("customer_idFront")}
                                onChange={(e) => handleFileChange(e, "idFront")}
                                className="hidden"
                              />
                            </label>

                            <label className="flex flex-col items-center justify-center p-3 bg-slate-50 hover:bg-slate-100/70 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer transition-all text-center gap-1">
                              {compressingKeys.includes("customer_idBack") ? (
                                <>
                                  <span className="w-4 h-4 border-2 border-slate-500 border-t-transparent rounded-full animate-spin"></span>
                                  <span className="text-[10px] font-bold text-slate-500 animate-pulse">جاري الضغط...</span>
                                </>
                              ) : images.idBack ? (
                                <>
                                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                  <span className="text-[11px] font-bold text-emerald-600">تم تصوير الموحدة خلفي</span>
                                </>
                              ) : (
                                <>
                                  <Camera className="w-5 h-5 text-slate-500" />
                                  <span className="text-[11px] font-extrabold text-slate-600">📸 تصوير الموحدة خلفي</span>
                                </>
                              )}
                              <input
                                type="file"
                                accept="image/*"
                                capture="environment"
                                disabled={compressingKeys.includes("customer_idBack")}
                                onChange={(e) => handleFileChange(e, "idBack")}
                                className="hidden"
                              />
                            </label>
                          </div>

                          {/* Previews for ID */}
                          {(images.idFront || images.idBack) && (
                            <div className="grid grid-cols-2 gap-3 mt-1">
                              {images.idFront ? (
                                <img
                                  src={images.idFront}
                                  alt="ID Card Front"
                                  className="h-20 w-full object-cover rounded-lg border border-slate-200"
                                />
                              ) : (
                                <div className="h-20 bg-slate-100 rounded-lg border border-slate-200"></div>
                              )}
                              {images.idBack ? (
                                <img
                                  src={images.idBack}
                                  alt="ID Card Back"
                                  className="h-20 w-full object-cover rounded-lg border border-slate-200"
                                />
                              ) : (
                                <div className="h-20 bg-slate-100 rounded-lg border border-slate-200"></div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Form Actions */}
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setFormStep(3)}
                          className="py-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl transition-all cursor-pointer text-sm"
                        >
                          السابق
                        </button>

                        {/* Submit Button with Loading Double-Click Protection */}
                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className={`col-span-2 text-white font-extrabold py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm ${
                            isSubmitting 
                              ? "bg-slate-400 cursor-not-allowed shadow-none" 
                              : "bg-indigo-900 shadow-indigo-900/20 hover:bg-indigo-950 active:scale-[0.98] cursor-pointer"
                          }`}
                        >
                          {isSubmitting ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              <span>جاري الحفظ...</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-4 h-4" />
                              <span>حفظ القسط ومزامنته سحابياً</span>
                            </>
                          )}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </form>
            </div>
          )}

          {/* SCREEN 2: CUSTOMERS LIST & FILTER */}
          {currentScreen === "list" && (
            <div className="space-y-4">
              
              <div className="space-y-3 pb-1">
                {/* Smart Alert Alert Banner */}
                {dueCustomers.length > 0 && (
                  <div className="bg-amber-50 border border-amber-300 text-amber-900 p-4 rounded-2xl shadow-sm flex items-start gap-3">
                    <div className="p-1 bg-amber-200 text-amber-800 rounded-lg mt-0.5">
                      <AlertCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-amber-950">🔔 تنبيهات الاستحقاق:</h4>
                      <p className="text-xs mt-1 leading-relaxed">
                        يوجد <strong className="text-red-700 underline">{dueCustomers.length}</strong> من العملاء يستحق موعد قسطهم أو تجاوزه!
                      </p>
                    </div>
                  </div>
                )}

                {/* Search & Filter Buttons */}
                <div className="bg-slate-50 pb-3 pt-1.5 border-b border-slate-100/80 shadow-sm space-y-2">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="🔍 ابحث بالاسم، رقم الهاتف، أو اسم المادة..."
                      value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                      className="w-full pl-4 pr-10 py-3.5 rounded-xl border border-slate-200 bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all text-sm font-semibold shadow-inner text-right"
                    />
                    <Search className="w-5 h-5 text-slate-400 absolute top-3.5 right-3.5" />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setCurrentFilter("all")}
                      className={`py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        currentFilter === "all"
                          ? "bg-indigo-900 text-white shadow-md shadow-indigo-950/20"
                          : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      📂 كل عملاء الأقساط ({customers.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentFilter("due")}
                      className={`py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                        currentFilter === "due"
                          ? "bg-amber-600 text-white shadow-md shadow-amber-600/20"
                          : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50"
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>المستحقين للدفع ({dueCustomers.length})</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Customers Grid list */}
              <div className="space-y-3">
                {filteredCustomers.length === 0 ? (
                  <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-500">
                    <UserPlus className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-bold">لا يوجد أي سجلات مطابقة للبحث حالياً.</p>
                    <p className="text-xs text-slate-400 mt-1">يمكنك إضافة قسط جديد من التبويب السفلي.</p>
                  </div>
                ) : (
                  filteredCustomers.slice(0, visibleCount).map((c) => {
                    const isDue = isCustomerDue(c);
                    const isCompleted = c.status === "done";
                    
                    let statusBadgeColor = "bg-emerald-50 text-emerald-700 border-emerald-200";
                    let statusText = "مستمر بالدفع";
 
                    if (isCompleted) {
                      statusBadgeColor = "bg-slate-100 text-slate-500 border-slate-200";
                      statusText = "مكتمل السداد";
                    } else if (isDue) {
                      statusBadgeColor = "bg-red-50 text-red-600 border-red-200 animate-pulse";
                      statusText = "🚨 يستحق الدفع";
                    }
 
                    const defaultAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cbd5e1"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;
 
                    return (
                      <div
                        key={c.id}
                        className="bg-white rounded-[24px] border border-slate-100 shadow-[0_4px_16px_rgba(0,0,0,0.02)] hover:shadow-[0_8px_32px_rgba(0,0,0,0.06)] hover:border-indigo-200 transition-all duration-300 p-5 relative overflow-hidden flex flex-col gap-4 group"
                      >
                        {/* Decorative subtle colored bar matching status */}
                        <div className={`absolute top-0 right-0 bottom-0 w-1.5 ${
                          isCompleted ? "bg-slate-300" : isDue ? "bg-rose-600" : "bg-amber-400"
                        }`} />

                        {/* Top customer info & Status row */}
                        <div className="flex justify-between items-start pl-1 pr-1">
                          {/* Left-aligned Status badge */}
                          <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border flex items-center gap-1.5 shadow-sm ${statusBadgeColor}`}>
                            <span className={`w-1.5 h-1.5 rounded-full bg-current ${isDue ? "animate-ping" : ""}`}></span>
                            {statusText}
                          </span>

                          {/* Right-aligned Name and Avatar */}
                          <div
                            onClick={() => viewCustomerDetails(c.id)}
                            className="flex items-center gap-3 text-right cursor-pointer"
                          >
                            <div className="text-right">
                              <h3 className="font-extrabold text-sm text-slate-900 group-hover:text-indigo-950 transition-colors leading-tight">
                                {c.name}
                              </h3>
                              <span className="text-[10px] text-slate-400 font-semibold block mt-0.5 font-sans" dir="ltr">
                                {c.phone} 📞
                              </span>
                            </div>
                            <img
                              src={c.images.personal || defaultAvatar}
                              alt="Avatar"
                              className="w-11 h-11 rounded-full object-cover border border-slate-200 bg-slate-50 shadow-sm hover:scale-105 transition-transform"
                            />
                          </div>
                        </div>

                        {/* Product and schedule info strip */}
                        <div 
                          onClick={() => viewCustomerDetails(c.id)}
                          className="flex flex-wrap gap-1.5 items-center bg-slate-50 p-2 rounded-xl border border-slate-100/60 text-[11px] font-bold text-slate-700 cursor-pointer justify-end pr-2"
                        >
                          {!isCompleted && (
                            <span className="bg-amber-500/10 text-amber-800 px-2 py-0.5 rounded-lg border border-amber-500/10">
                              🗓 الاستحقاق: {formatNextDueDate(getCustomerNextDueDate(c))}
                            </span>
                          )}
                          <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-lg border border-indigo-100">
                            📦 {c.productName}
                          </span>
                        </div>

                        {/* Money Summary Grid with Android-style metrics */}
                        <div
                          onClick={() => viewCustomerDetails(c.id)}
                          className="grid grid-cols-2 gap-3.5 bg-slate-50/50 p-3 rounded-2xl border border-slate-100/50 text-xs text-right pr-2 cursor-pointer"
                        >
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">الواصل الإجمالي:</span>
                            <span className="font-extrabold text-emerald-600 block mt-0.5">
                              {formatNumber(c.totalAmount - c.remainingAmount)} د.ع
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">المتبقي الصافي:</span>
                            <span className="font-extrabold text-red-600 block mt-0.5">
                              {formatNumber(c.remainingAmount)} د.ع
                            </span>
                          </div>
                        </div>

                        {/* Android-style Action Bar */}
                        <div className="flex gap-2 justify-end pt-1 pr-1 border-t border-dashed border-slate-100">
                          {/* Quick Message */}
                          <button
                            type="button"
                            onClick={() => setTemplateModalCustomer(c)}
                            className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-100 rounded-xl transition-all cursor-pointer text-xs font-extrabold flex items-center gap-1.5"
                          >
                            <MessageCircle className="w-4 h-4 text-emerald-600" />
                            <span>تذكير</span>
                          </button>

                          {/* Quick Call */}
                          <a
                            href={`tel:${c.phone}`}
                            className="px-3 py-2 bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-100 rounded-xl transition-all text-xs font-bold flex items-center justify-center gap-1"
                            title="اتصال هاتفي سريع"
                          >
                            <Phone className="w-4 h-4" />
                          </a>

                          {/* View Profile */}
                          <button
                            type="button"
                            onClick={() => viewCustomerDetails(c.id)}
                            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all text-xs font-extrabold cursor-pointer"
                          >
                            عرض الحساب
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* SCREEN 3: CUSTOMER DETAIL PANEL */}
          {currentScreen === "detail" && selectedCustomerId && (() => {
            const customer = customers.find((c) => c.id === selectedCustomerId);
            if (!customer) return <p className="text-center py-10">العميل غير موجود.</p>;

            const defaultAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cbd5e1"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;

            return (
              <div className="space-y-4">
                {/* Back Button */}
                <button
                  type="button"
                  onClick={() => setCurrentScreen("list")}
                  className="bg-white border border-slate-200 text-slate-700 text-xs font-bold py-2 px-4 rounded-xl hover:bg-slate-50 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>العودة لقائمة العملاء</span>
                </button>

                {/* Profile header card */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-center space-y-3">
                  <img
                    src={customer.images.personal || defaultAvatar}
                    alt="avatar"
                    className="w-20 h-20 rounded-full object-cover mx-auto border-2 border-slate-200 bg-slate-50"
                  />
                  <div className="space-y-1">
                    <h2 className="text-lg font-extrabold text-slate-900">{customer.name}</h2>
                    <p className="text-xs font-semibold text-slate-500 tracking-wide">{customer.phone}</p>
                  </div>

                  {/* Triggers template chooser modal */}
                  <button
                    type="button"
                    onClick={() => setTemplateModalCustomer(customer)}
                    className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-extrabold shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>مراسلة واختيار نموذج رسالة جاهزة</span>
                  </button>
                </div>

                {/* Product details card */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 border-r-4 border-r-indigo-600 text-right">
                  <h3 className="font-extrabold text-sm text-indigo-900 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                    <span>📦 تفاصيل المادة المبيعة</span>
                  </h3>
                  
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">اسم المنتج:</span>
                    <span className="font-bold text-slate-800">{customer.productName}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">الرقم التسلسلي (السيريال):</span>
                    <span className="font-mono text-slate-800 bg-slate-100 px-2 py-0.5 rounded">{customer.productSerial}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">تاريخ تسجيل المعاملة:</span>
                    <span className="font-bold text-slate-800">{customer.dateAdded}</span>
                  </div>
                </div>

                {/* Guarantor Details Card */}
                {customer.hasGuarantor && customer.guarantor && (
                  <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3.5 border-r-4 border-r-[#5F2E9F] text-right">
                    <h3 className="font-extrabold text-sm text-[#5F2E9F] pb-2 border-b border-slate-100 flex items-center gap-1.5">
                      <span>🛡️ تفاصيل وبيانات الكفيل الضامن</span>
                    </h3>
                    
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">اسم الكفيل الثلاثي:</span>
                      <span className="font-extrabold text-slate-800">{customer.guarantor.name}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">رقم هاتف الكفيل:</span>
                      <div className="flex items-center gap-1">
                        <a href={`tel:${customer.guarantor.phone}`} className="text-indigo-600 font-extrabold underline">{customer.guarantor.phone}</a>
                        <span>📞</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">عنوان سكن الكفيل:</span>
                      <span className="font-bold text-slate-800">{customer.guarantor.address}</span>
                    </div>

                    {/* Guarantor Documents preview */}
                    {customer.guarantor.images && (
                      <div className="pt-2.5 border-t border-slate-100 space-y-2">
                        <span className="text-[11px] font-extrabold text-[#5F2E9F] block">🪪 وثائق الكفيل الضامن (اضغط للتكبير):</span>
                        <div className="grid grid-cols-5 gap-1.5">
                          {customer.guarantor.images.personal && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">الوجه</span>
                              <img
                                src={customer.guarantor.images.personal}
                                alt="Guarantor Face"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.personal || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images.idFront && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">موحدة أ</span>
                              <img
                                src={customer.guarantor.images.idFront}
                                alt="Guarantor ID Front"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.idFront || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images.idBack && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">موحدة خ</span>
                              <img
                                src={customer.guarantor.images.idBack}
                                alt="Guarantor ID Back"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.idBack || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images.resFront && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">سكن أ</span>
                              <img
                                src={customer.guarantor.images.resFront}
                                alt="Guarantor Res Front"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.resFront || null)}
                              />
                            </div>
                          )}
                          {customer.guarantor.images.resBack && (
                            <div className="text-center space-y-1">
                              <span className="text-[8px] font-bold text-slate-400 block truncate">سكن خ</span>
                              <img
                                src={customer.guarantor.images.resBack}
                                alt="Guarantor Res Back"
                                className="w-full h-10 object-cover rounded border border-slate-200 cursor-zoom-in"
                                onClick={() => setPreviewImageSrc(customer.guarantor.images?.resBack || null)}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Financial Status Card */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 text-right">
                  <h3 className="font-extrabold text-sm text-indigo-900 pb-2 border-b border-slate-100 flex items-center gap-1.5">
                    <span>💵 المبالغ وتواريخ الدفع</span>
                  </h3>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">السعر الكلي للمادة:</span>
                    <span className="font-extrabold text-slate-800">{formatNumber(customer.totalAmount)} د.ع</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">المقدمة المدفوعة:</span>
                    <span className="font-bold text-slate-800">{formatNumber(customer.upfront)} د.ع</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">القسط الشهري المحدد:</span>
                    <span className="font-bold text-slate-800">{formatNumber(customer.monthlyAmount)} د.ع</span>
                  </div>
                  
                  <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 flex flex-col gap-1.5 text-xs text-amber-900">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold">يوم السداد المحدد:</span>
                      <span className="font-extrabold">يوم {customer.dueDay} في كل شهر</span>
                    </div>
                    {customer.status === "active" && (
                      <div className="flex justify-between items-center border-t border-amber-200/60 pt-1.5 mt-0.5">
                        <span className="font-extrabold text-amber-950">تاريخ الاستحقاق القادم:</span>
                        <span className="font-extrabold text-red-700 underline font-mono">
                          {formatNextDueDate(getCustomerNextDueDate(customer))}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                    <span className="text-sm font-bold text-slate-700">المتبقي الصافي للذمة:</span>
                    <span className="text-xl font-extrabold text-red-600">{formatNumber(customer.remainingAmount)} د.ع</span>
                  </div>
                </div>

                {/* Submit Payment Card */}
                {customer.remainingAmount > 0 ? (
                  <div className="bg-emerald-50 rounded-2xl p-5 border border-emerald-200 shadow-sm space-y-4 text-right">
                    <h3 className="font-extrabold text-sm text-emerald-900 flex items-center gap-1.5">
                      <DollarSign className="w-5 h-5 text-emerald-600" />
                      <span>💸 تسديد دفعة أو قسط جديد</span>
                    </h3>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600">اكتب مبلغ الدفع بالدينار العراقي:</label>
                      <input
                        type="text"
                        placeholder="0"
                        value={payAmountInput}
                        onChange={(e) => handleMoneyInputChange(e.target.value, setPayAmountInput)}
                        className="w-full px-4 py-3 rounded-xl border border-emerald-300 bg-white focus:ring-4 focus:ring-emerald-100 focus:border-emerald-500 outline-none transition-all text-base font-bold text-emerald-900 text-right"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-600">تاريخ تسجيل الدفع (تلقائي أو اختر يدوياً):</label>
                      <input
                        type="date"
                        value={payDateInput}
                        onChange={(e) => setPayDateInput(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-emerald-300 bg-white focus:ring-4 focus:ring-emerald-100 focus:border-emerald-500 outline-none transition-all text-sm font-bold text-slate-800 text-right"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handlePaymentSubmit(customer.id)}
                      className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 active:scale-[0.98] transition-all cursor-pointer text-sm"
                    >
                      ✓ تأكيد وتسجيل الدفعة الحالية
                    </button>
                  </div>
                ) : (
                  <div className="bg-slate-100 text-slate-600 border border-slate-300 rounded-2xl p-5 text-center font-bold text-sm">
                    🎉 تم سداد كافة الأقساط بالكامل وإبراء ذمة العميل بنجاح!
                  </div>
                )}

                {/* Receipt and payment log history */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3 text-right">
                  <h3 className="font-extrabold text-sm text-slate-900 pb-2 border-b border-slate-100">
                    📜 سجل الوصولات السابقة والمدفوعات
                  </h3>

                  {!customer.payments || customer.payments.length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-4 font-medium">لا توجد أي سحوبات أو سدادات مسجلة حالياً.</p>
                  ) : (
                    <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto pr-1">
                      {customer.payments.map((p, index) => (
                        <div key={index} className="flex justify-between items-center py-2.5 text-xs">
                          <span className="text-slate-500 font-semibold">🗓 {p.date}</span>
                          <span className="text-emerald-600 font-extrabold bg-emerald-50 border border-emerald-100 px-2.5 py-0.5 rounded-full">
                            + {formatNumber(p.amount)} د.ع
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Document verification images archive */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4 text-right">
                  <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-100 pb-2">
                    🪪 أرشيف المستمسكات والوثائق المرفقة (اضغط للتكبير)
                  </h3>

                  <div className="grid grid-cols-2 gap-3.5">
                    {customer.images.resFront && (
                      <div className="text-center space-y-1">
                        <span className="text-[10px] font-bold text-slate-500 block">بطاقة السكن - الوجه الأمامي</span>
                        <img
                          src={customer.images.resFront}
                          alt="Residence Card Front"
                          className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                          onClick={() => setPreviewImageSrc(customer.images.resFront)}
                        />
                      </div>
                    )}
                    {customer.images.resBack && (
                      <div className="text-center space-y-1">
                        <span className="text-[10px] font-bold text-slate-500 block">بطاقة السكن - الوجه الخلفي</span>
                        <img
                          src={customer.images.resBack}
                          alt="Residence Card Back"
                          className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                          onClick={() => setPreviewImageSrc(customer.images.resBack)}
                        />
                      </div>
                    )}
                    {customer.images.idFront && (
                      <div className="text-center space-y-1">
                        <span className="text-[10px] font-bold text-slate-500 block">البطاقة الوطنية - الوجه الأمامي</span>
                        <img
                          src={customer.images.idFront}
                          alt="ID Card Front"
                          className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                          onClick={() => setPreviewImageSrc(customer.images.idFront)}
                        />
                      </div>
                    )}
                    {customer.images.idBack && (
                      <div className="text-center space-y-1">
                        <span className="text-[10px] font-bold text-slate-500 block">البطاقة الوطنية - الوجه الخلفي</span>
                        <img
                          src={customer.images.idBack}
                          alt="ID Card Back"
                          className="w-full h-24 object-cover rounded-xl border border-slate-200 hover:scale-[1.02] cursor-pointer transition-all shadow-sm"
                          onClick={() => setPreviewImageSrc(customer.images.idBack)}
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Permanent Delete Button with custom confirmation modal trigger */}
                <button
                  type="button"
                  onClick={() => setDeleteConfirmId(customer.id)}
                  className="w-full py-3.5 bg-rose-50 text-rose-600 border border-rose-200 rounded-xl font-extrabold hover:bg-rose-100/80 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                >
                  <Trash2 className="w-5 h-5" />
                  <span>⚠️ حذف ملف هذا الزبون نهائياً</span>
                </button>
              </div>
          );
          })()}

          {/* SCREEN 4: ALERTS / NOTIFICATIONS SCREEN */}
          {currentScreen === "alerts" && (
            <div className="space-y-4">
              
              <div className="space-y-3 pb-2">
                {/* Header card with summary statistics */}
                <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm text-right space-y-3">
                  <div className="flex items-center gap-2 text-indigo-900 font-bold">
                    <Bell className="w-5 h-5 text-indigo-700" />
                    <span>🔔 مركز تتبع واستحقاق الأقساط</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                    يقوم هذا المركز تلقائياً بتحليل حسابات الزبائن وتحديد المواعيد القادمة، المتأخرة، أو المستحقة بناءً على الأشهر الفعلية وعمليات السداد السابقة.
                  </p>
                  
                  {/* Visual statistics cards */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-2">
                    <div className="bg-rose-50 border border-rose-200 rounded-xl p-2">
                      <span className="text-[10px] font-extrabold text-rose-800 block">متأخر عن السداد</span>
                      <span className="text-sm font-black text-rose-700">
                        {customerAlerts.filter(a => a.status === "overdue").length}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-2">
                      <span className="text-[10px] font-extrabold text-amber-800 block">مستحق اليوم</span>
                      <span className="text-sm font-black text-amber-700">
                        {customerAlerts.filter(a => a.status === "due_today").length}
                      </span>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-2">
                      <span className="text-[10px] font-extrabold text-yellow-800 block">يقترب موعده</span>
                      <span className="text-sm font-black text-yellow-700">
                        {customerAlerts.filter(a => a.status === "approaching").length}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Alert Level Filter Pills */}
                <div className="flex gap-1.5 overflow-x-auto pb-1" dir="rtl">
                  <button
                    type="button"
                    onClick={() => setAlertFilter("all")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "all"
                        ? "bg-indigo-900 text-white border-indigo-950 shadow-sm"
                        : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                    }`}
                  >
                    الكل ({customerAlerts.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertFilter("overdue")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "overdue"
                        ? "bg-rose-600 text-white border-rose-700 shadow-sm animate-pulse"
                        : "bg-white text-rose-600 border-rose-200 hover:bg-rose-50"
                    }`}
                  >
                    متأخر عن السداد ({customerAlerts.filter(a => a.status === "overdue").length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertFilter("due_today")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "due_today"
                        ? "bg-amber-600 text-white border-amber-700 shadow-sm"
                        : "bg-white text-amber-600 border-amber-200 hover:bg-slate-50"
                    }`}
                  >
                    مستحق اليوم ({customerAlerts.filter(a => a.status === "due_today").length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAlertFilter("approaching")}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                      alertFilter === "approaching"
                        ? "bg-yellow-500 text-slate-900 border-yellow-600 shadow-sm"
                        : "bg-white text-yellow-600 border-yellow-200 hover:bg-slate-50"
                    }`}
                  >
                    يقترب السداد ({customerAlerts.filter(a => a.status === "approaching").length})
                  </button>
                </div>
              </div>

              {/* List of Alerts */}
              <div className="space-y-3">
                {(() => {
                  const filtered = customerAlerts.filter(a => alertFilter === "all" || a.status === alertFilter);
                  
                  if (filtered.length === 0) {
                    return (
                      <div className="bg-white rounded-2xl p-8 border border-slate-200/80 shadow-sm text-center space-y-3">
                        <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto text-3xl shadow-inner animate-pulse">
                          ✨
                        </div>
                        <h4 className="font-extrabold text-sm text-slate-800">تنبيهات فارغة ومطابقة تماماً!</h4>
                        <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                          لا توجد أقساط مطابقة لهذا الفلتر في الوقت الحالي. جميع الحسابات منتظمة!
                        </p>
                      </div>
                    );
                  }

                  return filtered.map((alert) => {
                    const c = alert.customer;
                    const defaultAvatar = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23cbd5e1"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;
                    
                    let badgeStyles = "";
                    if (alert.status === "overdue") {
                      badgeStyles = "bg-rose-50 text-rose-700 border-rose-200";
                    } else if (alert.status === "due_today") {
                      badgeStyles = "bg-amber-500 text-white border-amber-600 animate-pulse";
                    } else if (alert.status === "approaching") {
                      badgeStyles = "bg-yellow-50 text-yellow-800 border-yellow-200";
                    }

                    return (
                      <div
                        key={c.id}
                        className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col gap-3 relative overflow-hidden text-right"
                      >
                        {/* Decorative side accent bar */}
                        <div className={`absolute top-0 right-0 bottom-0 w-1.5 ${
                          alert.status === "overdue" ? "bg-rose-600" :
                          alert.status === "due_today" ? "bg-amber-500 animate-pulse" : "bg-yellow-400"
                        }`} />

                        {/* Top customer and badge row */}
                        <div className="flex justify-between items-start pl-1 pr-2">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={c.images.personal || defaultAvatar}
                              alt={c.name}
                              className="w-10 h-10 rounded-full object-cover border border-slate-200 bg-slate-100 flex-shrink-0"
                            />
                            <div className="text-right">
                              <h4 className="font-extrabold text-xs text-slate-900 hover:text-indigo-900 transition-colors cursor-pointer" onClick={() => viewCustomerDetails(c.id)}>
                                {c.name}
                              </h4>
                              <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">
                                📞 {c.phone}
                              </span>
                            </div>
                          </div>

                          <span className={`text-[10px] font-extrabold px-2 py-1 rounded-lg border ${badgeStyles}`}>
                            {alert.statusText}
                          </span>
                        </div>

                        {/* Middle financial details */}
                        <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100/60 text-xs text-right pr-4">
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">المادة / الجهاز:</span>
                            <span className="font-bold text-slate-800 block truncate mt-0.5">📦 {c.productName}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px] font-bold">القسط الشهري المطلوب:</span>
                            <span className="font-extrabold text-indigo-950 block mt-0.5">{formatNumber(c.monthlyAmount)} د.ع</span>
                          </div>
                          <div className="mt-1.5">
                            <span className="text-slate-400 block text-[9px] font-bold">المتبقي الإجمالي:</span>
                            <span className="font-extrabold text-rose-600 block mt-0.5">{formatNumber(c.remainingAmount)} د.ع</span>
                          </div>
                          <div className="mt-1.5">
                            <span className="text-slate-400 block text-[9px] font-bold">تاريخ الاستحقاق القادم:</span>
                            <span className="font-bold text-slate-800 font-mono block mt-0.5">🗓 {formatNextDueDate(alert.nextDueDate)}</span>
                          </div>
                        </div>

                        {/* Quick Action Buttons Row */}
                        <div className="flex gap-2 pr-2">
                          {/* Direct WhatsApp Message Dialog button */}
                          <button
                            type="button"
                            onClick={() => setTemplateModalCustomer(c)}
                            className="flex-1 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl transition-all cursor-pointer text-[11px] font-bold flex items-center justify-center gap-1.5 animate-bounce-subtle"
                          >
                            <MessageCircle className="w-4 h-4 text-emerald-600" />
                            <span>مراسلة وتذكير</span>
                          </button>

                          {/* Fast Phone call button */}
                          <a
                            href={`tel:${c.phone}`}
                            className="px-3 py-2 bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 rounded-xl transition-all text-[11px] font-bold flex items-center justify-center gap-1"
                            title="اتصال هاتفي سريع"
                          >
                            <Phone className="w-4 h-4" />
                          </a>

                          {/* Full Customer Profile details button */}
                          <button
                            type="button"
                            onClick={() => viewCustomerDetails(c.id)}
                            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-all text-[11px] font-bold cursor-pointer"
                          >
                            الملف الشخصي
                          </button>
                        </div>

                      </div>
                    );
                  });
                })()}
              </div>
            </div>
          )}

          {/* SCREEN 5: SETTINGS */}
          {currentScreen === "settings" && (
            <SettingsScreen
              currentCredentials={systemCredentials}
              onCredentialsChange={setSystemCredentials}
              showToast={showToast}
            />
          )}

        </main>

        {/* Navigation bottom menu */}
        <nav className="absolute bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md h-20 flex border-t border-slate-100 z-40 rounded-t-[28px] shadow-[0_-8px_30px_rgba(0,0,0,0.04)] px-2 justify-around items-center">
          
          {/* Tab 1: Add Customer (إضافة قسط) */}
          <button
            type="button"
            onClick={() => setCurrentScreen("add")}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1"
          >
            <div className={`flex items-center justify-center px-4.5 py-1.5 rounded-full transition-all duration-300 ${
              currentScreen === "add" ? "bg-[#F3EEFA] text-[#5F2E9F] scale-105 shadow-sm" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
            }`}>
              <PlusCircle className="w-5 h-5" />
            </div>
            <span className={`text-[10px] mt-1 font-bold transition-all ${
              currentScreen === "add" ? "text-[#5F2E9F] font-extrabold" : "text-slate-500 font-medium"
            }`}>إضافة قسط</span>
          </button>

          {/* Tab 2: Customers List (كل العملاء) */}
          <button
            type="button"
            onClick={() => {
              setCurrentScreen("list");
              setSelectedCustomerId(null);
            }}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1"
          >
            <div className={`flex items-center justify-center px-4.5 py-1.5 rounded-full transition-all duration-300 ${
              currentScreen === "list" ? "bg-[#F3EEFA] text-[#5F2E9F] scale-105 shadow-sm" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
            }`}>
              <Search className="w-5 h-5" />
            </div>
            <span className={`text-[10px] mt-1 font-bold transition-all ${
              currentScreen === "list" ? "text-[#5F2E9F] font-extrabold" : "text-slate-500 font-medium"
            }`}>كل العملاء</span>
          </button>

          {/* Tab 3: Alerts (التنبيهات) */}
          <button
            type="button"
            onClick={() => {
              setCurrentScreen("alerts");
              setSelectedCustomerId(null);
            }}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1"
          >
            <div className={`flex items-center justify-center px-4.5 py-1.5 rounded-full transition-all duration-300 ${
              currentScreen === "alerts" ? "bg-[#F3EEFA] text-[#5F2E9F] scale-105 shadow-sm" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
            }`}>
              <Bell className="w-5 h-5" />
            </div>
            <span className={`text-[10px] mt-1 font-bold transition-all ${
              currentScreen === "alerts" ? "text-[#5F2E9F] font-extrabold" : "text-slate-500 font-medium"
            }`}>التنبيهات</span>
            {alertCount > 0 && (
              <span className="absolute top-0 right-1/2 translate-x-7 bg-rose-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full min-w-[18px] text-center shadow-md">
                {alertCount}
              </span>
            )}
          </button>

          {/* Tab 4: Settings (الإعدادات) */}
          <button
            type="button"
            onClick={() => {
              setCurrentScreen("settings");
              setSelectedCustomerId(null);
            }}
            className="flex flex-col items-center justify-center transition-all cursor-pointer relative group flex-1"
          >
            <div className={`flex items-center justify-center px-4.5 py-1.5 rounded-full transition-all duration-300 ${
              currentScreen === "settings" ? "bg-[#F3EEFA] text-[#5F2E9F] scale-105 shadow-sm" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
            }`}>
              <Settings className="w-5 h-5" />
            </div>
            <span className={`text-[10px] mt-1 font-bold transition-all ${
              currentScreen === "settings" ? "text-[#5F2E9F] font-extrabold" : "text-slate-500 font-medium"
            }`}>الإعدادات</span>
          </button>
        </nav>

        {/* MODAL 1: Ready-made Message Templates Chooser */}
        {templateModalCustomer && (() => {
          const c = templateModalCustomer;
          
          // Custom beautiful message templates
          const templates = [
            {
              title: "⏰ تذكير بموعد القسط القادم",
              text: `السلام عليكم أخي ${c.name} المحترم، نود تذكيرك بموعد قسط المادة (${c.productName}) المستحق في يوم ${c.dueDay} من الشهر، والبالغ قدره: ${formatNumber(c.monthlyAmount)} د.ع. يرجى التفضل بالسداد لتجنب الغرامات أو تراكم الأقساط. شكراً لالتزامك وتواصلك المستمر معنا.`
            },
            {
              title: "⚠️ تنبيه تأخير في السداد",
              text: `أخي العزيز ${c.name}، نلاحظ تأخر سداد القسط المستحق للمادة (${c.productName}) والبالغ قدره ${formatNumber(c.monthlyAmount)} د.ع. المتبقي بذمتك حتى الآن هو ${formatNumber(c.remainingAmount)} د.ع. نرجو منك التكرم بسداد المبلغ بأقرب وقت لتفادي أي إشكال قانوني. تفضل بقبول الاحترام والتقدير.`
            },
            {
              title: "💐 شكر وتقدير بعد السداد",
              text: `أخي المحترم ${c.name}، نشكرك جزيل الشكر على سداد الدفعة الحالية بنجاح والتزامك الراقي بمواعيد الأقساط. المبلغ المتبقي بذمتك الصافي الآن هو: ${formatNumber(c.remainingAmount)} د.ع فقط. نتمنى لك دوام الموفقية والنجاح!`
            }
          ];

          return (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
              <div className="bg-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 max-h-[85vh] overflow-y-auto text-right">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="font-extrabold text-sm text-indigo-950 flex items-center gap-1.5">
                    <MessageCircle className="w-5 h-5 text-indigo-700" />
                    <span>قوالب رسائل الواتساب الجاهزة</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setTemplateModalCustomer(null)}
                    className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <p className="text-xs text-slate-500 font-bold leading-relaxed">
                  اختر أحد القوالب التلقائية أدناه لإرسال رسالة مباشرة إلى هاتف الزبون (<span className="text-indigo-900">{c.name}</span>) دون الحاجة للكتابة اليدوية:
                </p>

                <div className="space-y-3">
                  {templates.map((tpl, i) => (
                    <div
                      key={i}
                      className="p-3.5 bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 rounded-xl transition-all cursor-pointer group"
                      onClick={() => launchWhatsAppWithMessage(c.phone, tpl.text)}
                    >
                      <h4 className="font-extrabold text-xs text-indigo-900 mb-1 flex justify-between items-center">
                        <span>{tpl.title}</span>
                        <span className="text-[9px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-extrabold group-hover:bg-indigo-200">إرسال مباشر</span>
                      </h4>
                      <p className="text-[11px] text-slate-600 leading-relaxed text-justify line-clamp-3">
                        {tpl.text}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => launchWhatsAppWithMessage(c.phone, "")}
                    className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                  >
                    💬 فتح محادثة فارغة بدون قالب جاهز
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

        {/* MODAL 2: Fullscreen Image Preview Zoom Overlay */}
        {previewImageSrc && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col justify-center items-center p-4">
            <button
              type="button"
              onClick={() => setPreviewImageSrc(null)}
              className="absolute top-5 right-5 p-2 bg-white/20 hover:bg-white/30 text-white rounded-full transition-all cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={previewImageSrc}
              alt="Fullscreen Zoomed Document"
              className="max-w-full max-h-[80vh] object-contain rounded-2xl shadow-2xl border border-white/10"
            />
            <p className="text-white/70 text-xs font-bold mt-4">اسحب أو انقر في أي مكان آخر للإغلاق</p>
          </div>
        )}

        {/* MODAL 3: Custom Delete Confirmation Modal */}
        {deleteConfirmId && (() => {
          const c = customers.find((cust) => cust.id === deleteConfirmId);
          if (!c) return null;
          return (
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 text-right">
                <div className="flex items-center gap-2.5 text-rose-600 font-extrabold border-b border-rose-50 pb-3">
                  <AlertCircle className="w-6 h-6 text-rose-500" />
                  <span className="text-sm">تأكيد حذف الزبون نهائياً</span>
                </div>
                
                <p className="text-xs text-slate-600 font-bold leading-relaxed">
                  هل أنت متأكد من حذف ملف الزبون (<span className="text-rose-600 font-extrabold">{c.name}</span>) بالكامل من النظام السحابي؟
                </p>
                
                <p className="text-[11px] text-slate-400 font-medium leading-relaxed bg-rose-50/50 p-2.5 rounded-xl border border-rose-100">
                  ⚠️ تنبيه: سيتم حذف معلومات الزبون، الوصولات، وجميع الوثائق والصور بشكل نهائي ولا يمكن التراجع عن هذا الإجراء مطلقاً!
                </p>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => handleDeleteCustomer(c.id)}
                    className="py-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs cursor-pointer transition-all shadow-lg shadow-rose-600/20"
                  >
                    نعم، احذف نهائياً
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmId(null)}
                    className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                  >
                    تراجع وإلغاء
                  </button>
                </div>
              </div>
            </div>
          );
        })()}

        {/* MODAL 4: Optional Documents Warning Confirmation Modal */}
        {showNoDocsConfirm && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-sm rounded-3xl p-6 space-y-4 shadow-2xl border border-slate-100 text-right">
              <div className="flex items-center gap-2.5 text-amber-600 font-extrabold border-b border-amber-50 pb-3">
                <AlertCircle className="w-6 h-6 text-amber-500" />
                <span className="text-sm">تأكيد التسجيل بدون مستندات</span>
              </div>
              
              <p className="text-xs text-slate-600 font-bold leading-relaxed">
                هل أنت متأكد من تسجيل هذا الزبون بدون رفع المستمسكات الثبوتية؟
              </p>
              
              <p className="text-[11px] text-amber-700 font-medium leading-relaxed bg-amber-50 p-2.5 rounded-xl border border-amber-100">
                ⚠️ تنبيه: لم يتم رفع أو تصوير كافة الوثائق المطلوبة (مثل بطاقة السكن أو البطاقة الموحدة). يمكنك مواصلة الحفظ وحفظها لاحقاً إذا أردت.
              </p>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => executeSaveCustomer()}
                  className="py-3 bg-amber-500 hover:bg-amber-600 text-white font-extrabold rounded-xl text-xs cursor-pointer transition-all shadow-lg shadow-amber-500/20"
                >
                  نعم، أكمل التسجيل
                </button>
                <button
                  type="button"
                  onClick={() => setShowNoDocsConfirm(false)}
                  className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs cursor-pointer transition-all"
                >
                  إلغاء ورفع الصور
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    )}
    </div>
  );
}
