import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { RefreshCw, AlertCircle, Upload, ShieldCheck, Share2, History } from "lucide-react";
import { exportBackupZip, importBackupZip, getBackupLogs, BackupLog } from "../firebase";

interface SettingsScreenProps {
  showToast: (msg: string, type: "success" | "danger" | "info") => void;
  onImportSuccess?: () => void;
}

export default function SettingsScreen({
  showToast,
  onImportSuccess
}: SettingsScreenProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  
  const [progressPercent, setProgressPercent] = useState<number | null>(null);
  const [progressMessage, setProgressMessage] = useState("");
  const [backupLogs, setBackupLogs] = useState<BackupLog[]>([]);

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [importResultReport, setImportResultReport] = useState<string | null>(null);

  // Fetch operational logs
  const fetchLogs = async () => {
    try {
      const logs = await getBackupLogs();
      setBackupLogs(logs);
    } catch (e) {
      console.error("Error fetching backup logs:", e);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleExport = async () => {
    if (isExporting || isImporting) return;
    setIsExporting(true);
    setProgressPercent(0);
    setProgressMessage("جاري البدء في تجهيز الأرشيف...");
    try {
      const zipBlob = await exportBackupZip((pct, msg) => {
        setProgressPercent(pct);
        setProgressMessage(msg);
      });
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `AlAqsat_Full_Backup_${dateStr}.zip`;
      const file = new File([zipBlob], filename, { type: "application/zip" });

      const downloadFallback = () => {
        const url = URL.createObjectURL(zipBlob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast("✨ تم تصدير النسخة الاحتياطية (ZIP) بنجاح وحفظها في جهازك!", "success");
      };

      // Check if browser supports sharing files
      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({
            files: [file],
            title: "النسخة الاحتياطية لتطبيق الأقساط",
            text: "ملف نسخة احتياطية كامل شامل للصور والنصوص"
          });
          showToast("✨ تم مشاركة ملف النسخ الاحتياطي بنجاح!", "success");
        } catch (shareErr: any) {
          // If they didn't abort/cancel, fall back to direct download
          if (shareErr.name !== "AbortError") {
            console.info("Sharing policy restriction in this browser context. Falling back to direct download.", shareErr);
            downloadFallback();
          } else {
            showToast("ℹ️ تم إلغاء عملية المشاركة.", "info");
          }
        }
      } else {
        // Fallback to normal download
        downloadFallback();
      }
      await fetchLogs();
    } catch (error) {
      console.error("Export error:", error);
      showToast("❌ عذراً، فشل تصدير النسخة الاحتياطية", "danger");
    } finally {
      setIsExporting(false);
      setProgressPercent(null);
      setProgressMessage("");
    }
  };

  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      console.log("📂 [SettingsScreen] لم يتم اختيار أي ملف.");
      return;
    }
    console.log("📂 [SettingsScreen] تم اختيار ملف النسخة الاحتياطية:", file.name, `(${file.size} بايت)`);
    setPendingFile(file);
    setShowConfirmModal(true);
    // Clear the input value so that the same file can be selected again if needed
    e.target.value = "";
  };

  const executeImport = async () => {
    if (!pendingFile) return;
    const file = pendingFile;
    setShowConfirmModal(false);
    setPendingFile(null);

    console.log("📂 [SettingsScreen] تم تأكيد الاستيراد من المستخدم. جاري البدء بالمعالجة...");
    setIsImporting(true);
    setProgressPercent(0);
    setProgressMessage("جاري البدء في عملية استيراد البيانات...");

    try {
      console.log("📂 [SettingsScreen] جاري استدعاء importBackupZip...");
      const resultReport = await importBackupZip(file, (pct, msg) => {
        setProgressPercent(pct);
        setProgressMessage(msg);
        console.log(`📂 [SettingsScreen] تقدم الاستيراد: ${pct}% - ${msg}`);
      });
      console.log("📂 [SettingsScreen] انتهى استدعاء importBackupZip بنجاح تام.");
      setImportResultReport(resultReport);
      showToast("✨ تم استيراد واسترجاع البيانات والصور بنجاح 100%!", "success");
      await fetchLogs();
      if (onImportSuccess) {
        console.log("📂 [SettingsScreen] جاري إخطار الواجهة الرئيسية لتحديث القوائم وعرض العملاء...");
        onImportSuccess();
      }
    } catch (error) {
      console.error("📂 [SettingsScreen] خطأ في عملية استيراد البيانات:", error);
      const msg = error instanceof Error ? error.message : "تأكد من أنه ملف ZIP نسخة احتياطية صالح ومصدر من النظام.";
      showToast(`❌ فشل الاستيراد: ${msg}`, "danger");
      await fetchLogs();
    } finally {
      setIsImporting(false);
      setProgressPercent(null);
      setProgressMessage("");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="h-full flex flex-col overflow-hidden text-right"
      dir="rtl"
    >
      <div className="flex-shrink-0 space-y-4 pb-2">
        {/* Title Header */}
        <div className="bg-gradient-to-l from-[#0B1F3A] to-slate-900 rounded-[28px] p-5 text-white shadow-lg space-y-2 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -translate-x-8 -translate-y-8" />
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#D4A44B]/10 rounded-full blur-xl translate-x-4 translate-y-4" />
          
          <h2 className="text-xl font-extrabold flex items-center gap-2.5">
            <span>⚙️ إعدادات النظام والأمان</span>
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            من هنا يمكنك إدارة النسخ الاحتياطي للنظام لضمان حماية بياناتك والقدرة على استعادتها في أي وقت.
          </p>
        </div>
      </div>
 
      {/* Form Credentials Card */}
      <div className="flex-1 overflow-y-auto pb-4 px-1 bg-white rounded-3xl p-6 border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.04)] space-y-6 -webkit-overflow-scrolling: touch;">
        
        {/* Backup and Restore Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-slate-800 font-extrabold">
            <ShieldCheck className="w-5 h-5 text-[#D4A44B]" />
            <span>💾 إدارة النسخ الاحتياطي والاستعادة الشاملة</span>
          </div>
          
          <p className="text-[11px] text-slate-500 leading-relaxed font-bold">
            يدعم النظام ضغط جميع السجلات والصور وتصديرها في ملف أرشيف مجمع <span className="text-[#D4A44B]">ZIP</span> محمي ومؤمن برمز أمان، وضمان سلامة البيانات وصور الكفلاء بنسبة 100%.
          </p>
 
          {/* Real-time Progress Bar Indicator */}
          {progressPercent !== null && (
            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 space-y-3 shadow-inner">
              <div className="flex justify-between items-center text-xs font-extrabold text-[#0B1F3A]">
                <span className="flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4A44B]" />
                  <span>{progressMessage}</span>
                </span>
                <span className="font-mono text-[#0B1F3A] bg-slate-100 px-2 py-0.5 rounded-lg">{progressPercent}%</span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-[#0B1F3A] via-[#D4A44B] to-emerald-500 h-full transition-all duration-300 rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}
  
          <div className="grid grid-cols-2 gap-3 pt-1">
            {/* Export Button */}
            <button
              type="button"
              onClick={handleExport}
              disabled={isExporting || isImporting}
              className="h-12 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-[#0B1F3A] hover:text-[#D4A44B] font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50"
            >
              {isExporting ? (
                <>
                  <RefreshCw className="w-4 h-4 text-[#D4A44B] animate-spin" />
                  <span>جاري التحضير...</span>
                </>
              ) : (
                <>
                  <Share2 className="w-4 h-4 text-[#D4A44B]" />
                  <span>تصدير ومشاركة ZIP</span>
                </>
              )}
            </button>
  
            {/* Import Button */}
            <label className={`h-12 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-[#0B1F3A] hover:text-[#D4A44B] font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.98] text-center ${(isImporting || isExporting) ? 'opacity-50 pointer-events-none' : ''}`}>
              {isImporting ? (
                <>
                  <RefreshCw className="w-4 h-4 text-[#D4A44B] animate-spin" />
                  <span>جاري الاستيراد...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 text-[#D4A44B]" />
                  <span>استيراد ملف ZIP</span>
                </>
              )}
              <input
                type="file"
                accept=".zip"
                className="hidden"
                disabled={isImporting || isExporting}
                onChange={handleImportFileChange}
              />
            </label>
          </div>

          {/* Historical Logs List */}
          <div className="border-t border-slate-100 pt-6 space-y-3">
            <div className="flex items-center gap-2 text-slate-800 font-extrabold text-sm">
              <History className="w-4 h-4 text-[#0B1F3A]" />
              <span>📜 سجل عمليات النسخ والاستعادة السابقة</span>
            </div>
            
            {backupLogs.length === 0 ? (
              <div className="bg-slate-50 rounded-xl p-4 text-center border border-dashed border-slate-200">
                <p className="text-[10px] text-slate-400 font-bold">لا توجد عمليات تصدير أو استيراد مسجلة حتى الآن.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {backupLogs.map((log) => (
                  <div 
                    key={log.id} 
                    className={`p-3 rounded-xl border text-xs flex flex-col gap-1.5 transition-all hover:bg-slate-50/50 ${
                      log.status === "success" 
                        ? "bg-emerald-50/20 border-emerald-100" 
                        : "bg-rose-50/20 border-rose-100"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className={`px-2 py-0.5 rounded-md font-bold text-[9px] ${
                        log.type === "export" 
                          ? "bg-slate-100 text-slate-700 border border-slate-200" 
                          : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                      }`}>
                        {log.type === "export" ? "تصدير نسخة احتياطية" : "استيراد واستعادة"}
                      </span>
                      <span className="text-[9px] text-slate-400 font-semibold font-mono">
                        {new Date(log.timestamp).toLocaleString("ar-EG", {
                          year: 'numeric', month: 'short', day: 'numeric',
                          hour: '2-digit', minute: '2-digit'
                        })}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center text-[10px] text-slate-600 font-bold">
                      <span>مدة العملية: {log.durationMs >= 1000 ? `${(log.durationMs / 1000).toFixed(1)} ث` : `${log.durationMs} مل ث`}</span>
                      <span>عدد السجلات: {log.recordsCount}</span>
                      <span className={`font-semibold flex items-center gap-1 ${
                        log.status === "success" ? "text-emerald-700" : "text-rose-700"
                      }`}>
                        ● {log.status === "success" ? "ناجحة" : "فشلت"}
                      </span>
                    </div>

                    {log.error && (
                      <p className="text-[9px] text-rose-600 bg-rose-50/50 p-1.5 rounded-lg border border-rose-100/40 leading-relaxed font-semibold">
                        السبب: {log.error}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
 
      </div>

      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-[28px] max-w-md w-full border border-slate-100 shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-right"
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="bg-amber-50 border-b border-amber-100 p-5 flex gap-3 items-start">
              <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5 animate-pulse" />
              <div className="space-y-1">
                <h3 className="text-sm font-extrabold text-amber-900">تنبيه هام جداً واستعادة شاملة</h3>
                <p className="text-xs text-amber-800 font-semibold">
                  تحذير: سيتم حذف جميع البيانات الحالية بالكامل واستبدالها ببيانات الملف المختار!
                </p>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div className="bg-slate-50 rounded-2xl p-4 text-xs space-y-2 border border-slate-100 font-medium text-slate-600 leading-relaxed">
                <p>
                  عملية استيراد واستعادة البيانات من ملف <span className="text-[#0B1F3A] font-bold">ZIP</span> هي عملية حساسة وشاملة، حيث سيقوم التطبيق بـ:
                </p>
                <ul className="list-disc list-inside space-y-1 text-slate-700 pr-1">
                  <li>مسح كافة العملاء والأقساط المسجلين حالياً في هذا الجهاز.</li>
                  <li>حذف جميع المستندات وصور الكفلاء القديمة المخزنة.</li>
                  <li>استرجاع كافة سجلات وملفات وصور ملف الأرشيف <span className="font-bold text-emerald-700">"{pendingFile?.name}"</span> بنسبة 100%.</li>
                </ul>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={executeImport}
                  className="flex-1 h-11 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md active:scale-95"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>نعم، امسح واستعد البيانات</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    console.log("📂 [SettingsScreen] تم إلغاء الاستيراد من قبل المستخدم.");
                    setShowConfirmModal(false);
                    setPendingFile(null);
                  }}
                  className="h-11 px-5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold rounded-xl text-xs transition-all cursor-pointer active:scale-95"
                >
                  <span>إلغاء</span>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {importResultReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-[28px] max-w-md w-full border border-slate-100 shadow-[0_20px_50px_rgba(0,0,0,0.15)] overflow-hidden text-right"
            dir="rtl"
          >
            {/* Modal Header */}
            {importResultReport && (importResultReport.includes("الصور المفقودة:") && !importResultReport.includes("الصور المفقودة: 0")) ? (
              <div className="bg-amber-50 border-b border-amber-100 p-5 flex gap-3 items-start">
                <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5 animate-pulse" />
                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-amber-900">تقرير استعادة النسخة الاحتياطية (تنبيه)</h3>
                  <p className="text-xs text-amber-800 font-semibold">
                    تمت استعادة البيانات بنجاح، ولكن توجد صور مفقودة غير موجودة في الأرشيف!
                  </p>
                </div>
              </div>
            ) : (
              <div className="bg-emerald-50 border-b border-emerald-100 p-5 flex gap-3 items-start">
                <ShieldCheck className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-emerald-900">تقرير استعادة النسخة الاحتياطية</h3>
                  <p className="text-xs text-emerald-800 font-semibold">
                    تمت استعادة كافة البيانات والملفات بنجاح تام بنسبة 100%!
                  </p>
                </div>
              </div>
            )}

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div className="bg-slate-50 rounded-2xl p-4 text-xs space-y-3 border border-slate-100 font-semibold text-slate-700 leading-relaxed">
                {importResultReport.split("\n").map((line, idx) => {
                  const colonIndex = line.indexOf(":");
                  if (colonIndex === -1) {
                    return <p key={idx} className="text-slate-800 font-extrabold text-center border-b border-slate-200/50 pb-2 last:border-b-0">{line}</p>;
                  }
                  const label = line.substring(0, colonIndex);
                  const val = line.substring(colonIndex + 1);
                  return (
                    <p key={idx} className="flex justify-between items-center py-1 border-b border-slate-200/50 last:border-b-0">
                      <span>{label}:</span>
                      <span className="font-extrabold text-[#0B1F3A] font-mono text-sm">{val}</span>
                    </p>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={() => setImportResultReport(null)}
                className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md active:scale-95"
              >
                <span>موافق، رائع!</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}
