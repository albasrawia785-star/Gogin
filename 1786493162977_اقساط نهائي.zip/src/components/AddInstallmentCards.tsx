import React, { useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  User,
  Phone,
  CreditCard,
  MapPin,
  Calendar,
  ShieldCheck,
  ShieldAlert,
  FileText,
  Sparkles,
  DollarSign,
  Wallet,
  TrendingUp,
  Camera,
  ChevronDown,
  PlusCircle,
  CheckCircle2,
  UserPlus
} from "lucide-react";
import branding from "../branding.json";
import { SearchableGovernorateDropdown, CompactDocumentRow } from "../App";

// Local helper functions for clean currency formatting/cleaning
export const cleanNumber = (val: string | number): number => {
  if (!val) return 0;
  if (typeof val === "number") return val;
  const cleaned = val.replace(/,/g, "");
  return parseFloat(cleaned) || 0;
};

export const formatNumber = (num: number): string => {
  return num.toLocaleString("en-US");
};

interface Customer {
  id: string;
  name: string;
  phone: string;
  status: "active" | "completed" | "delayed" | "inactive";
}

interface TopCardProps {
  customers: Customer[];
  onResetForm: () => void;
}

export function TopCard({ customers, onResetForm }: TopCardProps) {
  const activeCount = useMemo(() => {
    return customers.filter(c => c.status === "active").length;
  }, [customers]);

  return (
    <div className="bg-gradient-to-br from-[#0B1F3A] to-[#1E293B] rounded-[32px] p-6 text-white shadow-[0_15px_30px_rgba(15,23,42,0.1)] relative overflow-hidden" dir="rtl">
      {/* Ambient decorative circle */}
      <div className="absolute -top-12 -left-12 w-32 h-32 rounded-full bg-[#D4A44B]/10 blur-xl pointer-events-none" />
      
      <div className="relative z-10 flex flex-col gap-4">
        {/* Top Row: Shop Name and Program Title */}
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#D4A44B] animate-pulse" />
            <span className="text-xs font-black tracking-wide text-slate-300">نظام إدارة الأقساط الذكي</span>
          </div>
          <div className="bg-white/10 px-3 py-1 rounded-full border border-white/5">
            <span className="text-[10px] font-black text-[#D4A44B]">{branding.shopName}</span>
          </div>
        </div>
        
        {/* Info Row: User & Date */}
        <div className="grid grid-cols-2 gap-4 text-right">
          <div className="flex flex-col gap-0.5">
            <span className="text-[10px] text-slate-400 font-bold">المستخدم الحالي</span>
            <span className="text-xs font-black text-slate-200">👤 {branding.login.username === "admin" ? "المدير العام (admin)" : branding.login.username}</span>
          </div>
          <div className="flex flex-col gap-0.5 text-left">
            <span className="text-[10px] text-slate-400 font-bold">تاريخ اليوم</span>
            <span className="text-xs font-black text-slate-200">📅 {new Date().toLocaleDateString("ar-IQ", { year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
        </div>

        {/* Bottom Row: Active Installments Counter & Plus New Button */}
        <div className="flex justify-between items-center bg-white/5 p-3 rounded-2xl border border-white/5 mt-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#D4A44B]/20 flex items-center justify-center text-[#D4A44B]">
              <TrendingUp className="w-4.5 h-4.5" />
            </div>
            <div className="text-right">
              <span className="block text-[10px] text-slate-400 font-bold">الأقساط النشطة حالياً</span>
              <span className="block text-sm font-black text-white">{activeCount} قسط نشط</span>
            </div>
          </div>
          
          <button
            type="button"
            onClick={onResetForm}
            className="px-4 py-2 bg-[#D4A44B] hover:bg-[#C3933B] text-[#0B1F3A] text-xs font-black rounded-xl transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 shadow-md shadow-[#D4A44B]/15 border-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>قسط جديد</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface CompletionProgressBarProps {
  percentage: number;
}

export function CompletionProgressBar({ percentage }: CompletionProgressBarProps) {
  return (
    <div className="bg-white rounded-[24px] p-4.5 border border-slate-100 shadow-sm text-right animate-fade-in" dir="rtl">
      <div className="flex justify-between items-center mb-2">
        <span className="text-xs font-black text-slate-700">نسبة اكتمال إدخال البيانات</span>
        <span className="text-xs font-extrabold text-[#D4A44B] bg-[#D4A44B]/10 px-2.5 py-0.5 rounded-full">
          {percentage}%
        </span>
      </div>
      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
        <motion.div
          className="bg-gradient-to-r from-[#D4A44B] to-[#0B1F3A] h-full rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}

interface CustomerCardProps {
  custName: string;
  setCustName: (val: string) => void;
  custPhone: string;
  setCustPhone: (val: string) => void;
  custNationalId: string;
  setCustNationalId: (val: string) => void;
  custGovernorate: string;
  setCustGovernorate: (val: string) => void;
  custNearestLandmark: string;
  setCustNearestLandmark: (val: string) => void;
  custDateAdded: string;
  setCustDateAdded: (val: string) => void;
}

export function CustomerCard({
  custName,
  setCustName,
  custPhone,
  setCustPhone,
  custNationalId,
  setCustNationalId,
  custGovernorate,
  setCustGovernorate,
  custNearestLandmark,
  setCustNearestLandmark,
  custDateAdded,
  setCustDateAdded,
}: CustomerCardProps) {
  return (
    <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-4 text-right animate-fade-in" dir="rtl">
      <div className="flex items-center gap-2.5 text-[#0B1F3A] font-black border-b border-slate-100 pb-3">
        <div className="w-8 h-8 rounded-full bg-[#0B1F3A]/5 flex items-center justify-center text-[#D4A44B]">
          <User className="w-4.5 h-4.5" />
        </div>
        <div className="text-right">
          <span className="block text-sm font-black text-slate-800">بيانات صاحب القسط (العميل)</span>
          <span className="block text-[10px] text-slate-400 font-bold mt-0.5">المعلومات الشخصية وعنوان السكن</span>
        </div>
      </div>

      {/* الاسم الكامل */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>الاسم الثلاثي للعميل</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <User className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="text"
            required
            value={custName}
            onChange={(e) => setCustName(e.target.value)}
            className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
          />
        </div>
      </div>

      {/* رقم الهاتف */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>رقم الهاتف النشط (الواتساب)</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <Phone className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="tel"
            required
            maxLength={11}
            value={custPhone}
            onChange={(e) => setCustPhone(e.target.value.replace(/[^\d]/g, "").slice(0, 11))}
            className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold tracking-wide text-left text-slate-800 font-sans border-0"
          />
        </div>
      </div>

      {/* رقم البطاقة الوطنية */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>رقم البطاقة الوطنية لصاحب القسط</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <CreditCard className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="text"
            required
            maxLength={12}
            value={custNationalId}
            onChange={(e) => setCustNationalId(e.target.value.replace(/[^\d]/g, "").slice(0, 12))}
            className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
          />
        </div>
      </div>

      {/* المحافظة وأقرب نقطة دالة */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-right">
        <div className="relative flex flex-col gap-1 text-right">
          <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
            <span>المحافظة</span>
            <span className="text-rose-500">*</span>
          </label>
          <SearchableGovernorateDropdown
            value={custGovernorate}
            onChange={setCustGovernorate}
          />
        </div>

        <div className="relative flex flex-col gap-1 text-right">
          <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
            <span>أقرب نقطة دالة (العنوان تفصيلاً)</span>
            <span className="text-rose-500">*</span>
          </label>
          <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
            <div className="absolute right-4.5 text-slate-400 pointer-events-none">
              <MapPin className="w-4.5 h-4.5 text-slate-400" />
            </div>
            <input
              type="text"
              required
              value={custNearestLandmark}
              onChange={(e) => setCustNearestLandmark(e.target.value)}
              className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
            />
          </div>
        </div>
      </div>

      {/* تاريخ تسجيل المعاملة */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>تاريخ تسجيل البيع / المعاملة</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <Calendar className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="date"
            required
            value={custDateAdded}
            onChange={(e) => setCustDateAdded(e.target.value)}
            className="w-full pr-12 pl-4 py-3.5 bg-transparent outline-none text-sm font-semibold text-slate-800 text-right cursor-pointer border-0"
          />
        </div>
        <p className="text-[10px] text-slate-400 font-bold leading-relaxed mt-1 pr-1">
          يتم تعيين يوم السداد الشهري تلقائياً بناءً على تاريخ المعاملة (يوم {custDateAdded.split("-")[2] || "اليوم"}).
        </p>
      </div>
    </div>
  );
}

interface GuarantorCardProps {
  hasGuarantor: boolean;
  setHasGuarantor: (val: boolean) => void;
  guarantorName: string;
  setGuarantorName: (val: string) => void;
  guarantorPhone: string;
  setGuarantorPhone: (val: string) => void;
  guarantorNationalId: string;
  setGuarantorNationalId: (val: string) => void;
  guarantorGovernorate: string;
  setGuarantorGovernorate: (val: string) => void;
  guarantorNearestLandmark: string;
  setGuarantorNearestLandmark: (val: string) => void;
  onShowToast: (msg: string, type: "success" | "danger" | "info" | "warning") => void;
}

export function GuarantorCard({
  hasGuarantor,
  setHasGuarantor,
  guarantorName,
  setGuarantorName,
  guarantorPhone,
  setGuarantorPhone,
  guarantorNationalId,
  setGuarantorNationalId,
  guarantorGovernorate,
  setGuarantorGovernorate,
  guarantorNearestLandmark,
  setGuarantorNearestLandmark,
  onShowToast,
}: GuarantorCardProps) {
  return (
    <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-5 text-right animate-fade-in" dir="rtl">
      <div className="flex items-center gap-2.5 text-[#0B1F3A] font-black border-b border-slate-100 pb-3">
        <div className="w-8 h-8 rounded-full bg-[#0B1F3A]/5 flex items-center justify-center text-[#D4A44B]">
          <ShieldAlert className="w-4.5 h-4.5" />
        </div>
        <div className="text-right">
          <span className="block text-sm font-black text-slate-800">نوع الضمان والتوثيق للمبيعة</span>
          <span className="block text-[10px] text-slate-400 font-bold mt-0.5">تحديد ما إذا كانت المعاملة تتطلب كفيل ضامن</span>
        </div>
      </div>

      {/* Custom Polished Radio Buttons */}
      <div className="bg-slate-50/70 p-1.5 rounded-2xl border border-slate-150 flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => {
            setHasGuarantor(false);
            onShowToast("👤 تم اختيار إكمال المعاملة بدون كفيل", "info");
          }}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer border-0 ${
            !hasGuarantor
              ? "bg-[#0B1F3A] text-white shadow-md shadow-[#0B1F3A]/15 scale-[1.01]"
              : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/50"
          }`}
        >
          <User className="w-4 h-4" />
          <span>بدون كفيل</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setHasGuarantor(true);
            onShowToast("🛡️ تم تفعيل نموذج إضافة كفيل ضامن", "info");
          }}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer border-0 ${
            hasGuarantor
              ? "bg-[#0B1F3A] text-white shadow-md shadow-[#0B1F3A]/15 scale-[1.01]"
              : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/50"
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>وجود كفيل ضامن</span>
        </button>
      </div>

      {/* Guarantor Fields Form */}
      <AnimatePresence initial={false}>
        {hasGuarantor && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden space-y-4 pt-1"
          >
            {/* الاسم الكامل للكفيل */}
            <div className="relative flex flex-col gap-1 text-right">
              <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
                <span>الاسم الثلاثي للكفيل</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
                <div className="absolute right-4.5 text-slate-400 pointer-events-none">
                  <UserPlus className="w-4.5 h-4.5 text-slate-400" />
                </div>
                <input
                  type="text"
                  required={hasGuarantor}
                  value={guarantorName}
                  onChange={(e) => setGuarantorName(e.target.value)}
                  className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
                />
              </div>
            </div>

            {/* رقم هاتف الكفيل */}
            <div className="relative flex flex-col gap-1 text-right">
              <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
                <span>رقم هاتف الكفيل (الواتساب)</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
                <div className="absolute right-4.5 text-slate-400 pointer-events-none">
                  <Phone className="w-4.5 h-4.5 text-slate-400" />
                </div>
                <input
                  type="tel"
                  required={hasGuarantor}
                  maxLength={11}
                  value={guarantorPhone}
                  onChange={(e) => setGuarantorPhone(e.target.value.replace(/[^\d]/g, "").slice(0, 11))}
                  className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold tracking-wide text-left text-slate-800 font-sans border-0"
                />
              </div>
            </div>

            {/* رقم البطاقة الوطنية للكفيل */}
            <div className="relative flex flex-col gap-1 text-right">
              <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
                <span>رقم البطاقة الوطنية الموحدة للكفيل</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
                <div className="absolute right-4.5 text-slate-400 pointer-events-none">
                  <CreditCard className="w-4.5 h-4.5 text-slate-400" />
                </div>
                <input
                  type="text"
                  required={hasGuarantor}
                  value={guarantorNationalId}
                  onChange={(e) => setGuarantorNationalId(e.target.value.replace(/[^\d]/g, "").slice(0, 12))}
                  className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
                />
              </div>
            </div>

            {/* عنوان الكفيل */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-right">
              <div className="relative flex flex-col gap-1 text-right">
                <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
                  <span>محافظة الكفيل</span>
                  <span className="text-rose-500">*</span>
                </label>
                <SearchableGovernorateDropdown
                  value={guarantorGovernorate}
                  onChange={setGuarantorGovernorate}
                />
              </div>

              <div className="relative flex flex-col gap-1 text-right">
                <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
                  <span>أقرب نقطة دالة / عنوان الكفيل</span>
                  <span className="text-rose-500">*</span>
                </label>
                <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
                  <div className="absolute right-4.5 text-slate-400 pointer-events-none">
                    <MapPin className="w-4.5 h-4.5 text-slate-400" />
                  </div>
                  <input
                    type="text"
                    required={hasGuarantor}
                    value={guarantorNearestLandmark}
                    onChange={(e) => setGuarantorNearestLandmark(e.target.value)}
                    className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

interface ProductCardProps {
  prodName: string;
  setProdName: (val: string) => void;
  prodSerial: string;
  setProdSerial: (val: string) => void;
}

export function ProductCard({
  prodName,
  setProdName,
  prodSerial,
  setProdSerial,
}: ProductCardProps) {
  return (
    <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-4 text-right animate-fade-in" dir="rtl">
      <div className="flex items-center gap-2.5 text-[#0B1F3A] font-black border-b border-slate-100 pb-3">
        <div className="w-8 h-8 rounded-full bg-[#0B1F3A]/5 flex items-center justify-center text-[#D4A44B]">
          <FileText className="w-4.5 h-4.5" />
        </div>
        <div className="text-right">
          <span className="block text-sm font-black text-slate-800">بيانات وتفاصيل السلعة المباعة</span>
          <span className="block text-[10px] text-slate-400 font-bold mt-0.5">تسجيل مواصفات المادة لتوثيقها</span>
        </div>
      </div>

      {/* اسم السلعة */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>اسم السلعة المباعة</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <FileText className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="text"
            required
            value={prodName}
            onChange={(e) => setProdName(e.target.value)}
            className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
          />
        </div>
      </div>

      {/* تفاصيل المادة / الملاحظات */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>تفاصيل ومواصفات السلعة أو ملاحظات إضافية</span>
          <span className="text-slate-400 font-bold text-[10px] pr-1">(اختياري)</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <Sparkles className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="text"
            value={prodSerial}
            onChange={(e) => setProdSerial(e.target.value)}
            className="w-full h-full pr-12 pl-4 bg-transparent outline-none text-sm font-bold text-slate-800 text-right border-0"
          />
        </div>
      </div>
    </div>
  );
}

interface InstallmentCardProps {
  custTotalAmount: string;
  setCustTotalAmount: (val: string) => void;
  custUpfront: string;
  setCustUpfront: (val: string) => void;
  custMonthly: string;
  setCustMonthly: (val: string) => void;
  custDueDay: string;
  setCustDueDay: (val: string) => void;
  remainingVal: number;
  handleMoneyInputChange: (val: string, setter: (formatted: string) => void) => void;
}

export function InstallmentCard({
  custTotalAmount,
  setCustTotalAmount,
  custUpfront,
  setCustUpfront,
  custMonthly,
  setCustMonthly,
  custDueDay,
  setCustDueDay,
  remainingVal,
  handleMoneyInputChange,
}: InstallmentCardProps) {
  return (
    <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-4 text-right animate-fade-in" dir="rtl">
      <div className="flex items-center gap-2.5 text-[#0B1F3A] font-black border-b border-slate-100 pb-3">
        <div className="w-8 h-8 rounded-full bg-[#0B1F3A]/5 flex items-center justify-center text-[#D4A44B]">
          <DollarSign className="w-4.5 h-4.5" />
        </div>
        <div className="text-right">
          <span className="block text-sm font-black text-slate-800">حسابات المبالغ والأقساط</span>
          <span className="block text-[10px] text-slate-400 font-bold mt-0.5">الجدولة المالية وحساب القيمة المتبقية بالذمة</span>
        </div>
      </div>

      {/* السعر الكلي للسلعة */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>السعر الكلي للسلعة (دينار عراقي)</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <DollarSign className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="text"
            required
            value={custTotalAmount}
            onChange={(e) => handleMoneyInputChange(e.target.value, setCustTotalAmount)}
            className="w-full pr-12 pl-4 py-3.5 bg-transparent outline-none text-base font-black text-[#0B1F3A] text-right border-0"
          />
        </div>
      </div>

      {/* المقدمة والقسط الشهري */}
      <div className="grid grid-cols-2 gap-4 text-right">
        <div className="relative flex flex-col gap-1 text-right">
          <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
            <span>المقدمة المدفوعة</span>
            <span className="text-rose-500">*</span>
          </label>
          <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-emerald-500 focus-within:ring-4 focus-within:ring-emerald-500/5 transition-all duration-200 overflow-hidden">
            <div className="absolute right-4 text-emerald-500 pointer-events-none">
              <Wallet className="w-4 h-4 text-emerald-500" />
            </div>
            <input
              type="text"
              required
              value={custUpfront}
              onChange={(e) => handleMoneyInputChange(e.target.value, setCustUpfront)}
              className="w-full pr-11 pl-3 py-3.5 bg-transparent outline-none text-sm font-black text-emerald-600 text-right border-0"
            />
          </div>
        </div>

        <div className="relative flex flex-col gap-1 text-right">
          <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
            <span>القسط الشهري</span>
            <span className="text-rose-500">*</span>
          </label>
          <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-amber-500 focus-within:ring-4 focus-within:ring-amber-500/5 transition-all duration-200 overflow-hidden">
            <div className="absolute right-4 text-amber-500 pointer-events-none">
              <TrendingUp className="w-4 h-4 text-amber-500" />
            </div>
            <input
              type="text"
              required
              value={custMonthly}
              onChange={(e) => handleMoneyInputChange(e.target.value, setCustMonthly)}
              className="w-full pr-11 pl-3 py-3.5 bg-transparent outline-none text-sm font-black text-amber-600 text-right border-0"
            />
          </div>
        </div>
      </div>

      {/* يوم السداد الشهري المحدد */}
      <div className="relative flex flex-col gap-1 text-right">
        <label className="text-xs font-bold text-slate-500 flex items-center justify-end gap-1 mb-1 pr-1">
          <span>يوم السداد الشهري المحدد (تاريخ الاستحقاق)</span>
          <span className="text-rose-500">*</span>
        </label>
        <div className="relative flex items-center h-14 bg-[#F8FAFC]/55 border border-[#E8ECF2] rounded-[18px] focus-within:border-[#0B1F3A] focus-within:ring-4 focus-within:ring-[#0B1F3A]/5 transition-all duration-200 overflow-hidden">
          <div className="absolute right-4.5 text-slate-400 pointer-events-none">
            <Calendar className="w-4.5 h-4.5 text-slate-400" />
          </div>
          <input
            type="number"
            required
            min="1"
            max="31"
            value={custDueDay}
            onChange={(e) => setCustDueDay(e.target.value)}
            className="w-full pr-12 pl-4 py-3.5 bg-transparent outline-none text-sm font-semibold text-slate-800 text-right border-0"
          />
        </div>
      </div>

      {/* receipt receipt details */}
      <div className="p-4 bg-[#FDF8F8] rounded-[20px] border border-red-50/50 flex flex-col gap-1 text-right" dir="rtl">
        <div className="flex justify-between items-center">
          <span className="text-xs font-black text-slate-600">المبلغ المتبقي في الذمة:</span>
          <span className="text-lg font-black text-rose-600">{formatNumber(remainingVal)} د.ع</span>
        </div>
        {remainingVal > 0 && cleanNumber(custMonthly) > 0 && (
          <div className="text-[10px] text-slate-400 font-bold leading-relaxed mt-1 border-t border-red-100/50 pt-1.5 flex items-center gap-1">
            <span>⚠️</span>
            <span>سيتم سداد هذا الدين على شكل أقساط شهرية متساوية، قيمة كل قسط هي <strong>{formatNumber(cleanNumber(custMonthly))} د.ع</strong>.</span>
          </div>
        )}
      </div>
    </div>
  );
}

interface AttachmentsCardProps {
  hasGuarantor: boolean;
  images: Record<string, string>;
  guarantorImages: Record<string, string>;
  customerDocsExpanded: boolean;
  setCustomerDocsExpanded: (val: boolean | ((p: boolean) => boolean)) => void;
  guarantorDocsExpanded: boolean;
  setGuarantorDocsExpanded: (val: boolean | ((p: boolean) => boolean)) => void;
  handleDirectCustomerUpload: (key: string, file: File) => void;
  handleDirectGuarantorUpload: (key: string, file: File) => void;
  setImages: (val: any) => void;
  setGuarantorImages: (val: any) => void;
  setPreviewImageSrc: (src: string) => void;
  compressingKeys: string[];
}

export function AttachmentsCard({
  hasGuarantor,
  images,
  guarantorImages,
  customerDocsExpanded,
  setCustomerDocsExpanded,
  guarantorDocsExpanded,
  setGuarantorDocsExpanded,
  handleDirectCustomerUpload,
  handleDirectGuarantorUpload,
  setImages,
  setGuarantorImages,
  setPreviewImageSrc,
  compressingKeys,
}: AttachmentsCardProps) {
  const custUploadedCount = useMemo(() => {
    return Object.values(images).filter(Boolean).length;
  }, [images]);

  const guarUploadedCount = useMemo(() => {
    return Object.values(guarantorImages).filter(Boolean).length;
  }, [guarantorImages]);

  return (
    <div className="bg-white rounded-[20px] p-6 border border-[#E8ECF2] shadow-[0_10px_30px_rgba(11,31,58,0.03)] space-y-4 text-right animate-fade-in" dir="rtl">
      <div className="flex items-center gap-2.5 text-[#0B1F3A] font-black border-b border-slate-100 pb-3">
        <div className="w-8 h-8 rounded-full bg-[#0B1F3A]/5 flex items-center justify-center text-[#D4A44B]">
          <Camera className="w-4.5 h-4.5" />
        </div>
        <div className="text-right">
          <span className="block text-sm font-black text-slate-800">الوثائق والمستمسكات الرسمية المرفقة</span>
          <span className="block text-[10px] text-slate-400 font-bold mt-0.5">رفع البطاقة الموحدة وبطاقة السكن وصورة العميل</span>
        </div>
      </div>

      {/* Customer documents accordion */}
      <div className="space-y-2">
        <button
          type="button"
          onClick={() => setCustomerDocsExpanded(prev => !prev)}
          className="w-full flex items-center justify-between p-3.5 bg-slate-50/70 hover:bg-slate-100/80 rounded-2xl border border-slate-200/80 transition-all cursor-pointer group border-0"
        >
          <div className="flex items-center gap-2">
            <Camera className="w-4.5 h-4.5 text-[#D4A44B] group-hover:scale-110 transition-transform" />
            <span className="text-xs font-black text-[#0B1F3A]">📸 مستمسكات صاحب القسط (العميل)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] bg-[#0B1F3A]/5 text-[#0B1F3A] px-2.5 py-0.5 rounded-full font-black">
              {custUploadedCount} / 5
            </span>
            <ChevronDown className={`w-4 h-4 text-[#0B1F3A] transition-transform duration-300 ${customerDocsExpanded ? "rotate-180" : ""}`} />
          </div>
        </button>

        <AnimatePresence initial={false}>
          {customerDocsExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <CompactDocumentRow
                type="customer"
                images={images}
                onUploadClick={(key: string, file: File) => handleDirectCustomerUpload(key, file)}
                onRemoveClick={(key: string) => {
                  setImages((prev: any) => ({ ...prev, [key]: "" }));
                }}
                onPreviewClick={(src: string) => setPreviewImageSrc(src)}
                compressingKeys={compressingKeys}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Guarantor documents accordion */}
      {hasGuarantor && (
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={() => setGuarantorDocsExpanded(prev => !prev)}
            className="w-full flex items-center justify-between p-3.5 bg-slate-50/70 hover:bg-slate-100/80 rounded-2xl border border-slate-200/80 transition-all cursor-pointer group border-0"
          >
            <div className="flex items-center gap-2">
              <Camera className="w-4.5 h-4.5 text-[#D4A44B] group-hover:scale-110 transition-transform" />
              <span className="text-xs font-black text-[#0B1F3A]">🛡️ مستمسكات الكفيل الضامن</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] bg-[#0B1F3A]/5 text-[#0B1F3A] px-2.5 py-0.5 rounded-full font-black">
                {guarUploadedCount} / 5
              </span>
              <ChevronDown className={`w-4 h-4 text-[#0B1F3A] transition-transform duration-300 ${guarantorDocsExpanded ? "rotate-180" : ""}`} />
            </div>
          </button>

          <AnimatePresence initial={false}>
            {guarantorDocsExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <CompactDocumentRow
                  type="guarantor"
                  images={guarantorImages}
                  onUploadClick={(key: string, file: File) => handleDirectGuarantorUpload(key, file)}
                  onRemoveClick={(key: string) => {
                    setGuarantorImages((prev: any) => ({ ...prev, [key]: "" }));
                  }}
                  onPreviewClick={(src: string) => setPreviewImageSrc(src)}
                  compressingKeys={compressingKeys}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
