export interface HistoryItem {
  id: number;
  type: 'DEBT' | 'PAYMENT';
  amount: number;
  date: string;
  note: string;
}

export interface Customer {
  id: string;
  name: string;
  avatarText?: string;
  phone?: string;
  debt: number;
  totalAdded?: number;
  totalPaid?: number;
  overdueDays?: number;
  lastDate?: string;
  lastTimestamp?: number;
  avatarBg?: string;
  createdAt?: any;
  history?: HistoryItem[];
}

export interface User {
  id: string;
  username: string;
  role: 'مدير عام' | 'مدير فرعي' | 'حساب تجريبي';
  isTrial?: boolean;
  expiresAt?: number;
}

export interface SubManager {
  id: string;
  username?: string;
  password?: string;
  role?: string;
  createdBy?: string;
  createdAt?: string;
}

export interface TrialAccount {
  id: string;
  username: string;
  password?: string;
  expiresAt: number;
  createdAt?: any;
  isDisabled?: boolean;
}
