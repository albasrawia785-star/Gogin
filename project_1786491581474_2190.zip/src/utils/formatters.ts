import { Customer } from '../types';

/**
 * Format numbers with thousand separators (e.g. 100000 -> "100,000")
 */
export const formatNumberWithCommas = (val: string | number | undefined | null): string => {
  if (val === undefined || val === null || val === '') return '';
  const cleanVal = val.toString().replace(/,/g, '');
  if (isNaN(Number(cleanVal))) return '';
  const parts = cleanVal.split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return parts.join('.');
};

/**
 * Parse string with commas back into a number
 */
export const parseRawNumber = (formattedVal: string | number | undefined | null): number => {
  if (!formattedVal) return 0;
  const cleanVal = formattedVal.toString().replace(/,/g, '');
  const parsed = parseFloat(cleanVal);
  return isNaN(parsed) ? 0 : parsed;
};

/**
 * Format Iraqi phone numbers to standard international format for WhatsApp API link
 */
export const formatIraqiPhoneForWhatsApp = (phone: string): string => {
  if (!phone) return '';
  const clean = phone.replace(/[^0-9]/g, '');
  if (clean.startsWith('07') && clean.length === 11) return '964' + clean.substring(1);
  if (clean.startsWith('7') && clean.length === 10) return '964' + clean;
  if (clean.startsWith('00964')) return clean.substring(2);
  if (clean.startsWith('964')) return clean;
  return clean;
};

/**
 * Calculate overdue days accurately based on last transaction timestamp or creation date
 */
export const getCustomerOverdueDays = (c: Customer): number => {
  if (typeof c.lastTimestamp === 'number' && c.lastTimestamp > 0) {
    const diffMs = Date.now() - c.lastTimestamp;
    return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  }

  if (c.createdAt) {
    let ts: number | null = null;
    if (typeof c.createdAt.toDate === 'function') {
      ts = c.createdAt.toDate().getTime();
    } else if (typeof c.createdAt.seconds === 'number') {
      ts = c.createdAt.seconds * 1000;
    } else if (typeof c.createdAt === 'string') {
      const parsed = new Date(c.createdAt).getTime();
      if (!isNaN(parsed)) ts = parsed;
    }
    if (ts) {
      const diffMs = Date.now() - ts;
      return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
    }
  }

  return c.overdueDays || 0;
};
