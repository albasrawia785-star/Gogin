import { initializeApp, getApps } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs,
  where,
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  serverTimestamp 
} from "firebase/firestore";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updatePassword as firebaseUpdatePassword,
  User as FirebaseUser
} from "firebase/auth";

// ============================================================================
// 📍 إعدادات مشروع فايربيس السحابي (Firebase Config)
// ============================================================================

export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBJaO_j_Q-zFZ6v6dOy1rzICUamCBpilBs",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "vpngs-c9bb5.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "vpngs-c9bb5",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "vpngs-c9bb5.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "894664321700",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:894664321700:web:f4d1b59a51ed1bba6ad431"
};

// ============================================================================
// 🚀 تهيئة خدمات فايربيس (Auth & Firestore)
// ============================================================================

// 1. تطبيق Firebase الرئيسي
export const app = initializeApp(firebaseConfig);

// 2. قاعدة البيانات Firestore
export const db = getFirestore(app);

// 3. خدمة المصادقة والأمان Firebase Auth
export const auth = getAuth(app);

// 4. تطبيق ثانوي لإنشاء حسابات المدراء الفرعيين دون تسجيل خروج المدير العام
export function getSecondaryAuth() {
  const secondaryApp = getApps().find(a => a.name === 'SecondaryApp') || initializeApp(firebaseConfig, 'SecondaryApp');
  return getAuth(secondaryApp);
}

// تحويل اسم المستخدم إلى بريد إلكتروني قياسي لمصادقة Firebase
export function usernameToEmail(usernameInput: string): string {
  const cleaned = usernameInput.trim().toLowerCase();
  if (cleaned.includes('@')) {
    return cleaned;
  }
  return `${cleaned}@debtbook.internal`;
}

// ============================================================================
// 🛡️ معالج أخطاء وأمان قواعد البيانات
// ============================================================================

export enum FirestoreOpType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  READ = 'read',
}

export function handleFirestoreError(error: unknown, opType: FirestoreOpType, collectionPath: string) {
  const isPermissionError = error instanceof Error && (
    error.message.includes('permission-denied') || 
    error.message.includes('Missing or insufficient permissions')
  );

  if (isPermissionError) {
    console.error(`[Security Guard] Access denied on path: ${collectionPath} (${opType})`);
    throw new Error('عفواً، ليس لديك الصلاحية الكافية للوصول إلى هذه البيانات أو تعديلها.');
  }

  console.error(`[Database Error] Operation ${opType} failed on ${collectionPath}:`, error);
  throw error;
}

// 5. تصدير الأدوات المستخدمة في التطبيق
export {
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs,
  where,
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  serverTimestamp,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  firebaseUpdatePassword
};
export type { FirebaseUser };



