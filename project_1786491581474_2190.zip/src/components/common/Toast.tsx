import React from 'react';

interface ToastProps {
  message: string | null;
}

export const Toast: React.FC<ToastProps> = ({ message }) => {
  if (!message) return null;

  return (
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-slate-100 text-xs font-bold px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 border border-slate-700/50 transition-all animate-in fade-in slide-in-from-top-2">
      <i className="fa-solid fa-circle-check text-emerald-400 text-sm"></i>
      <span>{message}</span>
    </div>
  );
};
