import React from 'react';
import { User } from '../../types';

interface HeaderProps {
  currentUser: User;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentUser, onLogout }) => {
  return (
    <header className="flex items-center justify-between pb-3.5 border-b border-slate-200/80 mb-4 select-none">
      {/* Right side: Brand identity & User profile */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-teal-500 text-white font-extrabold text-sm flex items-center justify-center shrink-0 shadow-md shadow-blue-500/20">
          {currentUser.username ? currentUser.username.slice(0, 2).toUpperCase() : 'د'}
        </div>
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <h1 className="font-extrabold text-slate-900 text-sm tracking-tight">
              {currentUser.username}
            </h1>
            <span className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-200/80 shadow-2xs">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              سحابي نشط
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            {currentUser.isTrial ? 'حساب تجريبي' : currentUser.role} <span className="text-slate-300">•</span> دفتر ديوني
          </p>
        </div>
      </div>
    </header>
  );
};


