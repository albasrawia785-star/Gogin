import React from 'react';

export type NavTab = 'main' | 'reports' | 'overdue' | 'settings';

interface NavigationProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  overdueCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  overdueCount
}) => {
  return (
    <nav className="fixed bottom-3 left-1/2 -translate-x-1/2 w-[92%] max-w-md bg-white/95 backdrop-blur-md text-slate-800 border border-slate-200/90 px-3 py-2 rounded-2xl flex justify-around items-center z-40 select-none shadow-[0_10px_25px_-5px_rgba(15,23,42,0.1)]">
      <button
        type="button"
        onClick={() => setActiveTab('main')}
        className={`flex items-center gap-2 transition-all cursor-pointer py-2 px-3.5 rounded-xl ${
          activeTab === 'main'
            ? 'bg-blue-600 text-white font-extrabold shadow-md shadow-blue-500/20 scale-[1.02]'
            : 'text-slate-500 hover:text-blue-600 font-bold'
        }`}
      >
        <i className="fa-solid fa-house text-xs"></i>
        <span className="text-xs">الرئيسية</span>
      </button>

      <button
        type="button"
        onClick={() => setActiveTab('reports')}
        className={`flex items-center gap-2 transition-all cursor-pointer py-2 px-3.5 rounded-xl ${
          activeTab === 'reports'
            ? 'bg-blue-600 text-white font-extrabold shadow-md shadow-blue-500/20 scale-[1.02]'
            : 'text-slate-500 hover:text-blue-600 font-bold'
        }`}
      >
        <i className="fa-solid fa-chart-pie text-xs"></i>
        <span className="text-xs">التقارير</span>
      </button>

      <button
        type="button"
        onClick={() => setActiveTab('overdue')}
        className={`flex items-center gap-2 transition-all cursor-pointer py-2 px-3.5 rounded-xl relative ${
          activeTab === 'overdue'
            ? 'bg-blue-600 text-white font-extrabold shadow-md shadow-blue-500/20 scale-[1.02]'
            : 'text-slate-500 hover:text-blue-600 font-bold'
        }`}
      >
        <div className="relative">
          <i className="fa-solid fa-clock-rotate-left text-xs"></i>
          {overdueCount > 0 && (
            <span className="absolute -top-2 -right-2.5 min-w-[16px] h-4 px-1 bg-rose-600 text-white text-[9px] font-black rounded-full flex items-center justify-center border-2 border-white animate-pulse">
              {overdueCount}
            </span>
          )}
        </div>
        <span className="text-xs">المتأخرون</span>
      </button>

      <button
        type="button"
        onClick={() => setActiveTab('settings')}
        className={`flex items-center gap-2 transition-all cursor-pointer py-2 px-3.5 rounded-xl ${
          activeTab === 'settings'
            ? 'bg-blue-600 text-white font-extrabold shadow-md shadow-blue-500/20 scale-[1.02]'
            : 'text-slate-500 hover:text-blue-600 font-bold'
        }`}
      >
        <i className="fa-solid fa-sliders text-xs"></i>
        <span className="text-xs">الإعدادات</span>
      </button>
    </nav>
  );
};


