import React, { useState, useEffect } from 'react';
import { Customer } from '../../types';
import { formatNumberWithCommas, parseRawNumber } from '../../utils/formatters';

interface CustomerModalProps {
  isOpen: boolean;
  mode: 'ADD' | 'EDIT';
  customer?: Customer | null;
  onClose: () => void;
  onSubmitAdd: (name: string, phone: string, initialDebt: number) => Promise<void>;
  onSubmitEdit: (id: string, name: string, phone: string) => Promise<void>;
}

export const CustomerModal: React.FC<CustomerModalProps> = ({
  isOpen,
  mode,
  customer,
  onClose,
  onSubmitAdd,
  onSubmitEdit,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [debtFormatted, setDebtFormatted] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (mode === 'EDIT' && customer) {
      setName(customer.name || '');
      setPhone(customer.phone || '');
      setDebtFormatted('');
    } else {
      setName('');
      setPhone('');
      setDebtFormatted('');
    }
    setErrorMsg('');
  }, [mode, customer, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('اسم المدين مطلوب');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    try {
      if (mode === 'ADD') {
        const initialDebt = parseRawNumber(debtFormatted);
        await onSubmitAdd(name.trim(), phone.trim(), initialDebt);
      } else if (mode === 'EDIT' && customer) {
        await onSubmitEdit(customer.id, name.trim(), phone.trim());
      }
      onClose();
    } catch (err) {
      setErrorMsg('حدث خطأ أثناء حفظ البيانات سحابياً.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h2 className="font-extrabold text-slate-900 text-base">
            {mode === 'ADD' ? 'إضافة مدين جديد' : `تعديل بيانات: ${customer?.name}`}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-extrabold text-slate-700 mb-1.5">
              اسم المدين <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="أدخل الاسم الثلاثي أو اسم المحل..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-slate-300/80 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-400"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="block text-xs font-extrabold text-slate-700">
                رقم الهاتف (اختياري)
              </label>
              <span className="text-[11px] text-slate-400 font-bold" dir="ltr">
                {phone.length} / 11
              </span>
            </div>
            <input
              type="tel"
              placeholder="07XXXXXXXXX"
              maxLength={11}
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/[^0-9]/g, ''))}
              className="w-full px-3.5 py-2.5 border border-slate-300/80 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-400"
              dir="ltr"
            />
          </div>

          {mode === 'ADD' && (
            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1.5">
                الدين الأولي (د.ع)
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="0"
                  value={debtFormatted}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => setDebtFormatted(formatNumberWithCommas(e.target.value))}
                  className="w-full pl-12 pr-3.5 py-2.5 border border-slate-300/80 rounded-xl text-base font-black text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-400"
                />
                <span className="absolute left-3 top-3 text-xs font-bold text-slate-400">د.ع</span>
              </div>
            </div>
          )}

          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200/80 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-blue-500/20 active:scale-95 flex items-center justify-center gap-2"
            >
              {isSubmitting && <i className="fa-solid fa-circle-notch animate-spin"></i>}
              <span>{mode === 'ADD' ? 'حفظ المدين' : 'حفظ التعديلات'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
