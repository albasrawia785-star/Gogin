import React, { useState, useEffect } from 'react';
import { Customer } from '../../types';
import { formatNumberWithCommas, parseRawNumber } from '../../utils/formatters';

interface TransactionModalProps {
  isOpen: boolean;
  type: 'ADD_DEBT' | 'PAYMENT' | null;
  customer: Customer | null;
  onClose: () => void;
  onSubmit: (customer: Customer, amount: number, type: 'ADD_DEBT' | 'PAYMENT') => Promise<void>;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  type,
  customer,
  onClose,
  onSubmit,
}) => {
  const [amountFormatted, setAmountFormatted] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    setAmountFormatted('');
    setErrorMsg('');
  }, [isOpen, type, customer]);

  if (!isOpen || !type || !customer) return null;

  const isPayment = type === 'PAYMENT';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseRawNumber(amountFormatted);

    if (!amount || amount <= 0) {
      setErrorMsg('يرجى إدخال مبلغ صحيح أكبر من صفر');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    try {
      await onSubmit(customer, amount, type);
      onClose();
    } catch (err) {
      setErrorMsg('حدث خطأ أثناء إجراء العملية سحابياً.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-slate-200/80 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3.5">
          <div>
            <h2 className="font-black text-slate-900 text-base">
              {isPayment ? 'تسديد دفعة حساب' : 'إضافة دين جديد'}
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              اسم المدين: <span className="font-extrabold text-slate-900">{customer.name}</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Current Balance Reminder */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-500">الدين الحالي المستحق</span>
          <span className="text-base font-black text-slate-900">
            {formatNumberWithCommas(customer.debt || 0)} <span className="text-xs font-extrabold text-slate-400">د.ع</span>
          </span>
        </div>

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-extrabold text-slate-700 mb-1.5">
              المبلغ (د.ع) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                autoFocus
                placeholder="0"
                value={amountFormatted}
                onFocus={(e) => e.target.select()}
                onChange={(e) => setAmountFormatted(formatNumberWithCommas(e.target.value))}
                className="w-full pl-12 pr-3.5 py-2.5 border border-slate-300/80 rounded-xl text-base font-black text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-400"
              />
              <span className="absolute left-3.5 top-3 text-xs font-bold text-slate-400">د.ع</span>
            </div>
          </div>

          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 bg-slate-100 hover:bg-slate-200/80 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 py-3 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-sm flex items-center justify-center gap-2 text-white active:scale-95 ${
                isPayment ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20'
              }`}
            >
              {isSubmitting && <i className="fa-solid fa-circle-notch animate-spin"></i>}
              <span>{isPayment ? 'تأكيد التسديد' : 'إضافة الدين'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
