import React from 'react';
import { Customer } from '../../types';
import { formatNumberWithCommas } from '../../utils/formatters';

interface StatementModalProps {
  isOpen: boolean;
  customer: Customer | null;
  onClose: () => void;
  onSendWhatsApp: (customer: Customer) => void;
}

export const StatementModal: React.FC<StatementModalProps> = ({
  isOpen,
  customer,
  onClose,
  onSendWhatsApp,
}) => {
  if (!isOpen || !customer) return null;

  const history = customer.history || [];

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 border border-slate-200 shadow-xl space-y-5 max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 shrink-0">
          <div>
            <h2 className="font-extrabold text-slate-900 text-base">كشف حساب التفصيلي</h2>
            <p className="text-xs text-slate-500 font-bold mt-0.5">{customer.name}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Financial Summary Box */}
        <div className="grid grid-cols-3 gap-2 bg-slate-50 border border-slate-200/80 p-3 rounded-xl shrink-0 text-center select-none">
          <div>
            <span className="text-[10px] font-bold text-slate-500 block">إجمالي المضاف</span>
            <span className="text-xs font-black text-rose-600 block mt-0.5">
              {formatNumberWithCommas(customer.totalAdded || customer.debt || 0)}
            </span>
          </div>
          <div className="border-r border-l border-slate-200/80 px-1">
            <span className="text-[10px] font-bold text-slate-500 block">إجمالي المسدد</span>
            <span className="text-xs font-black text-emerald-600 block mt-0.5">
              {formatNumberWithCommas(customer.totalPaid || 0)}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-500 block">المتبقي المطلوب</span>
            <span className="text-xs font-black text-slate-900 block mt-0.5">
              {formatNumberWithCommas(customer.debt || 0)}
            </span>
          </div>
        </div>

        {/* History Timeline */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {history.length === 0 ? (
            <div className="text-center py-10 text-slate-400 font-bold text-xs">
              لا توجد حركة مسجلة لهذا الحساب
            </div>
          ) : (
            history.map((item) => {
              const isPayment = item.type === 'PAYMENT';
              return (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200/80 bg-white hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-[10px] shrink-0 ${
                        isPayment ? 'bg-emerald-50 text-emerald-600 border border-emerald-200/80' : 'bg-rose-50 text-rose-600 border border-rose-200/80'
                      }`}
                    >
                      <i className={`fa-solid ${isPayment ? 'fa-arrow-down' : 'fa-plus'}`}></i>
                    </div>
                    <div>
                      <div className="text-xs font-extrabold text-slate-900">
                        {item.note || (isPayment ? 'دفعة تسديد' : 'إضافة دين')}
                      </div>
                      <div className="text-[10px] font-medium text-slate-400 mt-0.5">
                        {item.date}
                      </div>
                    </div>
                  </div>

                  <div className={`text-xs font-black ${isPayment ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {isPayment ? '-' : '+'}{formatNumberWithCommas(item.amount)} <span className="text-[10px] font-bold text-slate-400">د.ع</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Actions Footer */}
        <div className="pt-2 border-t border-slate-100 flex gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onSendWhatsApp(customer)}
            className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
          >
            <i className="fa-brands fa-whatsapp text-sm"></i>
            <span>إرسال عبر الواتساب</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200/80 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
