import React, { useState } from 'react';
import { db, doc, setDoc, serverTimestamp } from '../../firebase';
import { formatIraqiPhoneForWhatsApp } from '../../utils/formatters';

interface CreateAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAutoLogin: (username: string, pass: string) => Promise<boolean>;
  triggerToast: (msg: string) => void;
}

export const CreateAccountModal: React.FC<CreateAccountModalProps> = ({
  isOpen,
  onClose,
  onAutoLogin,
  triggerToast,
}) => {
  const [activeTab, setActiveTab] = useState<'TRIAL' | 'PERMANENT'>('TRIAL');
  const [isCreatingTrial, setIsCreatingTrial] = useState(false);
  const [createdCredentials, setCreatedCredentials] = useState<{
    username: string;
    pass: string;
    expiresAt: number;
  } | null>(null);

  if (!isOpen) return null;

  const phoneFormatted = formatIraqiPhoneForWhatsApp('07810936407');
  const permanentMsg = encodeURIComponent('السلام عليكم، أريد إنشاء حساب دائم في تطبيق دفتر ديوني.');
  const whatsappUrl = `https://wa.me/${phoneFormatted}?text=${permanentMsg}`;

  // Rate Limiting helper (Max 3 trial creations per hour per device)
  const checkRateLimit = (): boolean => {
    try {
      const historyStr = localStorage.getItem('debt_trial_creations');
      const history: number[] = historyStr ? JSON.parse(historyStr) : [];
      const now = Date.now();
      const oneHourAgo = now - 3600000;
      const recentCreations = history.filter((ts) => ts > oneHourAgo);

      if (recentCreations.length >= 3) {
        return false;
      }
      return true;
    } catch (e) {
      return true;
    }
  };

  const recordTrialCreation = () => {
    try {
      const historyStr = localStorage.getItem('debt_trial_creations');
      const history: number[] = historyStr ? JSON.parse(historyStr) : [];
      const now = Date.now();
      const oneHourAgo = now - 3600000;
      const recent = history.filter((ts) => ts > oneHourAgo);
      recent.push(now);
      localStorage.setItem('debt_trial_creations', JSON.stringify(recent));
    } catch (e) {
      console.warn('Could not record trial creation rate limit', e);
    }
  };

  const handleCreateTrial = () => {
    setIsCreatingTrial(true);
    try {
      // Generate random username & password
      const randomDigits = Math.floor(10000 + Math.random() * 90000);
      const generatedUsername = `demo_${randomDigits}`;
      const generatedPass = `${Math.floor(100000 + Math.random() * 900000)}`;
      const expiresAt = Date.now() + 3600000; // 1 hour (60 minutes)

      // Background write to Firestore (completely non-blocking)
      setDoc(doc(db, 'users', generatedUsername), {
        username: generatedUsername,
        password: generatedPass,
        role: 'حساب تجريبي',
        isTrial: true,
        expiresAt,
        createdAt: Date.now(),
      }).catch((err) => console.warn('Background trial save info:', err));

      recordTrialCreation();

      // Show created credentials instantly
      setCreatedCredentials({
        username: generatedUsername,
        pass: generatedPass,
        expiresAt,
      });

      triggerToast('تم إنشاء الحساب التجريبي بنجاح لمدة 60 دقيقة');
    } catch (err) {
      console.error('Trial account creation error:', err);
    } finally {
      setIsCreatingTrial(false);
    }
  };

  const handleCopyCredentials = () => {
    if (!createdCredentials) return;
    const textToCopy = `اسم المستخدم: ${createdCredentials.username}\nكلمة المرور: ${createdCredentials.pass}`;
    navigator.clipboard.writeText(textToCopy).then(
      () => triggerToast('تم نسخ بيانات الدخول إلى الحافظة!'),
      () => triggerToast('تعذر النسخ تلقائياً، يرجى نسخ البيانات يدوياً')
    );
  };

  const handleDirectLogin = async () => {
    if (!createdCredentials) return;
    setIsCreatingTrial(true);
    try {
      const success = await onAutoLogin(createdCredentials.username, createdCredentials.pass);
      if (success) {
        onClose();
      } else {
        triggerToast('تعذر تسجيل الدخول التلقائي، يرجى كتابة البيانات يدوياً');
      }
    } catch (e) {
      triggerToast('حدث خطأ أثناء تسجيل الدخول');
    } finally {
      setIsCreatingTrial(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 select-none dir-rtl" dir="rtl">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              <i className="fa-solid fa-user-plus"></i>
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">إنشاء حساب جديد</h3>
              <p className="text-[11px] text-slate-500 font-normal">اختر نوع الحساب المناسب لاحتياجاتك</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        {/* Tab Selection */}
        <div className="p-3 bg-slate-100/60 border-b border-slate-100 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('TRIAL')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'TRIAL'
                ? 'bg-white text-indigo-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
            }`}
          >
            <i className="fa-solid fa-bolt text-amber-500 text-xs"></i>
            <span>حساب تجريبي (ساعة)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PERMANENT')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'PERMANENT'
                ? 'bg-white text-emerald-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
            }`}
          >
            <i className="fa-brands fa-whatsapp text-emerald-600 text-xs"></i>
            <span>حساب دائم (واتساب)</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 space-y-4">
          {activeTab === 'TRIAL' && (
            <div className="space-y-4">
              
              {!createdCredentials ? (
                <>
                  <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-3.5 space-y-2 text-xs">
                    <div className="flex items-center gap-2 font-bold text-amber-900">
                      <i className="fa-solid fa-clock-rotate-left text-amber-600"></i>
                      <span>مميزات الحساب التجريبي:</span>
                    </div>
                    <ul className="text-amber-800 space-y-1.5 pr-4 list-disc text-[11px] leading-relaxed">
                      <li>توليد اسم مستخدم وكلمة مرور تلقائياً بشكل فوري.</li>
                      <li>مدة الحساب <strong>ساعة واحدة فقط (60 دقيقة)</strong> مع عداد تنازلي live.</li>
                      <li>صلاحيات كاملة لتجربة إضافة الديون، الزبناء، والتقارير.</li>
                      <li>ينتهي الحساب ويُغلق تلقائياً بعد انقضاء الوقت المحدد.</li>
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={handleCreateTrial}
                    disabled={isCreatingTrial}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer active:scale-98 disabled:opacity-60"
                  >
                    {isCreatingTrial ? (
                      <>
                        <i className="fa-solid fa-circle-notch animate-spin text-xs"></i>
                        <span>جاري إنشاء الحساب التجريبي...</span>
                      </>
                    ) : (
                      <>
                        <i className="fa-solid fa-bolt text-amber-300"></i>
                        <span>إنشاء حساب تجريبي فوري (60 دقيقة)</span>
                      </>
                    )}
                  </button>
                </>
              ) : (
                <div className="space-y-3.5 animate-in fade-in duration-200">
                  <div className="bg-emerald-50 border border-emerald-200/80 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
                      <span className="flex items-center gap-1.5">
                        <i className="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                        تم إنشاء الحساب التجريبي بنجاح!
                      </span>
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md text-[10px] font-extrabold border border-emerald-200">
                        صلاحية: 60 دقيقة
                      </span>
                    </div>

                    <div className="space-y-2 bg-white rounded-lg p-3 border border-emerald-100 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-normal">اسم المستخدم:</span>
                        <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-xs select-all">
                          {createdCredentials.username}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-normal">كلمة المرور:</span>
                        <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-xs select-all">
                          {createdCredentials.pass}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyCredentials}
                      className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 border border-slate-200 transition-colors cursor-pointer"
                    >
                      <i className="fa-regular fa-copy text-xs"></i>
                      <span>نسخ البيانات</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleDirectLogin}
                      disabled={isCreatingTrial}
                      className="py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-blue-500/20 transition-all cursor-pointer active:scale-98 disabled:opacity-60"
                    >
                      {isCreatingTrial ? (
                        <i className="fa-solid fa-circle-notch animate-spin text-xs"></i>
                      ) : (
                        <i className="fa-solid fa-right-to-bracket text-xs"></i>
                      )}
                      <span>تسجيل الدخول الآن</span>
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

          {activeTab === 'PERMANENT' && (
            <div className="space-y-4">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2.5 text-xs">
                <div className="flex items-center gap-2 font-bold text-slate-900">
                  <i className="fa-solid fa-shield-halved text-emerald-600"></i>
                  <span>الحساب الدائم السحابي:</span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  لإنشاء حساب دائم، آمن، وغير محدود الزمن مع حفظ جميع بياناتك وسجلاتك سحابياً، يرجى التواصل معنا مباشرة عبر واتساب لتفعيل حسابك الشخصي.
                </p>
              </div>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer active:scale-98"
              >
                <i className="fa-brands fa-whatsapp text-lg"></i>
                <span>التواصل عبر واتساب للتفعيل</span>
              </a>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/50 text-center">
          <p className="text-[11px] text-slate-500 font-normal">
            تطبيق دفتر ديوني • جميع الحقوق محفوظة
          </p>
        </div>

      </div>
    </div>
  );
};
