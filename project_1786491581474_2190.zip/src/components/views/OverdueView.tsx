import React from 'react';
import { Customer } from '../../types';
import { formatNumberWithCommas, getCustomerOverdueDays } from '../../utils/formatters';

interface OverdueViewProps {
  overdueCustomers: Customer[];
  overdueDaysLimit: number;
  onSendWhatsApp: (customer: Customer) => void;
  onOpenStatement: (customer: Customer) => void;
}

export const OverdueView: React.FC<OverdueViewProps> = ({
  overdueCustomers,
  overdueDaysLimit,
  onSendWhatsApp,
  onOpenStatement,
}) => {
  return (
    <div className="flex-1 min-h-0 overflow-y-auto scroll-smooth smooth-scrollbar space-y-4 p-0.5 pb-20 select-none">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-transparent border border-amber-200/80 rounded-2xl p-4 sm:p-5 flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
            <h2 className="text-base font-black text-slate-900">سجل المدينين المتأخرين عن التسديد</h2>
          </div>
          <p className="text-xs text-slate-600 font-medium">
            متابعة الحسابات المعلقة التي تجاوزت مدة السماح المحدد ({overdueDaysLimit} {overdueDaysLimit === 1 ? 'يوم' : overdueDaysLimit === 2 ? 'يومان' : overdueDaysLimit <= 10 ? 'أيام' : 'يوم'})
          </p>
        </div>

        <div className="hidden sm:flex items-center justify-center w-12 h-12 rounded-2xl bg-amber-500 text-white font-bold text-lg shadow-sm">
          <i className="fa-solid fa-clock-rotate-left"></i>
        </div>
      </div>

      {overdueCustomers.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-10 text-center text-slate-500 font-bold text-xs space-y-2 shadow-2xs">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-1">
            <i className="fa-solid fa-circle-check text-2xl"></i>
          </div>
          <p className="text-slate-900 font-extrabold text-sm">ممتاز! لا يوجد مدينون متأخرون حالياً</p>
          <p className="text-slate-400 font-normal">جميع الحسابات ملتزمة ضمن حد السماح المحدد ({overdueDaysLimit} يوم)</p>
        </div>
      ) : (
        <div className="space-y-3">
          {overdueCustomers.map((c) => {
            const days = getCustomerOverdueDays(c);
            return (
              <div
                key={c.id}
                className="bg-white border border-slate-200/80 rounded-2xl p-4 flex items-center justify-between shadow-2xs hover:shadow-md hover:border-slate-300 transition-all"
              >
                <div className="space-y-1">
                  <h3 className="font-extrabold text-slate-900 text-sm">{c.name}</h3>
                  <div className="text-sm font-black text-rose-600">
                    {formatNumberWithCommas(c.debt)}{' '}
                    <span className="text-[10px] font-bold text-slate-400">د.ع</span>
                  </div>
                  <div className="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 mt-1">
                    <i className="fa-solid fa-clock text-[10px] text-amber-600"></i>
                    <span>متأخر منذ {days} {days === 1 ? 'يوم' : days === 2 ? 'يومان' : days <= 10 ? 'أيام' : 'يوم'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onOpenStatement(c)}
                    className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-700 font-bold text-xs transition-colors cursor-pointer border border-slate-200"
                    title="كشف الحساب"
                  >
                    <i className="fa-solid fa-file-invoice text-sm"></i>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSendWhatsApp(c)}
                    className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all cursor-pointer shadow-2xs active:scale-95"
                  >
                    <i className="fa-brands fa-whatsapp text-base"></i>
                    <span>تذكير مباشر</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
