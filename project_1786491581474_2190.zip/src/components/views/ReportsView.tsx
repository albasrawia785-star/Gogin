import React from 'react';
import { Customer } from '../../types';
import { formatNumberWithCommas } from '../../utils/formatters';

interface ReportsViewProps {
  customers: Customer[];
  totalCurrentDebt: number;
  totalAddedDebts: number;
  totalPaidDebts: number;
  highDebtCount: number;
  activeCustomersCount: number;
  overdueCount: number;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  customers,
  totalCurrentDebt,
  totalAddedDebts,
  totalPaidDebts,
  highDebtCount,
  activeCustomersCount,
  overdueCount,
}) => {
  const collectionRate = totalAddedDebts > 0 ? ((totalPaidDebts / totalAddedDebts) * 100).toFixed(1) : '0';

  return (
    <div className="flex-1 min-h-0 overflow-y-auto scroll-smooth smooth-scrollbar space-y-4 p-0.5 pb-20 select-none">
      {/* Header Banner */}
      <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
        <div>
          <h2 className="text-base font-black text-slate-900">التقارير والإحصائيات المالية</h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            مؤشرات الأداء المالي، إجمالي الديون، ونسب التحصيل
          </p>
        </div>
      </div>

      {/* 1. Debt Summary Hero Card (Transferred from Main view as requested) */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 space-y-3.5 select-none shadow-sm relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-extrabold text-slate-700">إجمالي الديون القائمة الحالية</span>
          </div>
          <span className="text-[10px] font-black text-emerald-800 bg-emerald-50 border border-emerald-200/80 px-2.5 py-1 rounded-lg tracking-wide uppercase">
            صافي الحساب المعلق
          </span>
        </div>

        <div className="flex items-baseline justify-between pt-1">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-black tracking-tight text-slate-900">
              {formatNumberWithCommas(totalCurrentDebt)}
            </span>
            <span className="text-xs font-black text-slate-500">د.ع</span>
          </div>
        </div>

        {/* Micro Stats Row: High contrast indicators */}
        <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-100 text-[11px] font-bold text-slate-700">
          <div className="flex flex-col items-center sm:items-start bg-slate-50 p-2.5 rounded-xl border border-slate-200/60">
            <span className="text-[10px] text-slate-500 font-bold">النشاطون</span>
            <span className="text-sm font-black text-slate-900 mt-0.5">{activeCustomersCount}</span>
          </div>

          <div className="flex flex-col items-center sm:items-start bg-slate-50 p-2.5 rounded-xl border border-slate-200/60">
            <span className="text-[10px] text-slate-500 font-bold">ديون مرتفعة</span>
            <span className={`text-sm font-black mt-0.5 ${highDebtCount > 0 ? 'text-amber-700' : 'text-slate-900'}`}>
              {highDebtCount}
            </span>
          </div>

          <div className="flex flex-col items-center sm:items-start bg-slate-50 p-2.5 rounded-xl border border-slate-200/60">
            <span className="text-[10px] text-slate-500 font-bold">المتأخرون</span>
            <span className={`text-sm font-black mt-0.5 ${overdueCount > 0 ? 'text-rose-700' : 'text-slate-900'}`}>
              {overdueCount}
            </span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-2xs space-y-1.5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-500 block">إجمالي الديون المسجلة</span>
            <span className="w-2 h-2 rounded-full bg-rose-500"></span>
          </div>
          <div className="text-lg sm:text-xl font-black text-slate-900">
            {formatNumberWithCommas(totalAddedDebts)}{' '}
            <span className="text-xs font-extrabold text-slate-400">د.ع</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-2xs space-y-1.5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-500 block">إجمالي التسديدات المحصلة</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          </div>
          <div className="text-lg sm:text-xl font-black text-emerald-600">
            {formatNumberWithCommas(totalPaidDebts)}{' '}
            <span className="text-xs font-extrabold text-slate-400">د.ع</span>
          </div>
        </div>
      </div>

      {/* Collection Rate Progress Card (Light Theme) */}
      <div className="bg-white border border-slate-200/80 p-5 rounded-2xl shadow-2xs space-y-3.5">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-chart-line text-emerald-600 text-sm"></i>
            <span className="text-xs font-extrabold text-slate-900">نسبة تحصيل الديون الكلية</span>
          </div>
          <span className="text-xs font-black text-emerald-800 bg-emerald-50 border border-emerald-200/80 px-3 py-1 rounded-full">{collectionRate}%</span>
        </div>

        <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-200/80">
          <div
            className="bg-emerald-600 h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, Math.max(0, parseFloat(collectionRate)))}%` }}
          ></div>
        </div>

        <div className="flex justify-between items-center text-[11px] font-bold text-slate-500 pt-1">
          <span>المبلغ المحصل: {formatNumberWithCommas(totalPaidDebts)} د.ع</span>
          <span>الرصيد القائم: {formatNumberWithCommas(totalCurrentDebt)} د.ع</span>
        </div>
      </div>

      {/* Detailed Accounts Metrics */}
      <div className="bg-white border border-slate-200/80 p-5 rounded-2xl shadow-2xs space-y-3.5">
        <h3 className="font-extrabold text-xs text-slate-900 border-b border-slate-100 pb-2.5 flex items-center justify-between">
          <span>ملخص حالة سجلات المدينين</span>
          <i className="fa-solid fa-users text-slate-400"></i>
        </h3>

        <div className="space-y-3 text-xs font-bold text-slate-700">
          <div className="flex justify-between items-center py-1 border-b border-slate-100/80">
            <span className="text-slate-500 font-semibold">إجمالي عدد الحسابات المسجلة</span>
            <span className="font-black text-slate-900">{customers.length} مدين</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-100/80">
            <span className="text-slate-500 font-semibold">الحسابات القائمة بأرصدة ديون</span>
            <span className="font-black text-rose-600">{activeCustomersCount} مدين</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-100/80">
            <span className="text-slate-500 font-semibold">الحسابات الخالية تماماً من الديون</span>
            <span className="font-black text-emerald-600">{customers.length - activeCustomersCount} مدين</span>
          </div>

          <div className="flex justify-between items-center py-1 border-b border-slate-100/80">
            <span className="text-slate-500 font-semibold">حسابات ذات ديون مرتفعة</span>
            <span className="font-black text-amber-600">{highDebtCount} مدين</span>
          </div>

          <div className="flex justify-between items-center py-1">
            <span className="text-slate-500 font-semibold">الحسابات المتأخرة عن التسديد</span>
            <span className="font-black text-rose-600">{overdueCount} مدين</span>
          </div>
        </div>
      </div>
    </div>
  );
};
