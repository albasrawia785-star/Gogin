import React from 'react';
import { Customer } from '../../types';
import { formatNumberWithCommas, getCustomerOverdueDays } from '../../utils/formatters';

interface CustomerCardProps {
  customer: Customer;
  highDebtLimit: number;
  activeMenuId: string | null;
  setActiveMenuId: (id: string | null) => void;
  onOpenStatement: (customer: Customer) => void;
  onSendWhatsApp: (customer: Customer) => void;
  onEditCustomer: (customer: Customer) => void;
  onDeleteCustomer: (customer: Customer) => void;
  onAddDebt: (customer: Customer) => void;
  onPayment: (customer: Customer) => void;
}

export const CustomerCard: React.FC<CustomerCardProps> = ({
  customer,
  highDebtLimit,
  activeMenuId,
  setActiveMenuId,
  onOpenStatement,
  onSendWhatsApp,
  onEditCustomer,
  onDeleteCustomer,
  onAddDebt,
  onPayment,
}) => {
  const isHighDebt = (customer.debt || 0) >= highDebtLimit;
  const hasDebt = (customer.debt || 0) > 0;
  const initials = customer.avatarText || (customer.name ? customer.name.slice(0, 2) : 'مد');
  const overdueDays = getCustomerOverdueDays(customer);

  return (
    <div className="bg-white border border-slate-200/80 hover:border-slate-300 rounded-2xl p-4 space-y-3.5 relative select-none transition-all duration-200 shadow-[0_1px_3px_0_rgba(15,23,42,0.02)] hover:shadow-md">
      {/* 1. Header Row: Name, Phone & Options Menu */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white font-black text-xs flex items-center justify-center shrink-0 shadow-2xs">
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="font-extrabold text-slate-900 text-sm leading-tight truncate">
              {customer.name}
            </h3>
            {customer.phone ? (
              <p className="text-xs text-slate-500 font-medium mt-0.5 flex items-center gap-1.5" dir="ltr">
                <i className="fa-solid fa-phone text-[10px] text-slate-400"></i>
                <span>{customer.phone}</span>
              </p>
            ) : (
              <p className="text-[11px] text-slate-400 font-normal mt-0.5">
                بدون رقم هاتف مسجل
              </p>
            )}
          </div>
        </div>

        {/* Options Menu Dropdown Button */}
        <div className="relative shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setActiveMenuId(activeMenuId === customer.id ? null : customer.id);
            }}
            className="w-8 h-8 rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-100/80 flex items-center justify-center transition-all cursor-pointer"
            title="خيارات الحساب"
          >
            <i className="fa-solid fa-ellipsis-vertical text-sm"></i>
          </button>

          {activeMenuId === customer.id && (
            <div
              className="absolute top-9 left-0 bg-white border border-slate-200 rounded-2xl shadow-xl p-1.5 w-48 z-30 text-right space-y-1 animate-in fade-in zoom-in-95"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => {
                  onOpenStatement(customer);
                  setActiveMenuId(null);
                }}
                className="w-full flex items-center justify-between px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                <span>كشف الحساب التفصيلي</span>
                <i className="fa-solid fa-file-invoice text-slate-400"></i>
              </button>

              <button
                type="button"
                onClick={() => {
                  onSendWhatsApp(customer);
                  setActiveMenuId(null);
                }}
                className="w-full flex items-center justify-between px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                <span>إرسال تذكير واتساب</span>
                <i className="fa-brands fa-whatsapp text-emerald-600 text-sm"></i>
              </button>

              <button
                type="button"
                onClick={() => {
                  onEditCustomer(customer);
                  setActiveMenuId(null);
                }}
                className="w-full flex items-center justify-between px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                <span>تعديل بيانات المدين</span>
                <i className="fa-solid fa-pen-to-square text-slate-400"></i>
              </button>

              <div className="border-t border-slate-100 my-1"></div>

              <button
                type="button"
                onClick={() => {
                  setActiveMenuId(null);
                  onDeleteCustomer(customer);
                }}
                className="w-full flex items-center justify-between px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                <span>حذف السجل نهائياً</span>
                <i className="fa-solid fa-trash-can text-rose-500"></i>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 2. Amount & Status Row */}
      <div className="flex items-center justify-between pt-2.5 border-t border-slate-100/80">
        <div>
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">المبلغ المستحق</span>
          <div className="flex items-baseline gap-1.5 mt-0.5">
            <span className={`text-xl font-black ${hasDebt ? (isHighDebt ? 'text-rose-600' : 'text-slate-900') : 'text-emerald-600'}`}>
              {formatNumberWithCommas(customer.debt || 0)}
            </span>
            <span className="text-xs font-extrabold text-slate-400">د.ع</span>
          </div>
        </div>

        <div className="text-left flex flex-col items-end gap-1">
          <span
            className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border shadow-2xs ${
              isHighDebt
                ? 'bg-rose-50 text-rose-700 border-rose-200/80'
                : hasDebt
                ? 'bg-amber-50 text-amber-800 border-amber-200/80'
                : 'bg-emerald-50 text-emerald-800 border-emerald-200/80'
            }`}
          >
            {isHighDebt ? 'دين مرتفع' : hasDebt ? 'غير مسدد' : 'خالي من الدين'}
          </span>
          {hasDebt && overdueDays > 0 && (
            <span className="text-[10px] text-amber-700 font-extrabold flex items-center gap-1">
              <i className="fa-solid fa-clock text-[9px]"></i>
              <span>تأخير {overdueDays} يوم</span>
            </span>
          )}
        </div>
      </div>

      {/* 3. Actions Row: High Contrast, Luxury Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-1">
        <button
          type="button"
          onClick={() => onPayment(customer)}
          className="h-10 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 shadow-2xs"
        >
          <i className="fa-solid fa-arrow-down text-xs"></i>
          <span>تسديد مبلغ</span>
        </button>

        <button
          type="button"
          onClick={() => onAddDebt(customer)}
          className="h-10 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 shadow-2xs"
        >
          <i className="fa-solid fa-plus text-xs"></i>
          <span>إضافة دين</span>
        </button>
      </div>
    </div>
  );
};

