import React, { useState } from 'react';
import { formatIraqiPhoneForWhatsApp } from '../../utils/formatters';
import { CreateAccountModal } from '../modals/CreateAccountModal';

interface LoginViewProps {
  onLogin: (username: string, pass: string) => Promise<boolean>;
  triggerToast?: (msg: string) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLogin, triggerToast = () => {} }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isCreateAccountOpen, setIsCreateAccountOpen] = useState(false);

  const phoneFormatted = formatIraqiPhoneForWhatsApp('07810936407');
  const forgotMsg = encodeURIComponent('السلام عليكم، نسيت كلمة المرور الخاصة بحسابي في تطبيق دفتر ديوني.');
  const forgotWhatsappUrl = `https://wa.me/${phoneFormatted}?text=${forgotMsg}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setLoginError('يرجى كتابة اسم المستخدم وكلمة المرور');
      return;
    }
    setLoginError('');
    setIsLoading(true);

    try {
      const success = await onLogin(username.trim(), password.trim());
      if (!success) {
        setLoginError('اسم المستخدم أو كلمة المرور غير صحيحة!');
      }
    } catch (err) {
      setLoginError('حدث خطأ أثناء الاتصال بالخادم السحابي!');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex items-center justify-center p-4 sm:p-6 select-none dir-rtl relative overflow-hidden" dir="rtl">
      
      {/* Subtle ambient light background decoration */}
      <div className="absolute top-1/4 -right-20 w-96 h-96 bg-slate-200/50 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 -left-20 w-96 h-96 bg-emerald-100/50 rounded-full blur-3xl pointer-events-none"></div>

      {/* Centered Login Container */}
      <div className="w-full max-w-[420px] space-y-6 relative z-10">
        
        {/* Main Enterprise Light Luxury Card */}
        <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden">
          
          {/* Top Decorative Gradient Arc (Inspired by reference UI card header) */}
          <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-400"></div>

          {/* Logo & Header */}
          <div className="text-center space-y-3 pt-1">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-teal-500 text-white font-black text-2xl shadow-lg shadow-blue-500/25">
              <i className="fa-solid fa-wallet text-white"></i>
            </div>
            
            <div className="space-y-1">
              <div className="inline-block px-3 py-1 bg-blue-50 border border-blue-100 rounded-full text-[10px] font-extrabold text-blue-700 uppercase tracking-widest mb-1">
                منظومة المحاسبة السحابية
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                دفتر ديوني
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                أهلاً بك! سجل الدخول لإدارة الديون والتسديدات
              </p>
            </div>
          </div>

          {/* Error Notification */}
          {loginError && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-2xl flex items-center justify-center gap-2">
              <i className="fa-solid fa-circle-exclamation text-rose-500 text-xs"></i>
              <span>{loginError}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-extrabold text-slate-700">
                اسم المستخدم
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="أدخل اسم الحساب..."
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-2xl pr-10 pl-4 text-xs font-semibold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all"
                />
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                  <i className="fa-solid fa-user-gear"></i>
                </div>
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-extrabold text-slate-700">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-2xl pr-10 pl-10 text-xs font-semibold text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all"
                />
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                  <i className="fa-solid fa-lock"></i>
                </div>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 text-xs p-1 cursor-pointer transition-colors"
                  title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                >
                  <i className={`fa-regular ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-11 bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white font-black text-xs rounded-full flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 shadow-md shadow-blue-500/20 disabled:opacity-60 pt-0.5"
            >
              {isLoading ? (
                <i className="fa-solid fa-circle-notch animate-spin text-xs"></i>
              ) : (
                <i className="fa-solid fa-arrow-left text-xs"></i>
              )}
              <span>تسجيل الدخول إلى النظام</span>
            </button>
          </form>

          {/* Action Links: Create Account & Forgot Password */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2 text-xs font-bold">
            <button
              type="button"
              onClick={() => setIsCreateAccountOpen(true)}
              className="text-emerald-700 hover:text-emerald-800 transition-colors inline-flex items-center gap-1.5 py-1 cursor-pointer"
            >
              <i className="fa-solid fa-bolt text-xs"></i>
              <span>تجربة مجانية فورية</span>
            </button>

            <a
              href={forgotWhatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-500 hover:text-slate-900 transition-colors inline-flex items-center gap-1.5 py-1"
            >
              <i className="fa-brands fa-whatsapp text-emerald-600 text-sm"></i>
              <span>نسيت كلمة المرور؟</span>
            </a>
          </div>

        </div>

      </div>

      {/* Create Account Modal */}
      <CreateAccountModal
        isOpen={isCreateAccountOpen}
        onClose={() => setIsCreateAccountOpen(false)}
        onAutoLogin={onLogin}
        triggerToast={triggerToast}
      />
    </div>
  );
};

