import React, { useState } from 'react';
import { Customer } from '../../types';
import { CustomerCard } from './CustomerCard';

interface MainDebtViewProps {
  customers: Customer[];
  filteredCustomers: Customer[];
  isLoading: boolean;
  totalCurrentDebt: number;
  activeCustomersCount: number;
  highDebtCount: number;
  overdueCount: number;
  highDebtLimit: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filterType: 'ALL' | 'HAS_DEBT' | 'NO_DEBT' | 'HIGH_DEBT';
  setFilterType: (filter: 'ALL' | 'HAS_DEBT' | 'NO_DEBT' | 'HIGH_DEBT') => void;
  activeMenuId: string | null;
  setActiveMenuId: (id: string | null) => void;
  onOpenAddModal: () => void;
  onOpenStatement: (customer: Customer) => void;
  onSendWhatsApp: (customer: Customer) => void;
  onEditCustomer: (customer: Customer) => void;
  onDeleteCustomer: (customer: Customer) => void;
  onAddDebt: (customer: Customer) => void;
  onPayment: (customer: Customer) => void;
}

export const MainDebtView: React.FC<MainDebtViewProps> = ({
  customers,
  filteredCustomers,
  isLoading,
  totalCurrentDebt,
  activeCustomersCount,
  highDebtCount,
  overdueCount,
  highDebtLimit,
  searchQuery,
  setSearchQuery,
  filterType,
  setFilterType,
  activeMenuId,
  setActiveMenuId,
  onOpenAddModal,
  onOpenStatement,
  onSendWhatsApp,
  onEditCustomer,
  onDeleteCustomer,
  onAddDebt,
  onPayment,
}) => {
  return (
    <div className="flex-1 flex flex-col min-h-0 space-y-3.5">
      
      {/* Top Action Bar: Rearranged Search Bar + Primary Add Button */}
      <div className="shrink-0 space-y-2.5">
        <div className="flex items-center gap-2">
          {/* Main Search Bar (Pill style like reference image) */}
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="ابحث باسم المدين، المحل أو الهاتف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-11 bg-white pl-9 pr-10 border border-slate-200/90 rounded-full text-xs font-semibold text-slate-900 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-400 shadow-sm"
            />
            <i className="fa-solid fa-magnifying-glass absolute right-3.5 top-3.5 text-slate-400 text-xs"></i>
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-3 text-slate-400 hover:text-slate-800 text-xs p-1 cursor-pointer rounded-full hover:bg-slate-100"
                title="إلغاء البحث"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            )}
          </div>

          {/* Rearranged Add Button: Prominent Gradient Pill Action Button */}
          <button
            type="button"
            onClick={onOpenAddModal}
            title="إضافة مدين جديد"
            className="h-11 px-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white font-extrabold text-xs rounded-full flex items-center justify-center gap-2 shrink-0 transition-all cursor-pointer active:scale-95 shadow-md shadow-blue-500/20"
          >
            <i className="fa-solid fa-plus text-sm"></i>
            <span className="hidden sm:inline">إضافة مدين</span>
            <span className="sm:hidden">إضافة</span>
          </button>
        </div>

        {/* Filter Pills Bar (Inspired by pill tab categories in reference UI) */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 text-xs select-none">
          <button
            type="button"
            onClick={() => setFilterType('ALL')}
            className={`px-3.5 py-1.5 rounded-full whitespace-nowrap text-xs transition-all cursor-pointer ${
              filterType === 'ALL'
                ? 'bg-blue-600 text-white font-black shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50 font-bold'
            }`}
          >
            الكل ({customers.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('HAS_DEBT')}
            className={`px-3.5 py-1.5 rounded-full whitespace-nowrap text-xs transition-all cursor-pointer ${
              filterType === 'HAS_DEBT'
                ? 'bg-blue-600 text-white font-black shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50 font-bold'
            }`}
          >
            مطلوبين ({activeCustomersCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('HIGH_DEBT')}
            className={`px-3.5 py-1.5 rounded-full whitespace-nowrap text-xs transition-all cursor-pointer ${
              filterType === 'HIGH_DEBT'
                ? 'bg-blue-600 text-white font-black shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50 font-bold'
            }`}
          >
            مرتفعة ({highDebtCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('NO_DEBT')}
            className={`px-3.5 py-1.5 rounded-full whitespace-nowrap text-xs transition-all cursor-pointer ${
              filterType === 'NO_DEBT'
                ? 'bg-blue-600 text-white font-black shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200/80 hover:bg-slate-50 font-bold'
            }`}
          >
            خالي ({customers.length - activeCustomersCount})
          </button>
        </div>
      </div>

      {/* Customer List Header */}
      <div className="shrink-0 flex items-center justify-between text-xs font-extrabold text-slate-800 px-1 select-none pt-0.5">
        <div className="flex items-center gap-2">
          <span>قائمة السجلات والأسماء</span>
          <span className="text-slate-400 font-bold">({filteredCustomers.length} اسم)</span>
        </div>
      </div>

      {/* Customer Cards Scrollable Container */}
      <div className="flex-1 min-h-0 overflow-y-auto scroll-smooth smooth-scrollbar space-y-2.5 pb-20 pr-0.5">
        {isLoading ? (
          <div className="bg-white border border-slate-200/80 rounded-2xl p-10 text-center text-slate-500 font-bold text-xs space-y-2 shadow-2xs">
            <i className="fa-solid fa-circle-notch animate-spin text-xl text-blue-600 block"></i>
            <span>جاري تحديث سجلات الديون...</span>
          </div>
        ) : filteredCustomers.length === 0 ? (
          <div className="bg-white border border-slate-200/80 rounded-2xl p-10 text-center text-slate-500 font-medium text-xs space-y-2 shadow-2xs">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-1">
              <i className="fa-solid fa-users-slash text-xl"></i>
            </div>
            <p className="text-slate-900 font-extrabold text-sm">لا توجد نتائج مطابقة</p>
            <p className="text-slate-400 font-normal">تأكد من كتابة الاسم بصورة صحيحة أو قم بتغيير التصفية</p>
          </div>
        ) : (
          filteredCustomers.map((customer) => (
            <CustomerCard
              key={customer.id}
              customer={customer}
              highDebtLimit={highDebtLimit}
              activeMenuId={activeMenuId}
              setActiveMenuId={setActiveMenuId}
              onOpenStatement={onOpenStatement}
              onSendWhatsApp={onSendWhatsApp}
              onEditCustomer={onEditCustomer}
              onDeleteCustomer={onDeleteCustomer}
              onAddDebt={onAddDebt}
              onPayment={onPayment}
            />
          ))
        )}
      </div>
    </div>
  );
};

