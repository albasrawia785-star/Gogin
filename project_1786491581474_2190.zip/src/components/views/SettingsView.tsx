import React, { useState } from 'react';
import { User, SubManager, TrialAccount } from '../../types';
import { formatNumberWithCommas, parseRawNumber } from '../../utils/formatters';

interface SettingsViewProps {
  currentUser: User;
  onLogout?: () => void;
  overdueDaysLimit: number;
  onSaveOverdueDaysLimit: (days: number) => Promise<void>;
  highDebtLimit: number;
  onSaveHighDebtLimit: (limit: number) => Promise<void>;
  onChangePassword: (newPass: string) => Promise<void>;
  subManagers: SubManager[];
  onAddSubManager: (username: string, pass: string) => Promise<void>;
  onDeleteSubManager: (id: string) => Promise<void>;
  trialAccounts?: TrialAccount[];
  onStopTrialAccount?: (id: string) => Promise<void>;
  onDeleteTrialAccount?: (id: string) => Promise<void>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  onLogout,
  overdueDaysLimit,
  onSaveOverdueDaysLimit,
  highDebtLimit,
  onSaveHighDebtLimit,
  onChangePassword,
  subManagers,
  onAddSubManager,
  onDeleteSubManager,
  trialAccounts = [],
  onStopTrialAccount,
  onDeleteTrialAccount,
}) => {
  // Master Admin check (excludes trial users)
  const isMasterAdmin = currentUser.role === 'مدير عام' && !currentUser.isTrial;

  // Accordion active section state
  const [openSection, setOpenSection] = useState<string | null>(null);

  // Form states
  const [tempOverdueDaysInput, setTempOverdueDaysInput] = useState(overdueDaysLimit.toString());
  const [tempHighDebtFormatted, setTempHighDebtFormatted] = useState(formatNumberWithCommas(highDebtLimit));

  const [newPassInput, setNewPassInput] = useState('');
  const [confirmPassInput, setConfirmPassInput] = useState('');
  const [passError, setPassError] = useState('');
  const [passSuccessMsg, setPassSuccessMsg] = useState('');

  const [newSubUsername, setNewSubUsername] = useState('');
  const [newSubPassword, setNewSubPassword] = useState('');
  const [subMsg, setSubMsg] = useState('');
  const [isCreatingSub, setIsCreatingSub] = useState(false);

  // New account created credentials display
  const [createdCredentials, setCreatedCredentials] = useState<{ username: string; password: string } | null>(null);
  const [copiedNotice, setCopiedNotice] = useState(false);

  // Password visibility state map for sub-managers list
  const [visiblePasswords, setVisiblePasswords] = useState<{ [key: string]: boolean }>({});

  // Password visibility state map for trial accounts
  const [visibleTrialPasswords, setVisibleTrialPasswords] = useState<{ [key: string]: boolean }>({});
  const [processingTrialId, setProcessingTrialId] = useState<string | null>(null);

  const toggleSection = (sectionId: string) => {
    setOpenSection(prev => (prev === sectionId ? null : sectionId));
  };

  const togglePasswordVisibility = (id: string) => {
    setVisiblePasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleTrialPasswordVisibility = (id: string) => {
    setVisibleTrialPasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Trial Accounts metrics
  const activeTrialsCount = trialAccounts.filter(t => !t.isDisabled && t.expiresAt > Date.now()).length;
  const expiredOrStoppedTrialsCount = trialAccounts.filter(t => t.isDisabled || t.expiresAt <= Date.now()).length;

  const handleChangePassSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError('');
    setPassSuccessMsg('');

    if (!newPassInput || newPassInput !== confirmPassInput) {
      setPassError('كلمتا المرور غير متطابقتين!');
      return;
    }

    try {
      await onChangePassword(newPassInput);
      setPassSuccessMsg('تم تحديث كلمة المرور بنجاح!');
      setNewPassInput('');
      setConfirmPassInput('');
      setTimeout(() => setPassSuccessMsg(''), 4000);
    } catch (err) {
      setPassError('حدث خطأ أثناء تغيير كلمة المرور!');
    }
  };

  const handleAddSubSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubMsg('');
    setCreatedCredentials(null);

    const userClean = newSubUsername.trim();
    const passClean = newSubPassword.trim();

    if (!userClean || !passClean) {
      setSubMsg('يرجى ملء جميع الحقول المطلوب إدخالها');
      return;
    }

    setIsCreatingSub(true);
    try {
      await onAddSubManager(userClean, passClean);
      setCreatedCredentials({ username: userClean, password: passClean });
      setNewSubUsername('');
      setNewSubPassword('');
    } catch (err) {
      setSubMsg('حدث خطأ أثناء إضافة المدير الفرعي!');
    } finally {
      setIsCreatingSub(false);
    }
  };

  const handleCopyCredentials = () => {
    if (!createdCredentials) return;
    const text = `بيانات دخول المدير الفرعي:\nاسم المستخدم: ${createdCredentials.username}\nكلمة المرور: ${createdCredentials.password}`;
    navigator.clipboard.writeText(text);
    setCopiedNotice(true);
    setTimeout(() => setCopiedNotice(false), 3000);
  };

  // Avatar Initials derivation
  const getInitials = (name: string) => {
    if (!name) return 'US';
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <div className="flex-1 min-h-0 overflow-y-auto scroll-smooth smooth-scrollbar p-3.5 sm:p-4 space-y-5 pb-24 select-none text-right dir-rtl" dir="rtl">
      
      {/* 1. Page Header */}
      <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
        <div>
          <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
            مركز التحكم والإعدادات
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            تخصيص الخيارات المالية، الحسابات الفرعية والصلاحيات
          </p>
        </div>
        <span className="text-[11px] font-extrabold text-blue-800 bg-blue-50 px-3 py-1 rounded-full border border-blue-100 shadow-2xs">
          الإصدار السحابي
        </span>
      </div>

      {/* 2. User Profile Summary Card */}
      <div className="bg-white border border-slate-200/90 p-4 rounded-2xl shadow-2xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-teal-500 text-white font-black text-sm flex items-center justify-center shrink-0 shadow-md shadow-blue-500/20">
            {getInitials(currentUser.username)}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-slate-900 truncate">
                {currentUser.username}
              </h2>
              <span className="inline-flex items-center gap-1.5 text-[10px] font-black text-emerald-800 bg-emerald-50 border border-emerald-200/80 px-2.5 py-0.5 rounded-full shrink-0 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                حساب سحابي
              </span>
            </div>
            <p className="text-xs text-slate-500 font-bold mt-0.5 truncate">
              {currentUser.isTrial ? 'حساب تجريبي' : currentUser.role} • دفتر ديوني
            </p>
          </div>
        </div>
      </div>

      {/* 3. Section: Account & Security */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 px-1">
          <i className="fa-solid fa-shield-halved text-xs text-blue-600"></i>
          <h2 className="text-xs font-black text-slate-700 uppercase tracking-wider">
            إعدادات الحساب والأمان
          </h2>
        </div>

        {/* Vertical Options List with 8px (gap-2) spacing */}
        <div className="flex flex-col gap-2">
          
          {/* Option 1: Change Password Accordion Card (Hidden for Trial Accounts) */}
          {!currentUser.isTrial && (
            <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs hover:border-slate-300 transition-all">
              <button
                type="button"
                onClick={() => toggleSection('password')}
                className="w-full flex items-center justify-between cursor-pointer text-right"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs shrink-0 border border-blue-100">
                    <i className="fa-solid fa-key"></i>
                  </div>
                  <div>
                    <span className="text-xs font-black text-slate-900 block">تغيير كلمة المرور</span>
                    <span className="text-[11px] text-slate-500 font-medium block mt-0.5">تحديث الرمز السري الخاص بك</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <span className="text-[10px] font-black text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-100">
                    {openSection === 'password' ? 'إغلاق' : 'تعديل'}
                  </span>
                  <i className={`fa-solid fa-chevron-down text-xs transition-transform duration-200 ${openSection === 'password' ? 'rotate-180 text-slate-800' : ''}`}></i>
                </div>
              </button>

              {/* Collapsible Form for Change Password */}
              {openSection === 'password' && (
                <div className="mt-3.5 pt-3.5 border-t border-slate-100 space-y-2.5">
                  {passError && (
                    <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
                      <i className="fa-solid fa-circle-exclamation text-rose-500"></i>
                      <span>{passError}</span>
                    </div>
                  )}

                  {passSuccessMsg && (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold rounded-xl flex items-center gap-2">
                      <i className="fa-solid fa-circle-check text-emerald-600"></i>
                      <span>{passSuccessMsg}</span>
                    </div>
                  )}

                  <form onSubmit={handleChangePassSubmit} className="space-y-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">كلمة المرور الجديدة</label>
                      <input
                        type="password"
                        required
                        placeholder="••••••••"
                        value={newPassInput}
                        onChange={(e) => setNewPassInput(e.target.value)}
                        className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-800 focus:bg-white transition-colors placeholder:text-slate-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">تأكيد كلمة المرور</label>
                      <input
                        type="password"
                        required
                        placeholder="••••••••"
                        value={confirmPassInput}
                        onChange={(e) => setConfirmPassInput(e.target.value)}
                        className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-800 focus:bg-white transition-colors placeholder:text-slate-400"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full h-10 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl transition-all cursor-pointer active:scale-98 shadow-sm shadow-blue-500/20"
                    >
                      حفظ كلمة المرور الجديدة
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}

          {/* Option 2: Manage Sub-Managers Accordion Card (General Manager only) */}
          {isMasterAdmin && (
            <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs hover:border-slate-300 transition-all">
              <button
                type="button"
                onClick={() => toggleSection('submanagers')}
                className="w-full flex items-center justify-between cursor-pointer text-right"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs shrink-0 border border-indigo-100">
                    <i className="fa-solid fa-users-gear"></i>
                  </div>
                  <div>
                    <span className="text-xs font-black text-slate-900 block">إدارة حسابات المدراء الفرعيين</span>
                    <span className="text-[11px] text-slate-500 font-medium block mt-0.5">إضافة مستخدمين فرعيين واستعراض كلمات السر</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <span className="text-[10px] font-black text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-1 rounded-lg">
                    {subManagers.length} مدير
                  </span>
                  <i className={`fa-solid fa-chevron-down text-xs transition-transform duration-200 ${openSection === 'submanagers' ? 'rotate-180 text-slate-800' : ''}`}></i>
                </div>
              </button>

              {/* Collapsible Form & List for Sub-Managers */}
              {openSection === 'submanagers' && (
                <div className="mt-3.5 pt-3.5 border-t border-slate-100 space-y-3">
                  {subMsg && (
                    <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
                      <i className="fa-solid fa-circle-exclamation text-rose-500"></i>
                      <span>{subMsg}</span>
                    </div>
                  )}

                  {/* Created Credentials Alert Banner */}
                  {createdCredentials && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                      <div className="flex items-center gap-2 text-emerald-800">
                        <i className="fa-solid fa-circle-check text-emerald-600 text-sm"></i>
                        <span className="text-xs font-extrabold">تم إنشاء حساب المدير الفرعي بنجاح!</span>
                      </div>

                      <div className="bg-white border border-emerald-200 rounded-lg p-2.5 space-y-1.5 text-xs text-slate-800">
                        <div className="flex justify-between items-center border-b border-emerald-100 pb-1">
                          <span className="text-slate-500 font-medium">اسم المستخدم الفرعي:</span>
                          <span className="font-bold text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                            {createdCredentials.username}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-500 font-medium">كلمة المرور الحالية:</span>
                          <span className="font-mono font-bold text-slate-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            {createdCredentials.password}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleCopyCredentials}
                        className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98 shadow-2xs"
                      >
                        <i className={`fa-solid ${copiedNotice ? 'fa-check' : 'fa-copy'}`}></i>
                        <span>{copiedNotice ? 'تم النسخ!' : 'نسخ تفاصيل الحساب'}</span>
                      </button>
                    </div>
                  )}

                  {/* Add Sub-Manager Form */}
                  <form onSubmit={handleAddSubSubmit} className="space-y-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">اسم المستخدم الفرعي</label>
                      <input
                        type="text"
                        required
                        placeholder="أدخل اسم المستخدم الفرعي..."
                        value={newSubUsername}
                        onChange={(e) => setNewSubUsername(e.target.value)}
                        className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-800 focus:bg-white transition-colors placeholder:text-slate-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">كلمة المرور للفرعي</label>
                      <input
                        type="password"
                        required
                        placeholder="••••••••"
                        value={newSubPassword}
                        onChange={(e) => setNewSubPassword(e.target.value)}
                        className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-800 focus:bg-white transition-colors placeholder:text-slate-400"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={isCreatingSub}
                      className="w-full h-10 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 shadow-sm shadow-blue-500/20"
                    >
                      {isCreatingSub && <i className="fa-solid fa-spinner animate-spin text-xs"></i>}
                      <span>إضافة حساب فرعي جديد</span>
                    </button>
                  </form>

                  {/* Sub-Managers List */}
                  {subManagers.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-slate-100">
                      <span className="text-xs font-extrabold text-slate-700 block">
                        الحسابات الفرعية الحالية ({subManagers.length}):
                      </span>
                      <div className="space-y-2">
                        {subManagers.map((sub) => {
                          const isVisible = visiblePasswords[sub.id];
                          const subPass = sub.password || 'غير معينة';
                          return (
                            <div
                              key={sub.id}
                              className="p-3 bg-slate-50/80 border border-slate-200/80 rounded-xl space-y-2"
                            >
                              <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                  <div className="w-6 h-6 rounded bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0">
                                    <i className="fa-solid fa-user text-[10px]"></i>
                                  </div>
                                  <div>
                                    <span className="text-xs font-black text-slate-900 block">{sub.username || sub.id}</span>
                                    <span className="text-[10px] text-slate-500 font-medium">
                                      مدير فرعي {sub.createdAt ? `• ${sub.createdAt.slice(0, 10)}` : ''}
                                    </span>
                                  </div>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => onDeleteSubManager(sub.id)}
                                  className="p-1 text-rose-600 hover:bg-rose-100 rounded-lg text-xs transition-colors cursor-pointer"
                                  title="حذف الحساب الفرعي"
                                >
                                  <i className="fa-solid fa-trash-can"></i>
                                </button>
                              </div>

                              {/* Credentials Row */}
                              <div className="bg-white border border-slate-200/80 rounded-lg p-2 flex items-center justify-between text-xs">
                                <span className="text-[10px] font-bold text-slate-500">كلمة المرور:</span>
                                <div className="flex items-center gap-2">
                                  <span className={`font-mono text-xs ${isVisible ? 'font-bold text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100' : 'text-slate-400'}`}>
                                    {isVisible ? subPass : '••••••••'}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => togglePasswordVisibility(sub.id)}
                                    className="text-slate-400 hover:text-slate-700 p-0.5 text-xs cursor-pointer transition-colors"
                                    title={isVisible ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                                  >
                                    <i className={`fa-regular ${isVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Option 3: Manage Trial Accounts Accordion Card (General Manager only) */}
          {isMasterAdmin && (
            <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs hover:border-slate-300 transition-all">
              <button
                type="button"
                onClick={() => toggleSection('trials')}
                className="w-full flex items-center justify-between cursor-pointer text-right"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xs shrink-0 border border-amber-100">
                    <i className="fa-solid fa-bolt"></i>
                  </div>
                  <div>
                    <span className="text-xs font-black text-slate-900 block">إدارة الحسابات التجريبية</span>
                    <span className="text-[11px] text-slate-500 font-medium block mt-0.5">
                      عرض الحسابات المؤقتة، إيقافها، أو حذفها نهائياً
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <span className="text-[10px] font-black text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg">
                    {trialAccounts.length} حساب
                  </span>
                  <i className={`fa-solid fa-chevron-down text-xs transition-transform duration-200 ${openSection === 'trials' ? 'rotate-180 text-slate-800' : ''}`}></i>
                </div>
              </button>

              {/* Collapsible Content for Trial Accounts */}
              {openSection === 'trials' && (
                <div className="mt-3.5 pt-3.5 border-t border-slate-100 space-y-3">
                  
                  {/* Summary Bar */}
                  <div className="grid grid-cols-3 gap-2 text-center text-xs font-extrabold">
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-medium block">إجمالي الحسابات</span>
                      <span className="text-slate-900 font-black text-sm">{trialAccounts.length}</span>
                    </div>
                    <div className="bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200/80">
                      <span className="text-[10px] text-emerald-700 font-medium block">نشطة (سارية)</span>
                      <span className="text-emerald-800 font-black text-sm">{activeTrialsCount}</span>
                    </div>
                    <div className="bg-rose-50/60 p-2.5 rounded-xl border border-rose-200/80">
                      <span className="text-[10px] text-rose-700 font-medium block">موقوفة / منتهية</span>
                      <span className="text-rose-800 font-black text-sm">{expiredOrStoppedTrialsCount}</span>
                    </div>
                  </div>

                  {/* List of Trial Accounts */}
                  {trialAccounts.length === 0 ? (
                    <div className="text-center py-6 bg-slate-50 border border-dashed border-slate-200 rounded-xl space-y-1">
                      <i className="fa-solid fa-clock-rotate-left text-slate-300 text-2xl"></i>
                      <p className="text-xs font-bold text-slate-600">لا توجد حسابات تجريبية مسجلة</p>
                      <p className="text-[10px] text-slate-400">تظهر الحسابات التجريبية هنا فور إنشائها من شاشة الدخول</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-slate-700">
                          قائمة الحسابات التجريبية ({trialAccounts.length}):
                        </span>

                        {expiredOrStoppedTrialsCount > 0 && (
                          <button
                            type="button"
                            onClick={async () => {
                              const expiredList = trialAccounts.filter(t => t.isDisabled || t.expiresAt <= Date.now());
                              for (const acc of expiredList) {
                                if (onDeleteTrialAccount) {
                                  await onDeleteTrialAccount(acc.id);
                                }
                              }
                            }}
                            className="text-[10px] font-black text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-lg border border-rose-200 transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <i className="fa-solid fa-broom text-[10px]"></i>
                            <span>تنظيف المنتهية ({expiredOrStoppedTrialsCount})</span>
                          </button>
                        )}
                      </div>

                      <div className="space-y-2">
                        {trialAccounts.map((trial) => {
                          const isExpired = Date.now() >= trial.expiresAt;
                          const isStopped = trial.isDisabled || isExpired;
                          const diffMs = trial.expiresAt - Date.now();
                          const remainingMins = Math.max(0, Math.ceil(diffMs / 60000));
                          const isVisiblePass = visibleTrialPasswords[trial.id];
                          const trialPass = trial.password || 'غير معينة';
                          const isProcessing = processingTrialId === trial.id;

                          return (
                            <div
                              key={trial.id}
                              className={`p-3 border rounded-xl space-y-2 transition-all ${
                                trial.isDisabled
                                  ? 'border-rose-200 bg-rose-50/20'
                                  : isExpired
                                  ? 'border-amber-200 bg-amber-50/20'
                                  : 'border-slate-200/90 bg-white'
                              }`}
                            >
                              {/* Header & Status */}
                              <div className="flex justify-between items-center gap-2">
                                <div className="flex items-center gap-2 min-w-0">
                                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                                    trial.isDisabled
                                      ? 'bg-rose-100 text-rose-700'
                                      : isExpired
                                      ? 'bg-amber-100 text-amber-700'
                                      : 'bg-emerald-100 text-emerald-700'
                                  }`}>
                                    <i className="fa-solid fa-user-clock text-xs"></i>
                                  </div>
                                  <div className="min-w-0">
                                    <span className="text-xs font-black text-slate-900 block truncate">
                                      {trial.username}
                                    </span>
                                    <span className="text-[10px] text-slate-400 font-medium block truncate">
                                      معرّف الحساب: {trial.id}
                                    </span>
                                  </div>
                                </div>

                                {/* Status Badge */}
                                <div>
                                  {trial.isDisabled ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-rose-100 text-rose-800 border border-rose-200">
                                      <span className="w-1.5 h-1.5 rounded-full bg-rose-600"></span>
                                      موقوف
                                    </span>
                                  ) : isExpired ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-200">
                                      <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                                      منتهي
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                                      نشط (متبقي {remainingMins} د)
                                    </span>
                                  )}
                                </div>
                              </div>

                              {/* Credentials Row */}
                              <div className="bg-slate-50 border border-slate-100 rounded-lg p-2 flex items-center justify-between text-xs">
                                <span className="text-[10px] font-bold text-slate-500">كلمة المرور:</span>
                                <div className="flex items-center gap-2">
                                  <span className={`font-mono text-xs ${isVisiblePass ? 'font-bold text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100' : 'text-slate-400'}`}>
                                    {isVisiblePass ? trialPass : '••••••••'}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => toggleTrialPasswordVisibility(trial.id)}
                                    className="text-slate-400 hover:text-slate-700 p-0.5 text-xs cursor-pointer transition-colors"
                                    title={isVisiblePass ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                                  >
                                    <i className={`fa-regular ${isVisiblePass ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                                  </button>
                                </div>
                              </div>

                              {/* Action Buttons */}
                              <div className="flex items-center justify-end gap-2 pt-1">
                                {!isStopped && onStopTrialAccount && (
                                  <button
                                    type="button"
                                    disabled={isProcessing}
                                    onClick={async () => {
                                      setProcessingTrialId(trial.id);
                                      try {
                                        await onStopTrialAccount(trial.id);
                                      } finally {
                                        setProcessingTrialId(null);
                                      }
                                    }}
                                    className="py-1.5 px-3 bg-amber-50 hover:bg-amber-100 text-amber-800 font-extrabold text-[11px] rounded-lg border border-amber-200/80 flex items-center gap-1.5 transition-colors cursor-pointer active:scale-98 disabled:opacity-50"
                                    title="إيقاف الحساب التجريبي فوراً"
                                  >
                                    <i className="fa-solid fa-circle-pause text-amber-600 text-xs"></i>
                                    <span>إيقاف الحساب</span>
                                  </button>
                                )}

                                {onDeleteTrialAccount && (
                                  <button
                                    type="button"
                                    disabled={isProcessing}
                                    onClick={async () => {
                                      setProcessingTrialId(trial.id);
                                      try {
                                        await onDeleteTrialAccount(trial.id);
                                      } finally {
                                        setProcessingTrialId(null);
                                      }
                                    }}
                                    className="py-1.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 font-extrabold text-[11px] rounded-lg border border-rose-200/80 flex items-center gap-1.5 transition-colors cursor-pointer active:scale-98 disabled:opacity-50"
                                    title="حذف الحساب التجريبي نهائياً"
                                  >
                                    <i className="fa-solid fa-trash-can text-rose-600 text-xs"></i>
                                    <span>حذف الحساب</span>
                                  </button>
                                )}
                              </div>

                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                </div>
              )}
            </div>
          )}

          {/* Option 4: Static Account Details Card */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center text-xs shrink-0 border border-slate-200">
                <i className="fa-solid fa-id-card"></i>
              </div>
              <div>
                <span className="text-xs font-black text-slate-900 block">تفاصيل الحساب الحالية</span>
                <span className="text-[11px] font-medium text-slate-500 block mt-0.5">
                  المستخدم: {currentUser.username} • الصلاحية: {currentUser.role}
                </span>
              </div>
            </div>
            <span className="text-[10px] font-black text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
              نشط
            </span>
          </div>

        </div>
      </div>

      {/* 4. Section: System Options & Configuration */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 px-1">
          <i className="fa-solid fa-sliders text-xs text-blue-600"></i>
          <h2 className="text-xs font-black text-slate-700 uppercase tracking-wider">
            إعدادات النظام والخيارات
          </h2>
        </div>

        {/* Vertical Options List with 8px (gap-2) spacing */}
        <div className="flex flex-col gap-2">
          
          {/* Option 1: Overdue Days Limit Accordion Card */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs hover:border-slate-300 transition-all">
            <button
              type="button"
              onClick={() => toggleSection('overdue')}
              className="w-full flex items-center justify-between cursor-pointer text-right"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xs shrink-0 border border-amber-100">
                  <i className="fa-solid fa-clock-rotate-left"></i>
                </div>
                <div>
                  <span className="text-xs font-black text-slate-900 block">مدة التأخير لقائمة المتأخرين</span>
                  <span className="text-[11px] text-slate-500 font-medium block mt-0.5">
                    الحالي: {overdueDaysLimit} {overdueDaysLimit === 1 ? 'يوم' : overdueDaysLimit === 2 ? 'يومان' : overdueDaysLimit <= 10 ? 'أيام' : 'يوم'}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <span className="text-[10px] font-black text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg">
                  تعديل
                </span>
                <i className={`fa-solid fa-chevron-down text-xs transition-transform duration-200 ${openSection === 'overdue' ? 'rotate-180 text-slate-800' : ''}`}></i>
              </div>
            </button>

            {/* Collapsible Content for Overdue Days */}
            {openSection === 'overdue' && (
              <div className="mt-3.5 pt-3.5 border-t border-slate-100 space-y-3">
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  حدد عدد الأيام التي يظهر بعد انقضائها المدين في قائمة المتأخرين عن التسديد:
                </p>

                {/* Quick Presets */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => onSaveOverdueDaysLimit(7)}
                    className={`py-2 px-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      overdueDaysLimit === 7
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/80'
                    }`}
                  >
                    أسبوع (7 أيام)
                  </button>
                  <button
                    type="button"
                    onClick={() => onSaveOverdueDaysLimit(14)}
                    className={`py-2 px-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      overdueDaysLimit === 14
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/80'
                    }`}
                  >
                    أسبوعين (14 يوم)
                  </button>
                  <button
                    type="button"
                    onClick={() => onSaveOverdueDaysLimit(30)}
                    className={`py-2 px-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      overdueDaysLimit === 30
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/80'
                    }`}
                  >
                    شهر (30 يوم)
                  </button>
                </div>

                {/* Custom Input */}
                <div className="space-y-1.5 pt-1">
                  <label className="block text-xs font-extrabold text-slate-700">تحديد مدة مخصصة (حسب الإدخال):</label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type="number"
                        min="1"
                        max="365"
                        value={tempOverdueDaysInput}
                        onChange={(e) => setTempOverdueDaysInput(e.target.value)}
                        placeholder="أدخل عدد الأيام..."
                        className="w-full h-10 pl-10 pr-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-800 focus:bg-white transition-colors placeholder:text-slate-400"
                      />
                      <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">يوم</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const days = parseInt(tempOverdueDaysInput, 10);
                        if (days && days > 0) {
                          onSaveOverdueDaysLimit(days);
                        }
                      }}
                      className="px-4 h-10 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shrink-0 cursor-pointer transition-all active:scale-98 shadow-sm shadow-blue-500/20"
                    >
                      تحديث
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Option 2: High Debt Limit Accordion Card */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs hover:border-slate-300 transition-all">
            <button
              type="button"
              onClick={() => toggleSection('highdebt')}
              className="w-full flex items-center justify-between cursor-pointer text-right"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-xs shrink-0 border border-rose-100">
                  <i className="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div>
                  <span className="text-xs font-black text-slate-900 block">حد الديون المرتفعة</span>
                  <span className="text-[11px] text-slate-500 font-medium block mt-0.5">
                    المبلغ الحالي: {formatNumberWithCommas(highDebtLimit)} د.ع
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <span className="text-[10px] font-black text-rose-800 bg-rose-50 border border-rose-200 px-2.5 py-1 rounded-lg">
                  تعديل
                </span>
                <i className={`fa-solid fa-chevron-down text-xs transition-transform duration-200 ${openSection === 'highdebt' ? 'rotate-180 text-slate-800' : ''}`}></i>
              </div>
            </button>

            {/* Collapsible Content for High Debt Limit */}
            {openSection === 'highdebt' && (
              <div className="mt-3.5 pt-3.5 border-t border-slate-100 space-y-3">
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  يتم تصنيف الحساب كـ "دين مرتفع" إذا تجاوز هذا المبلغ:
                </p>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={tempHighDebtFormatted}
                      onChange={(e) => setTempHighDebtFormatted(formatNumberWithCommas(e.target.value))}
                      placeholder="100,000"
                      className="w-full h-10 pl-11 pr-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-800 focus:bg-white transition-colors placeholder:text-slate-400"
                    />
                    <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">د.ع</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const val = parseRawNumber(tempHighDebtFormatted);
                      if (val >= 0) {
                        onSaveHighDebtLimit(val);
                      }
                    }}
                    className="px-4 h-10 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shrink-0 cursor-pointer transition-all active:scale-98 shadow-sm shadow-blue-500/20"
                  >
                    تحديث
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Option 3: Static Sync & Settings Card */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center text-xs shrink-0 border border-slate-200">
                <i className="fa-solid fa-rotate text-xs"></i>
              </div>
              <div>
                <span className="text-xs font-black text-slate-900 block">المزامنة والتحديثات الآلية</span>
                <span className="text-[11px] font-medium text-slate-500 block mt-0.5">
                  تشفير سحابي متكامل مع الأجهزة
                </span>
              </div>
            </div>
            <span className="text-[10px] font-black text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200/80">
              تلقائي
            </span>
          </div>

        </div>
      </div>

      {/* 5. Section: Account Actions (Logout) */}
      {onLogout && (
        <div className="space-y-2 pt-1">
          <div className="flex items-center gap-2 px-1">
            <i className="fa-solid fa-right-from-bracket text-xs text-rose-600"></i>
            <h2 className="text-xs font-black text-rose-700 uppercase tracking-wider">
              إجراءات الجلسة
            </h2>
          </div>

          <button
            type="button"
            onClick={onLogout}
            className="w-full bg-rose-50 hover:bg-rose-100/80 border border-rose-200/90 rounded-2xl p-3.5 sm:p-4 shadow-2xs flex items-center justify-between text-rose-700 transition-all cursor-pointer active:scale-98 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center text-xs shrink-0 group-hover:bg-rose-200 transition-colors">
                <i className="fa-solid fa-power-off text-xs"></i>
              </div>
              <div>
                <span className="text-xs font-black block">تسجيل الخروج من الحساب</span>
                <span className="text-[11px] text-rose-500 font-medium block mt-0.5">إنهاء الجلسة الحالية والعودة لصفحة الدخول</span>
              </div>
            </div>
            <i className="fa-solid fa-arrow-left text-xs text-rose-500 group-hover:-translate-x-1 transition-transform"></i>
          </button>
        </div>
      )}

    </div>
  );
};
