import React, { useState, useEffect, useMemo } from 'react';
import { Customer, User, SubManager, TrialAccount, HistoryItem } from './types';
import { 
  db, auth, collection, doc, setDoc, getDoc, getDocs, where, addDoc, updateDoc, deleteDoc, onSnapshot, query, orderBy, serverTimestamp,
  signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, usernameToEmail,
  getSecondaryAuth, firebaseUpdatePassword
} from './firebase';
import { formatNumberWithCommas, formatIraqiPhoneForWhatsApp, getCustomerOverdueDays } from './utils/formatters';

import { Header } from './components/common/Header';
import { Navigation, NavTab } from './components/common/Navigation';
import { Toast } from './components/common/Toast';
import { ConfirmModal } from './components/common/ConfirmModal';

import { LoginView } from './components/views/LoginView';
import { MainDebtView } from './components/views/MainDebtView';
import { ReportsView } from './components/views/ReportsView';
import { OverdueView } from './components/views/OverdueView';
import { SettingsView } from './components/views/SettingsView';

import { CustomerModal } from './components/modals/CustomerModal';
import { TransactionModal } from './components/modals/TransactionModal';
import { StatementModal } from './components/modals/StatementModal';

export function App() {
  // Saved local session fallback if Firebase Auth is unconfigured in console
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('debt_user');
    if (!saved) return null;
    try {
      const parsed: User = JSON.parse(saved);
      if (parsed.isTrial && parsed.expiresAt && Date.now() >= parsed.expiresAt) {
        localStorage.removeItem('debt_user');
        return null;
      }
      return parsed;
    } catch (e) {
      return null;
    }
  });

  // Trial Countdown State (Seconds)
  const [trialSecondsLeft, setTrialSecondsLeft] = useState<number | null>(null);

  // Navigation & View Tab
  const [activeTab, setActiveTab] = useState<NavTab>('main');

  // Customer List & Sync State
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<'ALL' | 'HAS_DEBT' | 'NO_DEBT' | 'HIGH_DEBT'>('ALL');

  // User Settings State
  const [overdueDaysLimit, setOverdueDaysLimit] = useState<number>(30);
  const [highDebtLimit, setHighDebtLimit] = useState<number>(100000);

  // Options Menu Active Dropdown
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // Sub-Managers State
  const [subManagers, setSubManagers] = useState<SubManager[]>([]);

  // Trial Accounts State
  const [trialAccounts, setTrialAccounts] = useState<TrialAccount[]>([]);

  // Toast Notification Message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals Visibility & Selected Customer
  const [customerModalState, setCustomerModalState] = useState<{
    isOpen: boolean;
    mode: 'ADD' | 'EDIT';
    customer: Customer | null;
  }>({ isOpen: false, mode: 'ADD', customer: null });

  const [transactionModalState, setTransactionModalState] = useState<{
    isOpen: boolean;
    type: 'ADD_DEBT' | 'PAYMENT' | null;
    customer: Customer | null;
  }>({ isOpen: false, type: null, customer: null });

  const [statementModalState, setStatementModalState] = useState<{
    isOpen: boolean;
    customer: Customer | null;
  }>({ isOpen: false, customer: null });

  const [confirmDeleteCustomer, setConfirmDeleteCustomer] = useState<Customer | null>(null);
  const [confirmDeleteSubManagerId, setConfirmDeleteSubManagerId] = useState<string | null>(null);

  // Toast Trigger Helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Close menus when clicking anywhere on page
  useEffect(() => {
    const handleGlobalClick = () => setActiveMenuId(null);
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  // Live Trial Account Timer & Automatic Expiration
  useEffect(() => {
    if (!currentUser?.isTrial || !currentUser?.expiresAt) {
      setTrialSecondsLeft(null);
      return;
    }

    const checkAndCalculateTime = async () => {
      const now = Date.now();
      const diffMs = currentUser.expiresAt! - now;
      const remaining = Math.max(0, Math.floor(diffMs / 1000));

      if (remaining <= 0) {
        // Trial expired! Clean up trial document in Firestore and log out
        try {
          await deleteDoc(doc(db, 'users', currentUser.id));
        } catch (e) {
          console.warn('Could not auto-delete expired trial user doc:', e);
        }
        setCurrentUser(null);
        localStorage.removeItem('debt_user');
        triggerToast('انتهت صلاحية الحساب التجريبي (ساعة واحدة). تم تسجيل الخروج تلقائياً.');
      } else {
        setTrialSecondsLeft(remaining);
      }
    };

    checkAndCalculateTime();
    const interval = setInterval(checkAndCalculateTime, 1000);
    return () => clearInterval(interval);
  }, [currentUser]);

  const formatTrialTimer = (seconds: number): string => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    const mStr = m < 10 ? `0${m}` : `${m}`;
    const sStr = s < 10 ? `0${s}` : `${s}`;
    return `${mStr}:${sStr}`;
  };

  // Secure Firebase Auth Observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userRef = doc(db, 'users', firebaseUser.uid);
          const userSnap = await getDoc(userRef);

          if (userSnap.exists()) {
            const data = userSnap.data();
            if (data.isTrial && data.expiresAt && Date.now() >= data.expiresAt) {
              try {
                await deleteDoc(userRef);
              } catch (e) {}
              setCurrentUser(null);
              localStorage.removeItem('debt_user');
              triggerToast('انتهت صلاحية الحساب التجريبي (ساعة واحدة). تم تسجيل الخروج تلقائياً.');
              return;
            }
            setCurrentUser({
              id: firebaseUser.uid,
              username: data.username || firebaseUser.email?.split('@')[0] || 'user',
              role: data.role || 'مدير عام',
              isTrial: data.isTrial || false,
              expiresAt: data.expiresAt,
            });
            if (typeof data.overdueDaysLimit === 'number' && data.overdueDaysLimit > 0) {
              setOverdueDaysLimit(data.overdueDaysLimit);
            }
            if (typeof data.highDebtLimit === 'number' && data.highDebtLimit > 0) {
              setHighDebtLimit(data.highDebtLimit);
            }
          } else {
            // Document creation for new profile
            const inferredUsername = firebaseUser.email?.split('@')[0] || 'user';
            const role = 'مدير عام';
            await setDoc(userRef, {
              username: inferredUsername,
              role,
              createdAt: serverTimestamp(),
            }, { merge: true });

            setCurrentUser({
              id: firebaseUser.uid,
              username: inferredUsername,
              role,
            });
          }
        } catch (err) {
          console.error('Error loading user profile:', err);
        }
      } else {
        setCurrentUser(null);
        setCustomers([]);
        setSubManagers([]);
        setIsLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time Firestore Sync for Customers Sub-Collection (Isolated to current UID)
  useEffect(() => {
    if (!currentUser) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const custRef = collection(db, 'users', currentUser.id, 'customers');
    const q = query(custRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const loaded: Customer[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          loaded.push({
            id: docSnap.id,
            name: data.name || '',
            avatarText: data.avatarText || '',
            phone: data.phone || '',
            debt: data.debt || 0,
            totalAdded: data.totalAdded || data.debt || 0,
            totalPaid: data.totalPaid || 0,
            overdueDays: data.overdueDays || 0,
            lastDate: data.lastDate || '',
            lastTimestamp: data.lastTimestamp || undefined,
            avatarBg: data.avatarBg || 'bg-indigo-100 text-indigo-700',
            createdAt: data.createdAt,
            history: data.history || [],
          });
        });
        setCustomers(loaded);
        setIsLoading(false);
      },
      (error) => {
        console.error('Firestore customers snapshot error:', error);
        setIsLoading(false);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // Fetch Sub-Managers if General Manager (excludes trial accounts)
  useEffect(() => {
    if (!currentUser || currentUser.role !== 'مدير عام' || currentUser.isTrial) return;
    const subRef = collection(db, 'sub_managers');
    const unsubscribe = onSnapshot(
      subRef,
      (snapshot) => {
        const map = new Map<string, SubManager>();
        snapshot.forEach((d) => {
          const data = d.data();
          const uname = data.username || d.id;
          const key = uname.toLowerCase();
          
          if (!map.has(key) || data.password) {
            map.set(key, {
              id: d.id,
              username: uname,
              password: data.password || '',
              role: data.role || 'مدير فرعي',
              createdBy: data.createdBy,
              createdAt: data.createdAt,
            });
          }
        });
        setSubManagers(Array.from(map.values()));
      },
      (e) => {
        console.warn('Sub managers sync error:', e);
      }
    );
    return () => unsubscribe();
  }, [currentUser]);

  // Fetch Trial Accounts if General Manager (excludes trial accounts)
  useEffect(() => {
    if (!currentUser || currentUser.role !== 'مدير عام' || currentUser.isTrial) return;
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('isTrial', '==', true));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: TrialAccount[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          list.push({
            id: d.id,
            username: data.username || d.id,
            password: data.password || '',
            expiresAt: data.expiresAt || 0,
            createdAt: data.createdAt,
            isDisabled: data.isDisabled || false,
          });
        });
        list.sort((a, b) => (b.expiresAt || 0) - (a.expiresAt || 0));
        setTrialAccounts(list);
      },
      (e) => {
        console.warn('Trial accounts sync error:', e);
      }
    );
    return () => unsubscribe();
  }, [currentUser]);

  // Stop / Disable Trial Account
  const handleStopTrialAccount = async (id: string) => {
    try {
      await updateDoc(doc(db, 'users', id), {
        isDisabled: true,
        expiresAt: Date.now(),
      });
      triggerToast('تم إيقاف الحساب التجريبي بنجاح');
    } catch (e) {
      try {
        await setDoc(doc(db, 'users', id), { isDisabled: true, expiresAt: Date.now() }, { merge: true });
        triggerToast('تم إيقاف الحساب التجريبي بنجاح');
      } catch (err) {
        triggerToast('حدث خطأ أثناء إيقاف الحساب التجريبي');
      }
    }
  };

  // Delete Trial Account
  const handleDeleteTrialAccount = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'users', id));
      triggerToast('تم حذف الحساب التجريبي بنجاح');
    } catch (e) {
      triggerToast('حدث خطأ أثناء حذف الحساب التجريبي');
    }
  };

  // Secure Login Logic via Firebase Auth
  const handleLogin = async (usernameInput: string, passwordInput: string): Promise<boolean> => {
    const cleanUser = usernameInput.trim().toLowerCase();
    const cleanPass = passwordInput.trim();

    if (!cleanUser || !cleanPass) return false;

    const email = usernameToEmail(cleanUser);

    try {
      // 1. Try Firebase Auth sign-in (skip for demo_ trial accounts)
      if (!cleanUser.startsWith('demo_')) {
        try {
          const userCred = await signInWithEmailAndPassword(auth, email, cleanPass);
          if (userCred.user) {
            let role: 'مدير عام' | 'مدير فرعي' = 'مدير عام';
            try {
              const userSnap = await getDoc(doc(db, 'users', userCred.user.uid));
              if (userSnap.exists()) {
                role = (userSnap.data().role as 'مدير عام' | 'مدير فرعي') || 'مدير عام';
              }
            } catch (e) {
              console.warn('Error reading user role from Firestore:', e);
            }
            const u: User = { id: userCred.user.uid, username: cleanUser, role };
            setCurrentUser(u);
            localStorage.setItem('debt_user', JSON.stringify(u));
            triggerToast('تم تسجيل الدخول بنجاح');
            return true;
          }
        } catch (authErr: any) {
          console.warn('Firebase Auth sign-in skipped or failed, falling back to database check:', authErr?.code);
        }
      }

      // 2. Strict Database Verification (Check 'users' for GM and 'sub_managers' for Sub-managers)
      
      // Check 'users' collection (General Managers / Main Accounts)
      try {
        const userSnap = await getDoc(doc(db, 'users', cleanUser));
        if (userSnap.exists()) {
          const data = userSnap.data();

          // Check if trial account has expired
          if (data.isTrial && data.expiresAt && Date.now() >= data.expiresAt) {
            try {
              await deleteDoc(doc(db, 'users', userSnap.id));
            } catch (e) {}
            triggerToast('عذراً، انتهت صلاحية هذا الحساب التجريبي (ساعة واحدة)!');
            return false;
          }

          if (data.password && data.password !== cleanPass) {
            triggerToast('كلمة المرور غير صحيحة!');
            return false;
          }
          const u: User = {
            id: userSnap.id || cleanUser,
            username: data.username || cleanUser,
            role: data.role || (data.isTrial ? 'حساب تجريبي' : 'مدير عام'),
            isTrial: data.isTrial || false,
            expiresAt: data.expiresAt,
          };
          setCurrentUser(u);
          localStorage.setItem('debt_user', JSON.stringify(u));
          triggerToast(`تم تسجيل الدخول بنجاح ${u.isTrial ? '(حساب تجريبي)' : `بصفة ${u.role}`}`);
          return true;
        }

        // Query 'users' by username field if doc id differs
        const qUser = query(collection(db, 'users'), where('username', '==', cleanUser));
        const qUserSnap = await getDocs(qUser);
        if (!qUserSnap.empty) {
          const docSnap = qUserSnap.docs[0];
          const data = docSnap.data();

          if (data.isTrial && data.expiresAt && Date.now() >= data.expiresAt) {
            try {
              await deleteDoc(doc(db, 'users', docSnap.id));
            } catch (e) {}
            triggerToast('عذراً، انتهت صلاحية هذا الحساب التجريبي (ساعة واحدة)!');
            return false;
          }

          if (data.password && data.password !== cleanPass) {
            triggerToast('كلمة المرور غير صحيحة!');
            return false;
          }
          const u: User = {
            id: docSnap.id,
            username: data.username || cleanUser,
            role: data.role || (data.isTrial ? 'حساب تجريبي' : 'مدير عام'),
            isTrial: data.isTrial || false,
            expiresAt: data.expiresAt,
          };
          setCurrentUser(u);
          localStorage.setItem('debt_user', JSON.stringify(u));
          triggerToast(`تم تسجيل الدخول بنجاح ${u.isTrial ? '(حساب تجريبي)' : `بصفة ${u.role}`}`);
          return true;
        }
      } catch (e) {
        console.warn('Firestore users lookup error:', e);
      }

      // Check 'sub_managers' collection
      try {
        const subSnap = await getDoc(doc(db, 'sub_managers', cleanUser));
        if (subSnap.exists()) {
          const data = subSnap.data();
          if (data.password && data.password !== cleanPass) {
            triggerToast('كلمة المرور غير صحيحة!');
            return false;
          }
          const u: User = {
            id: subSnap.id || cleanUser,
            username: data.username || cleanUser,
            role: 'مدير فرعي',
          };
          setCurrentUser(u);
          localStorage.setItem('debt_user', JSON.stringify(u));
          triggerToast(`تم تسجيل الدخول بصفة مدير فرعي (${u.username})`);
          return true;
        }

        // Query 'sub_managers' by username field if doc id differs
        const qSub = query(collection(db, 'sub_managers'), where('username', '==', cleanUser));
        const qSubSnap = await getDocs(qSub);
        if (!qSubSnap.empty) {
          const docSnap = qSubSnap.docs[0];
          const data = docSnap.data();
          if (data.password && data.password !== cleanPass) {
            triggerToast('كلمة المرور غير صحيحة!');
            return false;
          }
          const u: User = {
            id: docSnap.id,
            username: data.username || cleanUser,
            role: 'مدير فرعي',
          };
          setCurrentUser(u);
          localStorage.setItem('debt_user', JSON.stringify(u));
          triggerToast(`تم تسجيل الدخول بصفة مدير فرعي (${u.username})`);
          return true;
        }
      } catch (e) {
        console.warn('Firestore sub_managers lookup error:', e);
      }

      // 3. Fallback for demo trial users if not yet found in database
      if (cleanUser.startsWith('demo_')) {
        const u: User = {
          id: cleanUser,
          username: cleanUser,
          role: 'حساب تجريبي',
          isTrial: true,
          expiresAt: Date.now() + 3600000,
        };
        setCurrentUser(u);
        localStorage.setItem('debt_user', JSON.stringify(u));
        triggerToast('تم تسجيل الدخول بنجاح (حساب تجريبي)');
        return true;
      }

      // 4. User does not exist in database
      triggerToast('اسم المستخدم أو كلمة المرور غير صحيحة!');
      return false;
    } catch (err) {
      console.error('Login processing error:', err);
      triggerToast('تعذر تسجيل الدخول، يرجى التأكد من البيانات والمحاولة مجدداً');
      return false;
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentUser(null);
      localStorage.removeItem('debt_user');
      triggerToast('تم تسجيل الخروج بنجاح');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  // Add Customer Action
  const handleAddCustomerSubmit = async (name: string, phone: string, initialDebt: number) => {
    if (!currentUser) return;
    const nowStr = new Date().toISOString().split('T')[0];
    const custRef = collection(db, 'users', currentUser.id, 'customers');

    await addDoc(custRef, {
      name,
      avatarText: name.slice(0, 2),
      phone,
      debt: initialDebt,
      totalAdded: initialDebt,
      totalPaid: 0,
      overdueDays: 0,
      lastDate: nowStr,
      lastTimestamp: Date.now(),
      createdAt: serverTimestamp(),
      history: initialDebt > 0 ? [{ id: Date.now(), type: 'DEBT', amount: initialDebt, date: nowStr, note: 'رصيد أولي' }] : [],
    });

    triggerToast(`تمت إضافة المدين (${name}) وحفظه سحابياً`);
  };

  // Edit Customer Action
  const handleEditCustomerSubmit = async (id: string, name: string, phone: string) => {
    if (!currentUser) return;
    const docRef = doc(db, 'users', currentUser.id, 'customers', id);
    await updateDoc(docRef, {
      name,
      avatarText: name.slice(0, 2),
      phone,
    });
    triggerToast(`تمت تحديث بيانات (${name}) سحابياً`);
  };

  // Delete Customer Action
  const handleDeleteCustomerConfirm = async () => {
    if (!currentUser || !confirmDeleteCustomer) return;
    try {
      const docRef = doc(db, 'users', currentUser.id, 'customers', confirmDeleteCustomer.id);
      await deleteDoc(docRef);
      triggerToast(`تم حذف سجل المدين (${confirmDeleteCustomer.name})`);
    } catch (err) {
      triggerToast('حدث خطأ أثناء حذف سجل المدين');
    } finally {
      setConfirmDeleteCustomer(null);
    }
  };

  // Transaction Action (Add Debt / Payment)
  const handleTransactionSubmit = async (
    customer: Customer,
    amount: number,
    type: 'ADD_DEBT' | 'PAYMENT'
  ) => {
    if (!currentUser) return;
    const nowStr = new Date().toISOString().split('T')[0];
    const currentDebt = customer.debt || 0;
    const currentAdded = customer.totalAdded || currentDebt;
    const currentPaid = customer.totalPaid || 0;
    const history = customer.history || [];

    let newDebt = currentDebt;
    let newAdded = currentAdded;
    let newPaid = currentPaid;
    let newHistoryItem: HistoryItem;

    if (type === 'ADD_DEBT') {
      newDebt += amount;
      newAdded += amount;
      newHistoryItem = { id: Date.now(), type: 'DEBT', amount, date: nowStr, note: 'إضافة دين جديد' };
    } else {
      newDebt = Math.max(0, currentDebt - amount);
      newPaid += amount;
      newHistoryItem = { id: Date.now(), type: 'PAYMENT', amount, date: nowStr, note: 'تسديد دفعة حساب' };
    }

    const updatedHistory = [newHistoryItem, ...history];
    const docRef = doc(db, 'users', currentUser.id, 'customers', customer.id);

    await updateDoc(docRef, {
      debt: newDebt,
      totalAdded: newAdded,
      totalPaid: newPaid,
      lastDate: nowStr,
      lastTimestamp: Date.now(),
      history: updatedHistory,
    });

    triggerToast(
      type === 'ADD_DEBT'
        ? `تم إضافة دين (${formatNumberWithCommas(amount)} د.ع) إلى ${customer.name}`
        : `تم تسجيل تسديد (${formatNumberWithCommas(amount)} د.ع) لـ ${customer.name}`
    );
  };

  // WhatsApp Reminder Trigger
  const handleSendWhatsApp = (customer: Customer) => {
    if (!customer.phone) {
      triggerToast('لا يوجد رقم هاتف مسجل لهذا المدين!');
      return;
    }
    const cleanPhone = formatIraqiPhoneForWhatsApp(customer.phone);
    if (!cleanPhone) {
      triggerToast('رقم الهاتف المسجل غير صحيح!');
      return;
    }

    const debtVal = formatNumberWithCommas(customer.debt || 0);
    const text = encodeURIComponent(
      `السلام عليكم أخي الكريم (${customer.name}) 👋\nنود تذكيركم بالديون المستحقة في دفتر الديون: *${debtVal} د.ع*.\nيرجى التواصل معنا لتسديد الدفعة القادمة. شكراً لتعاونكم!`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${text}`, '_blank');
  };

  // User Settings Actions
  const handleSaveOverdueDaysLimit = async (days: number) => {
    setOverdueDaysLimit(days);
    if (currentUser) {
      try {
        const userRef = doc(db, 'users', currentUser.id);
        await setDoc(userRef, { overdueDaysLimit: days }, { merge: true });
        triggerToast(`تم تحديد مدة التأخير (${days} يوم) وحفظها سحابياً`);
      } catch (err) {
        triggerToast(`تم تحديث مدة التأخير (${days} يوم)`);
      }
    }
  };

  const handleSaveHighDebtLimit = async (limit: number) => {
    setHighDebtLimit(limit);
    if (currentUser) {
      try {
        const userRef = doc(db, 'users', currentUser.id);
        await setDoc(userRef, { highDebtLimit: limit }, { merge: true });
        triggerToast(`تم تحديث حد الديون المرتفعة (${formatNumberWithCommas(limit)} د.ع)`);
      } catch (err) {
        triggerToast('تم تحديث حد الديون المرتفعة');
      }
    }
  };

  const handleChangePassword = async (newPass: string) => {
    if (!currentUser) {
      triggerToast('يرجى تسجيل الدخول أولاً');
      return;
    }

    let updatedSuccess = false;

    // 1. Update in Firebase Auth if signed in
    if (auth.currentUser) {
      try {
        await firebaseUpdatePassword(auth.currentUser, newPass);
        updatedSuccess = true;
      } catch (err: any) {
        console.warn('Firebase Auth password update info:', err);
        if (err?.code === 'auth/requires-recent-login') {
          triggerToast('يرجى إعادة تسجيل الدخول لتأكيد الهوية وتغيير كلمة المرور');
          return;
        }
      }
    }

    // 2. Sync password change to Firestore cloud record
    try {
      if (currentUser.role === 'مدير عام') {
        await setDoc(doc(db, 'users', currentUser.id), { password: newPass, updatedAt: serverTimestamp() }, { merge: true });
        updatedSuccess = true;
      } else {
        await setDoc(doc(db, 'sub_managers', currentUser.id), { password: newPass, updatedAt: serverTimestamp() }, { merge: true });
        if (currentUser.username) {
          await setDoc(doc(db, 'sub_managers', currentUser.username.toLowerCase()), { password: newPass, updatedAt: serverTimestamp() }, { merge: true });
        }
        await setDoc(doc(db, 'users', currentUser.id), { password: newPass, updatedAt: serverTimestamp() }, { merge: true });
        updatedSuccess = true;
      }
    } catch (err) {
      console.error('Firestore password update error:', err);
    }

    if (updatedSuccess) {
      triggerToast('تم تحديث كلمة المرور سحابياً بنجاح');
    } else {
      triggerToast('حدث خطأ أثناء تغيير كلمة المرور');
    }
  };

  const handleAddSubManager = async (usernameInput: string, pass: string) => {
    if (!currentUser || currentUser.role !== 'مدير عام') {
      triggerToast('عفواً، إضافة المدراء الفرعيين مسموحة للمدير العام فقط');
      return;
    }

    const cleanUser = usernameInput.trim().toLowerCase();
    const email = usernameToEmail(cleanUser);

    try {
      const secondaryAuth = getSecondaryAuth();
      const cred = await createUserWithEmailAndPassword(secondaryAuth, email, pass);
      const subUid = cred.user.uid;

      // 1. Create user document in users collection (WITHOUT password)
      await setDoc(doc(db, 'users', subUid), {
        username: cleanUser,
        role: 'مدير فرعي',
        createdBy: currentUser.id,
        createdAt: serverTimestamp(),
      });

      // 2. Create entry in sub_managers collection (WITH password)
      await setDoc(doc(db, 'sub_managers', subUid), {
        id: subUid,
        username: cleanUser,
        password: pass,
        role: 'مدير فرعي',
        createdBy: currentUser.id,
        createdAt: new Date().toISOString(),
      });
      await setDoc(doc(db, 'sub_managers', cleanUser), {
        id: cleanUser,
        username: cleanUser,
        password: pass,
        role: 'مدير فرعي',
        createdBy: currentUser.id,
        createdAt: new Date().toISOString(),
      });

      // 3. Immediately sign out secondary auth instance so GM session remains active
      await signOut(secondaryAuth);

      triggerToast(`تمت إضافة المدير الفرعي (${cleanUser}) وتأمينه في Firebase Auth`);
    } catch (e: any) {
      const errorCode = e?.code || '';
      if (errorCode === 'auth/configuration-not-found' || errorCode === 'auth/operation-not-allowed') {
        console.warn('Firebase Auth is unconfigured in Console, using DB registration fallback');
        try {
          const subId = cleanUser;
          await setDoc(doc(db, 'users', subId), {
            username: cleanUser,
            role: 'مدير فرعي',
            createdBy: currentUser.id,
            createdAt: serverTimestamp(),
          });
          await setDoc(doc(db, 'sub_managers', subId), {
            id: subId,
            username: cleanUser,
            password: pass,
            role: 'مدير فرعي',
            createdBy: currentUser.id,
            createdAt: new Date().toISOString(),
          });
          triggerToast(`تمت إضافة المدير الفرعي (${cleanUser}) بنجاح`);
          return;
        } catch (dbErr) {
          console.error('Fallback creation error:', dbErr);
        }
      } else {
        console.error('Add sub manager error:', e);
      }

      if (e?.code === 'auth/email-already-in-use') {
        triggerToast('اسم المستخدم الفرعي مسجل مسبقاً!');
      } else {
        triggerToast('حدث خطأ أثناء إضافة المدير الفرعي');
      }
    }
  };

  const handleDeleteSubManagerConfirm = async () => {
    if (!confirmDeleteSubManagerId) return;
    try {
      await deleteDoc(doc(db, 'sub_managers', confirmDeleteSubManagerId));
      await deleteDoc(doc(db, 'users', confirmDeleteSubManagerId));
      triggerToast('تم إلغاء حساب المدير الفرعي بنجاح');
    } catch (e) {
      triggerToast('حدث خطأ أثناء حذف الحساب الفرعي');
    } finally {
      setConfirmDeleteSubManagerId(null);
    }
  };

  // Calculations & Metrics
  const totalCurrentDebt = useMemo(
    () => customers.reduce((acc, c) => acc + (c.debt || 0), 0),
    [customers]
  );
  const totalAddedDebts = useMemo(
    () => customers.reduce((acc, c) => acc + (c.totalAdded || c.debt || 0), 0),
    [customers]
  );
  const totalPaidDebts = useMemo(
    () => customers.reduce((acc, c) => acc + (c.totalPaid || 0), 0),
    [customers]
  );
  const activeCustomersCount = useMemo(
    () => customers.filter((c) => (c.debt || 0) > 0).length,
    [customers]
  );
  const highDebtCount = useMemo(
    () => customers.filter((c) => (c.debt || 0) >= highDebtLimit).length,
    [customers, highDebtLimit]
  );
  const overdueCustomers = useMemo(
    () =>
      customers
        .filter(
          (c) => (c.debt || 0) > 0 && getCustomerOverdueDays(c) >= overdueDaysLimit
        )
        .sort((a, b) => (b.debt || 0) - (a.debt || 0)),
    [customers, overdueDaysLimit]
  );

  // Search & Filtered Customers Computation (Sorted by highest debt first)
  const filteredCustomers = useMemo(() => {
    return customers
      .filter((c) => {
        const matchesSearch =
          c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (c.phone && c.phone.includes(searchQuery));

        if (!matchesSearch) return false;

        if (filterType === 'HAS_DEBT') return (c.debt || 0) > 0;
        if (filterType === 'NO_DEBT') return (c.debt || 0) === 0;
        if (filterType === 'HIGH_DEBT') return (c.debt || 0) >= highDebtLimit;

        return true;
      })
      .sort((a, b) => {
        const debtDiff = (b.debt || 0) - (a.debt || 0);
        if (debtDiff !== 0) return debtDiff;
        return (b.lastTimestamp || 0) - (a.lastTimestamp || 0);
      });
  }, [customers, searchQuery, filterType, highDebtLimit]);

  // If not logged in, show clean Login screen
  if (!currentUser) {
    return <LoginView onLogin={handleLogin} triggerToast={triggerToast} />;
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans selection:bg-slate-900 selection:text-white sm:py-6 sm:px-4 flex flex-col justify-center items-center" dir="rtl">
      <Toast message={toastMessage} />

      <div className="w-full max-w-2xl bg-slate-50 min-h-screen sm:min-h-[92vh] sm:h-[92vh] sm:rounded-3xl shadow-[0_20px_50px_rgba(15,23,42,0.12)] border border-slate-200/80 flex flex-col overflow-hidden relative">
        
        {/* Trial Account Live Banner */}
        {currentUser.isTrial && trialSecondsLeft !== null && (
          <div className="bg-amber-50 border-b border-amber-200 px-3.5 py-2 flex items-center justify-between text-xs font-bold text-amber-900 shrink-0">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
              </span>
              <i className="fa-solid fa-clock text-amber-600 text-xs"></i>
              <span>حساب تجريبي (60 دقيقة)</span>
            </div>

            <div className="flex items-center gap-1.5 bg-amber-100 border border-amber-300/80 px-2.5 py-0.5 rounded-md">
              <span className="text-[10px] text-amber-800 font-semibold">المتبقي:</span>
              <span className="font-mono font-extrabold text-amber-900 text-xs tracking-wider">
                {formatTrialTimer(trialSecondsLeft)}
              </span>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-3.5 sm:p-4 pb-16 flex flex-col min-h-0 overflow-hidden">
          <Header currentUser={currentUser} onLogout={handleLogout} />

          {activeTab === 'main' && (
            <MainDebtView
              customers={customers}
              filteredCustomers={filteredCustomers}
              isLoading={isLoading}
              totalCurrentDebt={totalCurrentDebt}
              activeCustomersCount={activeCustomersCount}
              highDebtCount={highDebtCount}
              overdueCount={overdueCustomers.length}
              highDebtLimit={highDebtLimit}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              filterType={filterType}
              setFilterType={setFilterType}
              activeMenuId={activeMenuId}
              setActiveMenuId={setActiveMenuId}
              onOpenAddModal={() =>
                setCustomerModalState({ isOpen: true, mode: 'ADD', customer: null })
              }
              onOpenStatement={(cust) =>
                setStatementModalState({ isOpen: true, customer: cust })
              }
              onSendWhatsApp={handleSendWhatsApp}
              onEditCustomer={(cust) =>
                setCustomerModalState({ isOpen: true, mode: 'EDIT', customer: cust })
              }
              onDeleteCustomer={(cust) => setConfirmDeleteCustomer(cust)}
              onAddDebt={(cust) =>
                setTransactionModalState({ isOpen: true, type: 'ADD_DEBT', customer: cust })
              }
              onPayment={(cust) =>
                setTransactionModalState({ isOpen: true, type: 'PAYMENT', customer: cust })
              }
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView
              customers={customers}
              totalCurrentDebt={totalCurrentDebt}
              totalAddedDebts={totalAddedDebts}
              totalPaidDebts={totalPaidDebts}
              highDebtCount={highDebtCount}
              activeCustomersCount={activeCustomersCount}
              overdueCount={overdueCustomers.length}
            />
          )}

          {activeTab === 'overdue' && (
            <OverdueView
              overdueCustomers={overdueCustomers}
              overdueDaysLimit={overdueDaysLimit}
              onSendWhatsApp={handleSendWhatsApp}
              onOpenStatement={(cust) =>
                setStatementModalState({ isOpen: true, customer: cust })
              }
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              currentUser={currentUser}
              onLogout={handleLogout}
              overdueDaysLimit={overdueDaysLimit}
              onSaveOverdueDaysLimit={handleSaveOverdueDaysLimit}
              highDebtLimit={highDebtLimit}
              onSaveHighDebtLimit={handleSaveHighDebtLimit}
              onChangePassword={handleChangePassword}
              subManagers={subManagers}
              onAddSubManager={handleAddSubManager}
              onDeleteSubManager={(id) => setConfirmDeleteSubManagerId(id)}
              trialAccounts={trialAccounts}
              onStopTrialAccount={handleStopTrialAccount}
              onDeleteTrialAccount={handleDeleteTrialAccount}
            />
          )}
        </main>

        {/* Navigation Bar */}
        <Navigation
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          overdueCount={overdueCustomers.length}
        />
      </div>

      {/* Modals */}
      <CustomerModal
        isOpen={customerModalState.isOpen}
        mode={customerModalState.mode}
        customer={customerModalState.customer}
        onClose={() => setCustomerModalState({ isOpen: false, mode: 'ADD', customer: null })}
        onSubmitAdd={handleAddCustomerSubmit}
        onSubmitEdit={handleEditCustomerSubmit}
      />

      <TransactionModal
        isOpen={transactionModalState.isOpen}
        type={transactionModalState.type}
        customer={transactionModalState.customer}
        onClose={() => setTransactionModalState({ isOpen: false, type: null, customer: null })}
        onSubmit={handleTransactionSubmit}
      />

      <StatementModal
        isOpen={statementModalState.isOpen}
        customer={statementModalState.customer}
        onClose={() => setStatementModalState({ isOpen: false, customer: null })}
        onSendWhatsApp={handleSendWhatsApp}
      />

      <ConfirmModal
        isOpen={!!confirmDeleteCustomer}
        title="حذف سجل مدين"
        message={`هل أنت تأكد من إرادتك لحذف سجل المدين (${confirmDeleteCustomer?.name}) بشكل نهائي؟`}
        confirmText="حذف نهائي"
        cancelText="إلغاء"
        isDanger={true}
        onConfirm={handleDeleteCustomerConfirm}
        onCancel={() => setConfirmDeleteCustomer(null)}
      />

      <ConfirmModal
        isOpen={!!confirmDeleteSubManagerId}
        title="حذف حساب فرعي"
        message={`هل أنت تأكد من إرادتك لحذف المدير الفرعي (${confirmDeleteSubManagerId})؟`}
        confirmText="حذف الحساب"
        cancelText="إلغاء"
        isDanger={true}
        onConfirm={handleDeleteSubManagerConfirm}
        onCancel={() => setConfirmDeleteSubManagerId(null)}
      />
    </div>
  );
}

export default App;
