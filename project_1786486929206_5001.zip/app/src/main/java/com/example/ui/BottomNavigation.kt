package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun POSBottomNavigation(viewModel: POSViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    androidx.compose.material3.Surface(
        color = POSSurface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        tonalElevation = 0.dp,
        shadowElevation = 12.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            modifier = Modifier.navigationBarsPadding(),
            tonalElevation = 0.dp
        ) {
            // Tab 1: الرئيسية
            NavigationBarItem(
                selected = currentTab == 0,
                onClick = { viewModel.selectTab(0) },
                modifier = Modifier.testTag("nav_tab_home"),
                label = { 
                    Text(
                        text = "الرئيسية", 
                        fontSize = 11.sp, 
                        fontWeight = if (currentTab == 0) FontWeight.Bold else FontWeight.Medium
                    ) 
                },
                icon = { 
                    Icon(
                        imageVector = if (currentTab == 0) Icons.Default.Storefront else Icons.Outlined.Storefront, 
                        contentDescription = "الرئيسية"
                    ) 
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = POSPrimary.copy(alpha = 0.08f),
                    selectedIconColor = POSPrimary,
                    selectedTextColor = POSPrimary,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )

            // Tab 2: المصاريف
            NavigationBarItem(
                selected = currentTab == 1,
                onClick = { viewModel.selectTab(1) },
                modifier = Modifier.testTag("nav_tab_expenses"),
                label = { 
                    Text(
                        text = "المصاريف", 
                        fontSize = 11.sp, 
                        fontWeight = if (currentTab == 1) FontWeight.Bold else FontWeight.Medium
                    ) 
                },
                icon = { 
                    Icon(
                        imageVector = if (currentTab == 1) Icons.Default.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet, 
                        contentDescription = "المصاريف"
                    ) 
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = POSPrimary.copy(alpha = 0.08f),
                    selectedIconColor = POSPrimary,
                    selectedTextColor = POSPrimary,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )

            // Tab 3: الطلبات
            NavigationBarItem(
                selected = currentTab == 2,
                onClick = { viewModel.selectTab(2) },
                modifier = Modifier.testTag("nav_tab_orders"),
                label = { 
                    Text(
                        text = "الطلبات", 
                        fontSize = 11.sp, 
                        fontWeight = if (currentTab == 2) FontWeight.Bold else FontWeight.Medium
                    ) 
                },
                icon = { 
                    Icon(
                        imageVector = if (currentTab == 2) Icons.Default.ReceiptLong else Icons.Outlined.ReceiptLong, 
                        contentDescription = "الطلبات"
                    ) 
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = POSPrimary.copy(alpha = 0.08f),
                    selectedIconColor = POSPrimary,
                    selectedTextColor = POSPrimary,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )

            // Tab 4: الإعدادات
            NavigationBarItem(
                selected = currentTab == 3,
                onClick = { viewModel.selectTab(3) },
                modifier = Modifier.testTag("nav_tab_settings"),
                label = { 
                    Text(
                        text = "الإعدادات", 
                        fontSize = 11.sp, 
                        fontWeight = if (currentTab == 3) FontWeight.Bold else FontWeight.Medium
                    ) 
                },
                icon = { 
                    Icon(
                        imageVector = if (currentTab == 3) Icons.Default.Settings else Icons.Outlined.Settings, 
                        contentDescription = "الإعدادات"
                    ) 
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = POSPrimary.copy(alpha = 0.08f),
                    selectedIconColor = POSPrimary,
                    selectedTextColor = POSPrimary,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )
        }
    }
}
