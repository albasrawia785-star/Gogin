package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.utils.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class POSViewModel(private val repository: POSRepository, private val context: Context) : ViewModel() {

    private val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)

    // --- State: Onboarding Welcome ---
    private val _hasSeenOnboarding = MutableStateFlow(prefs.getBoolean("has_seen_onboarding", false))
    val hasSeenOnboarding: StateFlow<Boolean> = _hasSeenOnboarding.asStateFlow()

    fun completeOnboarding() {
        prefs.edit().putBoolean("has_seen_onboarding", true).apply()
        _hasSeenOnboarding.value = true
    }

    fun resetOnboarding() {
        prefs.edit().putBoolean("has_seen_onboarding", false).apply()
        _hasSeenOnboarding.value = false
    }

    // --- State: Authentication ---
    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _activeUser = MutableStateFlow(prefs.getString("logged_in_user", "") ?: "")
    val activeUser: StateFlow<String> = _activeUser.asStateFlow()

    private val _restaurantName = MutableStateFlow(UserAli.getRestaurantNameFromPrefs(context))
    val restaurantName: StateFlow<String> = _restaurantName.asStateFlow()

    fun refreshRestaurantName() {
        _restaurantName.value = UserAli.getRestaurantNameFromPrefs(context)
    }

    private val _isSuperAdmin = MutableStateFlow(
        prefs.getBoolean("is_super_admin", prefs.getString("logged_in_user", "") == "ali")
    )
    val isSuperAdmin: StateFlow<Boolean> = _isSuperAdmin.asStateFlow()

    private val _clientAccounts = MutableStateFlow<List<UserAccount>>(emptyList())
    val clientAccounts: StateFlow<List<UserAccount>> = _clientAccounts.asStateFlow()

    private val _loginErrorMessage = MutableStateFlow<String?>(null)
    val loginErrorMessage: StateFlow<String?> = _loginErrorMessage.asStateFlow()

    private val _isLoggingIn = MutableStateFlow(false)
    val isLoggingIn: StateFlow<Boolean> = _isLoggingIn.asStateFlow()

    fun clearLoginError() {
        _loginErrorMessage.value = null
    }

    private val _isTrialExpired = MutableStateFlow(false)
    val isTrialExpired: StateFlow<Boolean> = _isTrialExpired.asStateFlow()

    private val _showTrialLimitDialog = MutableStateFlow(false)
    val showTrialLimitDialog: StateFlow<Boolean> = _showTrialLimitDialog.asStateFlow()

    fun dismissTrialLimitDialog() {
        _showTrialLimitDialog.value = false
    }

    // --- State: Printer Alert ---
    private val _printerAlertMessage = MutableStateFlow<String?>(null)
    val printerAlertMessage: StateFlow<String?> = _printerAlertMessage.asStateFlow()

    fun clearPrinterAlert() {
        _printerAlertMessage.value = null
    }

    fun triggerPrinterAlert(printerName: String) {
        _printerAlertMessage.value = "إحدى الطابعات لا تعمل حالياً، يرجى التحقق من تشغيل الطابعة أو عودة الكهرباء\n\nاسم الطابعة المعطلة: $printerName"
    }

    init {
        com.example.utils.ReceiptPrinterHelper.onPrinterFailure = { printerName, _ ->
            triggerPrinterAlert(printerName)
        }
        com.example.utils.AppConfig.load(context)
        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }
        checkTrialExpiration()

        // Purge legacy "Xprinter" or "الافتراضية" on startup
        val pNameClean = prefs.getString("selected_printer_name", "") ?: ""
        if (pNameClean.contains("Xprinter") || pNameClean.contains("الافتراضية")) {
            prefs.edit()
                .putString("selected_printer_name", "")
                .putString("main_printer_mac", "")
                .apply()
        }
        val kNameClean = prefs.getString("selected_kitchen_printer_name", "") ?: ""
        if (kNameClean.contains("Xprinter") || kNameClean.contains("الافتراضية")) {
            prefs.edit()
                .putString("selected_kitchen_printer_name", "")
                .putString("kitchen_printer_mac", "")
                .apply()
        }
        
        // Extract MAC addresses on init if names exist but macs don't
        val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
        val pName = prefs.getString("selected_printer_name", "") ?: ""
        if (prefs.getString("main_printer_mac", "").isNullOrBlank() && pName.isNotBlank() && !pName.contains("Xprinter") && !pName.contains("الافتراضية")) {
            val extracted = addressRegex.find(pName)?.value ?: ""
            if (extracted.isNotBlank()) {
                prefs.edit().putString("main_printer_mac", extracted).apply()
            }
        }
        val kName = prefs.getString("selected_kitchen_printer_name", "") ?: ""
        if (prefs.getString("kitchen_printer_mac", "").isNullOrBlank() && kName.isNotBlank() && !kName.contains("Xprinter") && !kName.contains("الافتراضية")) {
            val extracted = addressRegex.find(kName)?.value ?: ""
            if (extracted.isNotBlank()) {
                prefs.edit().putString("kitchen_printer_mac", extracted).apply()
            }
        }
    }

    fun checkTrialExpiration() {
        val firstLoginTime = prefs.getLong("trial_first_login_time", 0L)
        if (firstLoginTime != 0L) {
            val passedTime = System.currentTimeMillis() - firstLoginTime
            val hours24 = 24 * 60 * 60 * 1000L
            if (passedTime >= hours24) {
                _isTrialExpired.value = true
            }
        }
    }

    fun logout() {
        _isLoggedIn.value = false
        _activeUser.value = ""
        _isSuperAdmin.value = false
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .putString("logged_in_user", "")
            .putBoolean("is_super_admin", false)
            .apply()
        refreshRestaurantName()
    }

    fun login(userName: String, passwordInput: String, onResult: (Boolean) -> Unit = {}): Boolean {
        _loginErrorMessage.value = null
        _isLoggingIn.value = true

        UserAli.login(
            context = context,
            userInput = userName,
            passInput = passwordInput,
            onSuccess = { account, superAdmin ->
                _isLoggingIn.value = false
                _isSuperAdmin.value = superAdmin
                val user = if (superAdmin) UserAliConfig.SUPER_ADMIN_USERNAME else (account?.username ?: userName)
                _activeUser.value = user
                _isLoggedIn.value = true
                prefs.edit()
                    .putBoolean("is_logged_in", true)
                    .putString("logged_in_user", user)
                    .putBoolean("is_super_admin", superAdmin)
                    .apply()

                AppConfig.load(context)
                refreshRestaurantName()
                onResult(true)
            },
            onError = { errorMsg ->
                _isLoggingIn.value = false
                _loginErrorMessage.value = errorMsg
                onResult(false)
            }
        )

        // Immediate sync check for super admin ali / 19971997
        if (userName.trim().equals(UserAliConfig.SUPER_ADMIN_USERNAME, ignoreCase = true) &&
            passwordInput.trim() == UserAliConfig.SUPER_ADMIN_PASSWORD
        ) {
            return true
        }
        return _isLoggedIn.value
    }

    init {
        UserAli.ensureFirebaseInitialized(context)
    }

    fun registerNewClient(
        username: String,
        pass: String,
        restaurantName: String,
        phoneNumber: String,
        licenseType: String,
        trialDays: Int,
        onComplete: (Boolean, String?) -> Unit
    ) {
        UserAli.registerNewClient(
            context = context,
            username = username,
            pass = pass,
            restaurantName = restaurantName,
            phoneNumber = phoneNumber,
            licenseType = licenseType,
            trialDays = trialDays,
            onComplete = { success, msg ->
                if (success) {
                    fetchAllClientAccounts()
                }
                onComplete(success, msg)
            }
        )
    }

    fun fetchAllClientAccounts() {
        UserAli.fetchAllAccounts(
            context = context,
            onResult = { list ->
                _clientAccounts.value = list
            },
            onError = { error ->
                android.util.Log.e("POSViewModel", "Error fetching accounts: $error")
            }
        )
    }

    fun toggleClientAccountStatus(keyId: String, currentStatus: Boolean, onComplete: (Boolean) -> Unit = {}) {
        UserAli.toggleAccountStatus(context = context, keyId = keyId, currentStatus = currentStatus) { success ->
            if (success) {
                fetchAllClientAccounts()
            }
            onComplete(success)
        }
    }

    fun deleteClientAccount(keyId: String, onComplete: (Boolean) -> Unit = {}) {
        UserAli.deleteAccount(context = context, keyId = keyId) { success ->
            if (success) {
                fetchAllClientAccounts()
            }
            onComplete(success)
        }
    }

    // --- State: Order Service Type ---
    private val _orderType = MutableStateFlow("صالة") // "صالة", "سفري", or "دلفري"
    val orderType: StateFlow<String> = _orderType.asStateFlow()

    private val _orderTypeDetails = MutableStateFlow("")
    val orderTypeDetails: StateFlow<String> = _orderTypeDetails.asStateFlow()

    private val _customerAddress = MutableStateFlow("")
    val customerAddress: StateFlow<String> = _customerAddress.asStateFlow()

    private val _deliveryPriceType = MutableStateFlow("مجاني") // "مجاني" or "قيمة التوصيل"
    val deliveryPriceType: StateFlow<String> = _deliveryPriceType.asStateFlow()

    private val _deliveryFee = MutableStateFlow(0.0)
    val deliveryFee: StateFlow<Double> = _deliveryFee.asStateFlow()

    fun setOrderType(type: String) {
        _orderType.value = type
        _orderTypeDetails.value = "" // Reset details on type change
        _customerAddress.value = "" // Reset address on type change
        if (type != "دلفري") {
            _deliveryPriceType.value = "مجاني"
            _deliveryFee.value = 0.0
        }
    }

    fun setCustomerAddress(address: String) {
        _customerAddress.value = address
    }

    fun setOrderTypeDetails(details: String) {
        _orderTypeDetails.value = details
    }

    fun setDeliveryPriceType(type: String) {
        _deliveryPriceType.value = type
        if (type == "مجاني") {
            _deliveryFee.value = 0.0
        }
    }

    fun setDeliveryFee(fee: Double) {
        _deliveryFee.value = fee
    }

    // --- State: Navigation ---
    private val _currentTab = MutableStateFlow(0) // 0: الرئيسية, 1: الطلبات, 2: المنيو, 3: الإعدادات
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun selectTab(index: Int) {
        _currentTab.value = index
    }

    // --- State: Database flows ---
    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _invoiceLimit = MutableStateFlow(50)
    val invoiceLimit: StateFlow<Int> = _invoiceLimit.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val invoices: StateFlow<List<Invoice>> = _invoiceLimit.flatMapLatest { limit ->
        repository.getRecentInvoices(limit)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadMoreInvoices() {
        _invoiceLimit.value += 50
    }

    val shiftLogs: StateFlow<List<ShiftLog>> = repository.allShiftLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allInvoiceItems: StateFlow<List<InvoiceItem>> = repository.allInvoiceItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- State: Home POS Selection ---
    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    val selectedCategoryId: StateFlow<Int?> = _selectedCategoryId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun selectCategory(id: Int?) {
        _selectedCategoryId.value = id
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Filter products reactively based on Category AND Search Query
    val filteredProducts: StateFlow<List<Product>> = combine(
        allProducts,
        _selectedCategoryId,
        categories,
        _searchQuery
    ) { products, catId, cats, query ->
        var result = products
        val activeCatId = catId ?: cats.firstOrNull()?.id
        if (activeCatId != null) {
            result = result.filter { it.categoryId == activeCatId }
        } else {
            result = emptyList()
        }
        if (query.isNotBlank()) {
            result = result.filter { it.name.contains(query, ignoreCase = true) }
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- State: Cart / Active Order ---
    private val _cartItems = MutableStateFlow<Map<Product, Int>>(emptyMap())
    val cartItems: StateFlow<Map<Product, Int>> = _cartItems.asStateFlow()

    val cartTotalCount: StateFlow<Int> = _cartItems.map { map ->
        map.values.sum()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val cartTotalAmount: StateFlow<Double> = combine(
        _cartItems,
        _orderType,
        _deliveryFee
    ) { items, orderType, fee ->
        val itemsSum = items.entries.sumOf { (product, qty) -> product.price * qty }
        if (orderType == "دلفري") {
            itemsSum + fee
        } else {
            itemsSum
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addProductToCart(product: Product) {
        val currentMap = _cartItems.value.toMutableMap()
        val currentQty = currentMap[product] ?: 0
        currentMap[product] = currentQty + 1
        _cartItems.value = currentMap
    }

    fun decreaseProductQty(product: Product) {
        val currentMap = _cartItems.value.toMutableMap()
        val currentQty = currentMap[product] ?: return
        if (currentQty <= 1) {
            currentMap.remove(product)
        } else {
            currentMap[product] = currentQty - 1
        }
        _cartItems.value = currentMap
    }

    fun removeProductFromCart(product: Product) {
        val currentMap = _cartItems.value.toMutableMap()
        currentMap.remove(product)
        _cartItems.value = currentMap
    }

    fun clearCart() {
        _cartItems.value = emptyMap()
        _deliveryPriceType.value = "مجاني"
        _deliveryFee.value = 0.0
    }


    // --- State: Payment Flow ---
    private val _paymentMethod = MutableStateFlow("نقدي") // "نقدي" or "بطاقة"
    val paymentMethod: StateFlow<String> = _paymentMethod.asStateFlow()

    private val _amountReceivedText = MutableStateFlow("")
    val amountReceivedText: StateFlow<String> = _amountReceivedText.asStateFlow()

    fun updatePaymentMethod(method: String) {
        _paymentMethod.value = method
        if (method == "بطاقة") {
            // Card payment usually receives exact amount
            val formatter = java.text.DecimalFormat("#,###", java.text.DecimalFormatSymbols(java.util.Locale.ENGLISH))
            _amountReceivedText.value = formatter.format(cartTotalAmount.value)
        } else {
            _amountReceivedText.value = ""
        }
    }

    fun updateAmountReceived(amountStr: String) {
        val clean = amountStr.replace(",", "")
        if (clean.isEmpty() || clean.all { it.isDigit() }) {
            val formatter = java.text.DecimalFormat("#,###", java.text.DecimalFormatSymbols(java.util.Locale.ENGLISH))
            val formatted = if (clean.isEmpty()) "" else {
                clean.toDoubleOrNull()?.let { formatter.format(it) } ?: clean
            }
            _amountReceivedText.value = formatted
        }
    }

    val amountReceived: StateFlow<Double> = _amountReceivedText.map { text ->
        text.replace(",", "").toDoubleOrNull() ?: 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val amountChange: StateFlow<Double> = combine(
        cartTotalAmount,
        amountReceived,
        _paymentMethod
    ) { total, received, method ->
        if (method == "بطاقة") {
            0.0
        } else {
            val change = received - total
            if (change > 0) change else 0.0
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    private val _showPaymentDialog = MutableStateFlow(false)
    val showPaymentDialog: StateFlow<Boolean> = _showPaymentDialog.asStateFlow()

    fun setShowPaymentDialog(show: Boolean) {
        _showPaymentDialog.value = show
        if (show) {
            // Pre-fill amount received with standard suggestions or exact amount
            _amountReceivedText.value = ""
            _orderTypeDetails.value = "" // Reset details on fresh checkout dialog opening
            _customerAddress.value = "" // Reset address on fresh checkout dialog opening
        }
    }

    fun submitOrder(onSuccess: (Long) -> Unit) {
        val total = cartTotalAmount.value
        val method = _paymentMethod.value
        val received = if (method == "بطاقة") total else amountReceived.value
        val change = if (method == "بطاقة") 0.0 else amountChange.value

        viewModelScope.launch {
            val activeShift = shiftLogs.value.firstOrNull { it.status == "مفتوحة" }
            val currentShiftId = activeShift?.id ?: 0

            val invoice = Invoice(
                totalAmount = total,
                paymentMethod = method,
                amountReceived = received,
                amountChange = change,
                status = "مدفوعة",
                shiftId = currentShiftId,
                orderType = _orderType.value,
                orderTypeDetails = _orderTypeDetails.value,
                customerAddress = _customerAddress.value
            )

            val items = _cartItems.value.map { (product, qty) ->
                InvoiceItem(
                    invoiceNumber = 0L, // Will be replaced in repository
                    productName = product.name,
                    productPrice = product.price,
                    productCost = 0.0,
                    quantity = qty
                )
            }

            val invoiceNo = repository.createInvoice(invoice, items)
            clearCart()
            onSuccess(invoiceNo)
        }
    }


    // --- State: Menu Management CRUD ---
    // Section Management
    fun addCategory(name: String) {
        viewModelScope.launch {
            repository.insertCategory(Category(name = name))
        }
    }

    fun editCategory(category: Category) {
        viewModelScope.launch {
            repository.updateCategory(category)
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
        }
    }

    // Product Management
    fun addProduct(name: String, categoryId: Int, price: Double, imageResName: String) {
        viewModelScope.launch {
            repository.insertProduct(Product(
                name = name,
                categoryId = categoryId,
                price = price,
                imageResName = imageResName
            ))
        }
    }

    fun editProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }


    // --- State: Settings Custom Settings ---
    private val _printerName = MutableStateFlow(
        prefs.getString("selected_printer_name", "").let {
            if (it == null || it.contains("Xprinter") || it.contains("الافتراضية")) "" else it
        }
    )
    val printerName: StateFlow<String> = _printerName.asStateFlow()

    private val _mainPrinterMac = MutableStateFlow(
        prefs.getString("main_printer_mac", "").let {
            if (it == null || it.contains("Xprinter") || it.contains("الافتراضية")) "" else it
        }
    )
    val mainPrinterMac: StateFlow<String> = _mainPrinterMac.asStateFlow()

    private val _selectedKitchenPrinterName = MutableStateFlow(
        prefs.getString("selected_kitchen_printer_name", "").let {
            if (it == null || it.contains("Xprinter") || it.contains("الافتراضية")) "" else it
        }
    )
    val selectedKitchenPrinterName: StateFlow<String> = _selectedKitchenPrinterName.asStateFlow()

    private val _kitchenPrinterMac = MutableStateFlow(
        prefs.getString("kitchen_printer_mac", "").let {
            if (it == null || it.contains("Xprinter") || it.contains("الافتراضية")) "" else it
        }
    )
    val kitchenPrinterMac: StateFlow<String> = _kitchenPrinterMac.asStateFlow()

    // Real-time Status texts
    private val _mainPrinterStatus = MutableStateFlow(prefs.getString("main_printer_status", "غير متصلة، جاهزة للفحص") ?: "غير متصلة، جاهزة للفحص")
    val mainPrinterStatus: StateFlow<String> = _mainPrinterStatus.asStateFlow()

    private val _kitchenPrinterStatus = MutableStateFlow(prefs.getString("kitchen_printer_status", "غير متصلة، جاهزة للفحص") ?: "غير متصلة، جاهزة للفحص")
    val kitchenPrinterStatus: StateFlow<String> = _kitchenPrinterStatus.asStateFlow()

    // Discovery states
    private val _isScanningMainPrinter = MutableStateFlow(false)
    val isScanningMainPrinter: StateFlow<Boolean> = _isScanningMainPrinter.asStateFlow()

    private val _isScanningKitchenPrinter = MutableStateFlow(false)
    val isScanningKitchenPrinter: StateFlow<Boolean> = _isScanningKitchenPrinter.asStateFlow()

    private val _discoveredMainPrinters = MutableStateFlow<List<String>>(emptyList())
    val discoveredMainPrinters: StateFlow<List<String>> = _discoveredMainPrinters.asStateFlow()

    private val _discoveredKitchenPrinters = MutableStateFlow<List<String>>(emptyList())
    val discoveredKitchenPrinters: StateFlow<List<String>> = _discoveredKitchenPrinters.asStateFlow()

    private var mainDiscoveryReceiver: android.content.BroadcastReceiver? = null
    private var kitchenDiscoveryReceiver: android.content.BroadcastReceiver? = null

    fun updatePrinterName(name: String) {
        _printerName.value = name
        val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
        val mac = addressRegex.find(name)?.value ?: name
        _mainPrinterMac.value = mac
        prefs.edit()
            .putString("selected_printer_name", name)
            .putString("main_printer_mac", mac)
            .apply()
    }

    fun updateSelectedKitchenPrinterName(name: String) {
        _selectedKitchenPrinterName.value = name
        val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
        val mac = addressRegex.find(name)?.value ?: name
        _kitchenPrinterMac.value = mac
        prefs.edit()
            .putString("selected_kitchen_printer_name", name)
            .putString("kitchen_printer_mac", mac)
            .apply()
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun startDiscoveryForMainPrinter() {
        if (_isScanningMainPrinter.value) return
        _isScanningMainPrinter.value = true
        _discoveredMainPrinters.value = emptyList()

        val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            _isScanningMainPrinter.value = false
            return
        }

        val foundPrintersMap = mutableMapOf<String, Int>()

        try {
            val paired = adapter.bondedDevices
            if (paired != null) {
                for (d in paired) {
                    val name = d.name ?: "Unknown"
                    val address = d.address ?: ""
                    val btClass = d.bluetoothClass
                    val majorClass = btClass?.majorDeviceClass ?: 0
                    val deviceClass = btClass?.deviceClass ?: 0
                    if (com.example.utils.BluetoothPrinterService.isThermalPrinter(name, majorClass, deviceClass, isBonded = true)) {
                        foundPrintersMap[address] = -50
                    }
                }
            }
        } catch (e: SecurityException) {
            e.printStackTrace()
        }

        val receiver = com.example.utils.BluetoothPrinterService.scanNearbyPrinters(
            context = context,
            onDeviceFound = { name, address, rssi, distance ->
                foundPrintersMap[address] = rssi
            },
            onScanFinished = {}
        )
        mainDiscoveryReceiver = receiver

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try {
                adapter.cancelDiscovery()
                if (mainDiscoveryReceiver != null) {
                    context.unregisterReceiver(mainDiscoveryReceiver)
                    mainDiscoveryReceiver = null
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val bondedAddresses = try {
                adapter.bondedDevices?.map { it.address }?.toSet() ?: emptySet()
            } catch (e: SecurityException) {
                emptySet()
            }

            val list = foundPrintersMap.entries.map { entry ->
                val address = entry.key
                val rssi = entry.value
                val name = try {
                    adapter.getRemoteDevice(address)?.name ?: "Thermal Printer"
                } catch (e: SecurityException) {
                    "Thermal Printer"
                }
                val isBonded = bondedAddresses.contains(address)
                val distance = Math.pow(10.0, (-60.0 - rssi) / 22.0)
                val distanceStr = String.format(java.util.Locale.ENGLISH, "%.1fm", distance)
                val prefix = if (isBonded) "[جهاز مقترن] " else "[جهاز نشط] "
                val itemText = "$prefix$name ($address) - إشارة: ${rssi}dBm (~$distanceStr)"
                Pair(itemText, isBonded)
            }
            .sortedWith(compareByDescending { it.second })
            .map { it.first }

            _discoveredMainPrinters.value = list
            _isScanningMainPrinter.value = false
        }, 4000)
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun startDiscoveryForKitchenPrinter() {
        if (_isScanningKitchenPrinter.value) return
        _isScanningKitchenPrinter.value = true
        _discoveredKitchenPrinters.value = emptyList()

        val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            _isScanningKitchenPrinter.value = false
            return
        }

        val foundPrintersMap = mutableMapOf<String, Int>()

        try {
            val paired = adapter.bondedDevices
            if (paired != null) {
                for (d in paired) {
                    val name = d.name ?: "Unknown"
                    val address = d.address ?: ""
                    val btClass = d.bluetoothClass
                    val majorClass = btClass?.majorDeviceClass ?: 0
                    val deviceClass = btClass?.deviceClass ?: 0
                    if (com.example.utils.BluetoothPrinterService.isThermalPrinter(name, majorClass, deviceClass, isBonded = true)) {
                        foundPrintersMap[address] = -50
                    }
                }
            }
        } catch (e: SecurityException) {
            e.printStackTrace()
        }

        val receiver = com.example.utils.BluetoothPrinterService.scanNearbyPrinters(
            context = context,
            onDeviceFound = { name, address, rssi, distance ->
                foundPrintersMap[address] = rssi
            },
            onScanFinished = {}
        )
        kitchenDiscoveryReceiver = receiver

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try {
                adapter.cancelDiscovery()
                if (kitchenDiscoveryReceiver != null) {
                    context.unregisterReceiver(kitchenDiscoveryReceiver)
                    kitchenDiscoveryReceiver = null
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val bondedAddresses = try {
                adapter.bondedDevices?.map { it.address }?.toSet() ?: emptySet()
            } catch (e: SecurityException) {
                emptySet()
            }

            val list = foundPrintersMap.entries.map { entry ->
                val address = entry.key
                val rssi = entry.value
                val name = try {
                    adapter.getRemoteDevice(address)?.name ?: "Thermal Printer"
                } catch (e: SecurityException) {
                    "Thermal Printer"
                }
                val isBonded = bondedAddresses.contains(address)
                val distance = Math.pow(10.0, (-60.0 - rssi) / 22.0)
                val distanceStr = String.format(java.util.Locale.ENGLISH, "%.1fm", distance)
                val prefix = if (isBonded) "[جهاز مقترن] " else "[جهاز نشط] "
                val itemText = "$prefix$name ($address) - إشارة: ${rssi}dBm (~$distanceStr)"
                Pair(itemText, isBonded)
            }
            .sortedWith(compareByDescending { it.second })
            .map { it.first }

            _discoveredKitchenPrinters.value = list
            _isScanningKitchenPrinter.value = false
        }, 4000)
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun testConnectionForMainPrinter() {
        viewModelScope.launch {
            _mainPrinterStatus.value = "جاري فحص الاتصال..."
            val name = _printerName.value
            val mac = _mainPrinterMac.value.ifBlank {
                val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
                addressRegex.find(name)?.value ?: ""
            }

            if (mac.isBlank() || mac.contains("الافتراضية")) {
                _mainPrinterStatus.value = "غير متصلة، لم يتم تعيين عنوان ماك"
                return@launch
            }

            val success = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                var socket: android.bluetooth.BluetoothSocket? = null
                try {
                    val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
                    if (adapter == null || !adapter.isEnabled) return@withContext false
                    val device = adapter.getRemoteDevice(mac) ?: return@withContext false
                    socket = device.createRfcommSocketToServiceRecord(java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                    adapter.cancelDiscovery()
                    socket.connect()
                    val outputStream = socket.outputStream
                    outputStream.write(byteArrayOf(0x1B, 0x40)) // ESC @
                    outputStream.flush()
                    true
                } catch (e: Exception) {
                    android.util.Log.e("POSViewModel", "Main printer testConnection failed: ", e)
                    false
                } finally {
                    try {
                        socket?.close()
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                    }
                }
            }

            if (success) {
                _mainPrinterStatus.value = "متصلة وجاهزة وتعمل بنجاح"
            } else {
                _mainPrinterStatus.value = "غير متصلة، تأكد من تشغيل الطابعة"
            }
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun testConnectionForKitchenPrinter() {
        viewModelScope.launch {
            _kitchenPrinterStatus.value = "جاري فحص الاتصال..."
            val name = _selectedKitchenPrinterName.value
            val mac = _kitchenPrinterMac.value.ifBlank {
                val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
                addressRegex.find(name)?.value ?: ""
            }

            if (mac.isBlank()) {
                _kitchenPrinterStatus.value = "غير متصلة، لم يتم تعيين عنوان ماك"
                return@launch
            }

            val success = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                var socket: android.bluetooth.BluetoothSocket? = null
                try {
                    val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
                    if (adapter == null || !adapter.isEnabled) return@withContext false
                    val device = adapter.getRemoteDevice(mac) ?: return@withContext false
                    socket = device.createRfcommSocketToServiceRecord(java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                    adapter.cancelDiscovery()
                    socket.connect()
                    val outputStream = socket.outputStream
                    outputStream.write(byteArrayOf(0x1B, 0x40)) // ESC @
                    outputStream.flush()
                    true
                } catch (e: Exception) {
                    android.util.Log.e("POSViewModel", "Kitchen printer testConnection failed: ", e)
                    false
                } finally {
                    try {
                        socket?.close()
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                    }
                }
            }

            if (success) {
                _kitchenPrinterStatus.value = "متصلة وجاهزة وتعمل بنجاح"
            } else {
                _kitchenPrinterStatus.value = "غير متصلة، تأكد من تشغيل الطابعة"
            }
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun testPrintForPrinter(isKitchen: Boolean) {
        viewModelScope.launch {
            val statusFlow = if (isKitchen) _kitchenPrinterStatus else _mainPrinterStatus
            val name = if (isKitchen) _selectedKitchenPrinterName.value else _printerName.value
            val pSize = if (isKitchen) _kitchenPaperSize.value else _mainPaperSize.value
            val mac = if (isKitchen) {
                _kitchenPrinterMac.value.ifBlank {
                    val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
                    addressRegex.find(name)?.value ?: ""
                }
            } else {
                _mainPrinterMac.value.ifBlank {
                    val addressRegex = "([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})".toRegex()
                    addressRegex.find(name)?.value ?: ""
                }
            }

            if (mac.isBlank() || (!isKitchen && mac.contains("الافتراضية"))) {
                statusFlow.value = "لم يتم تحديد طابعة لإجراء الطباعة التجريبية"
                return@launch
            }

            statusFlow.value = "جاري إرسال أمر الطباعة التجريبية..."

            val testTitle = if (isKitchen) "تجربة طابعة المطبخ والطلبات" else "تجربة طابعة الكاشير الأساسية"
            
            val success = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val bitmap = com.example.utils.ReceiptPrinterHelper.generateTestReceiptBitmap(
                        context,
                        pSize,
                        testTitle
                    )
                    com.example.utils.BluetoothPrinterService.printReceiptViaBluetooth(context, mac, bitmap)
                } catch (e: Exception) {
                    android.util.Log.e("POSViewModel", "testPrintForPrinter error: ", e)
                    false
                }
            }

            if (success) {
                statusFlow.value = "تمت الطباعة التجريبية بنجاح!"
            } else {
                statusFlow.value = "فشلت الطباعة التجريبية، يرجى التأكد من تشغيل الطابعة والبلوتوث"
            }
        }
    }

    fun disconnectPrinter(isKitchen: Boolean) {
        if (!isKitchen) {
            _printerName.value = ""
            _mainPrinterMac.value = ""
            _mainPrinterStatus.value = "جاهزة للفحص"
            prefs.edit()
                .putString("selected_printer_name", "")
                .putString("main_printer_mac", "")
                .putString("main_printer_status", "جاهزة للفحص")
                .apply()
        } else {
            _selectedKitchenPrinterName.value = ""
            _kitchenPrinterMac.value = ""
            _kitchenPrinterStatus.value = "جاهزة للفحص"
            prefs.edit()
                .putString("selected_kitchen_printer_name", "")
                .putString("kitchen_printer_mac", "")
                .putString("kitchen_printer_status", "جاهزة للفحص")
                .apply()
        }
    }

    private val _mainPaperSize = MutableStateFlow(prefs.getString("selected_paper_size", "80mm") ?: "80mm")
    val mainPaperSize: StateFlow<String> = _mainPaperSize.asStateFlow()
    val paperSize: StateFlow<String> = _mainPaperSize.asStateFlow()

    fun updateMainPaperSize(size: String) {
        _mainPaperSize.value = size
        prefs.edit().putString("selected_paper_size", size).apply()
    }

    fun updatePaperSize(size: String) {
        updateMainPaperSize(size)
    }

    private val _kitchenPaperSize = MutableStateFlow(prefs.getString("kitchen_paper_size", "80mm") ?: "80mm")
    val kitchenPaperSize: StateFlow<String> = _kitchenPaperSize.asStateFlow()

    fun updateKitchenPaperSize(size: String) {
        _kitchenPaperSize.value = size
        prefs.edit().putString("kitchen_paper_size", size).apply()
    }

    private val _textThickness = MutableStateFlow(prefs.getString("selected_text_thickness", "normal") ?: "normal")
    val textThickness: StateFlow<String> = _textThickness.asStateFlow()

    fun updateTextThickness(thickness: String) {
        _textThickness.value = thickness
        prefs.edit().putString("selected_text_thickness", thickness).apply()
    }

    private val _mainItemsTextSize = MutableStateFlow(prefs.getString("main_printer_items_text_size", "normal") ?: "normal")
    val mainItemsTextSize: StateFlow<String> = _mainItemsTextSize.asStateFlow()

    fun updateMainItemsTextSize(size: String) {
        _mainItemsTextSize.value = size
        prefs.edit().putString("main_printer_items_text_size", size).apply()
    }

    fun reprintInvoice(
        invoice: Invoice,
        items: List<InvoiceItem>,
        printOption: PrintOption,
        printTarget: PrintTarget
    ) {
        ReceiptPrinterHelper.reprintOrder(
            context = context,
            invoice = invoice,
            items = items,
            printOption = printOption,
            printTarget = printTarget
        )
    }

    private val _logoPrintSize = MutableStateFlow(prefs.getInt("logo_print_size", 100))
    val logoPrintSize: StateFlow<Int> = _logoPrintSize.asStateFlow()

    fun updateLogoPrintSize(size: Int) {
        _logoPrintSize.value = size
        prefs.edit().putInt("logo_print_size", size).apply()
    }

    private val _printKitchenReceipt = MutableStateFlow(prefs.getBoolean("print_kitchen_receipt", true))
    val printKitchenReceipt: StateFlow<Boolean> = _printKitchenReceipt.asStateFlow()

    fun updatePrintKitchenReceipt(enabled: Boolean) {
        _printKitchenReceipt.value = enabled
        prefs.edit().putBoolean("print_kitchen_receipt", enabled).apply()
    }

    private val _isKitchenPrinterEnabled = MutableStateFlow(prefs.getBoolean("is_kitchen_printer_enabled", false))
    val isKitchenPrinterEnabled: StateFlow<Boolean> = _isKitchenPrinterEnabled.asStateFlow()

    fun updateIsKitchenPrinterEnabled(enabled: Boolean) {
        _isKitchenPrinterEnabled.value = enabled
        prefs.edit().putBoolean("is_kitchen_printer_enabled", enabled).apply()
    }

    private val _isKitchenOptionalEnabled = MutableStateFlow(prefs.getBoolean("is_kitchen_optional_enabled", false))
    val isKitchenOptionalEnabled: StateFlow<Boolean> = _isKitchenOptionalEnabled.asStateFlow()

    fun updateIsKitchenOptionalEnabled(enabled: Boolean) {
        _isKitchenOptionalEnabled.value = enabled
        prefs.edit().putBoolean("is_kitchen_optional_enabled", enabled).apply()
    }

    private val _restaurantLogoPath = MutableStateFlow<String?>(
        if (java.io.File(context.filesDir, "restaurant_logo.png").exists()) {
            java.io.File(context.filesDir, "restaurant_logo.png").absolutePath
        } else null
    )
    val restaurantLogoPath: StateFlow<String?> = _restaurantLogoPath.asStateFlow()

    fun updateRestaurantLogo(uri: android.net.Uri) {
        viewModelScope.launch {
            val path = saveLogoToInternalStorage(context, uri)
            _restaurantLogoPath.value = path
        }
    }

    fun removeRestaurantLogo() {
        val file = java.io.File(context.filesDir, "restaurant_logo.png")
        if (file.exists()) {
            file.delete()
        }
        _restaurantLogoPath.value = null
    }

    private fun saveLogoToInternalStorage(context: Context, uri: android.net.Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val logoFile = java.io.File(context.filesDir, "restaurant_logo.png")
            val outputStream = java.io.FileOutputStream(logoFile)
            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            logoFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateDemoMeals() {
        // Function removed per user request
    }

    // Active user fields removed to avoid duplicates; defined at the top of the ViewModel.

    fun openShift(name: String, openingCapital: Double) {
        viewModelScope.launch {
            repository.clearInvoicesAndItems() // Clear existing orders and reset invoice number to 1
            repository.insertShiftLog(ShiftLog(
                shiftName = name,
                status = "مفتوحة",
                openingCapital = openingCapital,
                startTime = System.currentTimeMillis()
            ))
        }
    }

    fun closeShift(shiftId: Int, totalSales: Double, netProfit: Double) {
        viewModelScope.launch {
            val log = shiftLogs.value.find { it.id == shiftId } ?: return@launch
            repository.updateShiftLog(log.copy(
                endTime = System.currentTimeMillis(),
                status = "مغلقة",
                totalSales = totalSales,
                netProfit = netProfit
            ))
            repository.clearInvoicesAndItems() // Clear orders when shift is closed
        }
    }

    val isPOSOpen: StateFlow<Boolean> = shiftLogs.map { logs ->
        logs.any { it.status == "مفتوحة" }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)


    fun deleteInvoice(invoice: Invoice) {
        viewModelScope.launch {
            repository.deleteInvoice(invoice)
        }
    }

    fun cancelInvoice(invoice: Invoice, reason: String) {
        viewModelScope.launch {
            repository.updateInvoice(invoice.copy(
                status = "ملغاة",
                cancelReason = reason
            ))
        }
    }

    fun addExpense(amount: Double, reason: String, shiftId: Int) {
        viewModelScope.launch {
            repository.insertExpense(ExpenseEntity(amount = amount, reason = reason, shiftId = shiftId))
        }
    }

    private val _isPrintingExpenses = MutableStateFlow(false)
    val isPrintingExpenses: StateFlow<Boolean> = _isPrintingExpenses.asStateFlow()

    fun printExpensesReport(
        context: Context,
        expenses: List<ExpenseEntity>,
        totalExpenses: Double,
        onResult: (Boolean, String) -> Unit
    ) {
        if (_isPrintingExpenses.value) return
        _isPrintingExpenses.value = true

        val activeShift = shiftLogs.value.firstOrNull { it.status == "مفتوحة" }
        val shiftName = activeShift?.shiftName ?: "الوردية الحالية"

        com.example.utils.ReceiptPrinterHelper.printExpensesReport(
            context = context,
            shiftName = shiftName,
            expenses = expenses,
            totalExpenses = totalExpenses
        ) { success, message ->
            _isPrintingExpenses.value = false
            onResult(success, message)
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun deleteShiftLog(shiftLog: ShiftLog) {
        viewModelScope.launch {
            repository.deleteShiftLog(shiftLog)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            repository.prepopulateIfEmpty()
        }
    }

    fun clearAllSystemData() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                // 1. Wipe all database tables
                val db = AppDatabase.getDatabase(context)
                db.clearAllTables()

                // 2. Clear SharedPreferences completely
                prefs.edit().clear().commit()

                // 3. Delete any local files (such as restaurant logos/images)
                context.filesDir.listFiles()?.forEach { file ->
                    file.delete()
                }

                // 4. Force clean application restart
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                    if (intent != null) {
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        context.startActivity(intent)
                    }
                    Runtime.getRuntime().exit(0)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // --- State: Expanded Cart Sheet (Salla) ---
    private val _showCartSheet = MutableStateFlow(false)
    val showCartSheet: StateFlow<Boolean> = _showCartSheet.asStateFlow()

    fun setShowCartSheet(show: Boolean) {
        _showCartSheet.value = show
    }

    @android.annotation.SuppressLint("MissingPermission")
    suspend fun checkPrinterConnection(mac: String): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (mac.isBlank()) return@withContext false
        var socket: android.bluetooth.BluetoothSocket? = null
        try {
            val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
            if (adapter == null || !adapter.isEnabled) return@withContext false
            val device = adapter.getRemoteDevice(mac) ?: return@withContext false
            socket = device.createRfcommSocketToServiceRecord(java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
            adapter.cancelDiscovery()
            socket.connect()
            val outputStream = socket.outputStream
            outputStream.write(byteArrayOf(0x1B, 0x40)) // ESC @
            outputStream.flush()
            true
        } catch (e: Exception) {
            android.util.Log.e("POSViewModel", "checkPrinterConnection $mac failed: ", e)
            false
        } finally {
            try {
                socket?.close()
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }

    // --- Backup & Restore State & Logic ---
    private val _isBackupRestoreLoading = MutableStateFlow(false)
    val isBackupRestoreLoading: StateFlow<Boolean> = _isBackupRestoreLoading.asStateFlow()

    fun exportFullBackup(onSuccess: (java.io.File) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            _isBackupRestoreLoading.value = true
            try {
                val file = com.example.utils.BackupManager.exportBackup(context, repository)
                _isBackupRestoreLoading.value = false
                onSuccess(file)
            } catch (e: Exception) {
                e.printStackTrace()
                _isBackupRestoreLoading.value = false
                onError(e.localizedMessage ?: "حدث خطأ أثناء إنشاء النسخة الاحتياطية")
            }
        }
    }

    fun restoreFullBackup(zipUri: android.net.Uri, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            _isBackupRestoreLoading.value = true
            try {
                val success = com.example.utils.BackupManager.restoreBackup(context, repository, zipUri)
                if (success) {
                    refreshSettingsFromPrefs()
                    _isBackupRestoreLoading.value = false
                    onSuccess()
                } else {
                    throw Exception("تعذر استعادة النسخة الاحتياطية")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _isBackupRestoreLoading.value = false
                onError(e.localizedMessage ?: "ملف النسخة الاحتياطية غير صالح أو تالف")
            }
        }
    }

    private fun refreshSettingsFromPrefs() {
        _restaurantName.value = com.example.utils.UserAli.getRestaurantNameFromPrefs(context)
        _mainPrinterMac.value = prefs.getString("main_printer_mac", "") ?: ""
        _printerName.value = prefs.getString("selected_printer_name", "") ?: ""
        _mainPaperSize.value = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        _kitchenPaperSize.value = prefs.getString("kitchen_paper_size", "80mm") ?: "80mm"
        _textThickness.value = prefs.getString("selected_text_thickness", "normal") ?: "normal"
        _mainItemsTextSize.value = prefs.getString("main_printer_items_text_size", "normal") ?: "normal"
        _logoPrintSize.value = prefs.getInt("logo_print_size", 100)
        _printKitchenReceipt.value = prefs.getBoolean("print_kitchen_receipt", true)
        _isKitchenPrinterEnabled.value = prefs.getBoolean("is_kitchen_printer_enabled", false)
        _isKitchenOptionalEnabled.value = prefs.getBoolean("is_kitchen_optional_enabled", false)
        _restaurantLogoPath.value = if (java.io.File(context.filesDir, "restaurant_logo.png").exists()) {
            java.io.File(context.filesDir, "restaurant_logo.png").absolutePath
        } else null
    }
}

class POSViewModelFactory(private val repository: POSRepository, private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(POSViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return POSViewModel(repository, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
