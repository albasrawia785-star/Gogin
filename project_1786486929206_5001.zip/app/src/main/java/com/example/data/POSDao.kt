package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface POSDao {

    // --- Category Queries ---
    @Query("SELECT * FROM categories ORDER BY id ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category): Long

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)

    @Query("DELETE FROM products WHERE categoryId = :categoryId")
    suspend fun deleteProductsByCategory(categoryId: Int)


    // --- Product Queries ---
    @Query("SELECT * FROM products ORDER BY id DESC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE categoryId = :categoryId ORDER BY id DESC")
    fun getProductsByCategory(categoryId: Int): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE name LIKE :query ORDER BY id DESC")
    fun searchProducts(query: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)


    // --- Invoice Queries ---
    @Query("SELECT * FROM invoices ORDER BY invoiceNumber DESC")
    fun getAllInvoices(): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices ORDER BY invoiceNumber DESC LIMIT :limit")
    fun getRecentInvoices(limit: Int): Flow<List<Invoice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: Invoice): Long

    @Query("SELECT * FROM invoices WHERE invoiceNumber = :invoiceNumber")
    suspend fun getInvoiceById(invoiceNumber: Long): Invoice?


    // --- Invoice Item Queries ---
    @Query("SELECT * FROM invoice_items WHERE invoiceNumber = :invoiceNumber")
    fun getItemsForInvoice(invoiceNumber: Long): Flow<List<InvoiceItem>>

    @Query("SELECT * FROM invoice_items ORDER BY id DESC")
    fun getAllInvoiceItems(): Flow<List<InvoiceItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoiceItem(item: InvoiceItem)


    // --- Shift Log Queries ---
    @Query("SELECT * FROM shift_logs ORDER BY id DESC")
    fun getAllShiftLogs(): Flow<List<ShiftLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShiftLog(shiftLog: ShiftLog): Long

    @Update
    suspend fun updateShiftLog(shiftLog: ShiftLog)

    @Delete
    suspend fun deleteShiftLog(shiftLog: ShiftLog)

    @Delete
    suspend fun deleteInvoice(invoice: Invoice)

    @Update
    suspend fun updateInvoice(invoice: Invoice)

    @Query("DELETE FROM sqlite_sequence WHERE name = 'invoices'")
    suspend fun resetInvoiceSequence()

    @Query("DELETE FROM invoice_items WHERE invoiceNumber = :invoiceNumber")
    suspend fun deleteInvoiceItemsByInvoiceNo(invoiceNumber: Long)

    @Query("DELETE FROM categories")
    suspend fun clearCategories()

    @Query("DELETE FROM products")
    suspend fun clearProducts()

    @Query("DELETE FROM invoices")
    suspend fun clearInvoices()

    @Query("DELETE FROM invoice_items")
    suspend fun clearInvoiceItems()

    @Query("DELETE FROM shift_logs")
    suspend fun clearShiftLogs()

    // --- Expense Queries ---
    @Query("SELECT * FROM expenses ORDER BY id DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    @Query("DELETE FROM expenses")
    suspend fun clearExpenses()

    // --- Direct List Queries for Backup ---
    @Query("SELECT * FROM categories ORDER BY id ASC")
    suspend fun getAllCategoriesList(): List<Category>

    @Query("SELECT * FROM products ORDER BY id DESC")
    suspend fun getAllProductsList(): List<Product>

    @Query("SELECT * FROM invoices ORDER BY invoiceNumber DESC")
    suspend fun getAllInvoicesList(): List<Invoice>

    @Query("SELECT * FROM invoice_items ORDER BY id DESC")
    suspend fun getAllInvoiceItemsList(): List<InvoiceItem>

    @Query("SELECT * FROM shift_logs ORDER BY id DESC")
    suspend fun getAllShiftLogsList(): List<ShiftLog>

    @Query("SELECT * FROM expenses ORDER BY id DESC")
    suspend fun getAllExpensesList(): List<ExpenseEntity>

    // --- Batch Inserts for Restore ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<Category>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoices(invoices: List<Invoice>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoiceItems(items: List<InvoiceItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShiftLogs(shifts: List<ShiftLog>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(expenses: List<ExpenseEntity>)
}
