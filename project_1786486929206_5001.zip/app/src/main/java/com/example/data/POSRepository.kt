package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class POSRepository(private val posDao: POSDao) {

    val allCategories: Flow<List<Category>> = posDao.getAllCategories()
    val allProducts: Flow<List<Product>> = posDao.getAllProducts()
    val allInvoices: Flow<List<Invoice>> = posDao.getAllInvoices()
    val allShiftLogs: Flow<List<ShiftLog>> = posDao.getAllShiftLogs()
    val allInvoiceItems: Flow<List<InvoiceItem>> = posDao.getAllInvoiceItems()

    fun getRecentInvoices(limit: Int): Flow<List<Invoice>> {
        return posDao.getRecentInvoices(limit)
    }

    fun getProductsByCategory(categoryId: Int): Flow<List<Product>> {
        return posDao.getProductsByCategory(categoryId)
    }

    fun searchProducts(query: String): Flow<List<Product>> {
        return posDao.searchProducts("%$query%")
    }

    fun getItemsForInvoice(invoiceNumber: Long): Flow<List<InvoiceItem>> {
        return posDao.getItemsForInvoice(invoiceNumber)
    }

    suspend fun insertCategory(category: Category): Long = withContext(Dispatchers.IO) {
        posDao.insertCategory(category)
    }

    suspend fun updateCategory(category: Category) = withContext(Dispatchers.IO) {
        posDao.updateCategory(category)
    }

    suspend fun deleteCategory(category: Category) = withContext(Dispatchers.IO) {
        posDao.deleteProductsByCategory(category.id)
        posDao.deleteCategory(category)
    }

    suspend fun insertProduct(product: Product): Long = withContext(Dispatchers.IO) {
        posDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) = withContext(Dispatchers.IO) {
        posDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) = withContext(Dispatchers.IO) {
        posDao.deleteProduct(product)
    }

    suspend fun createInvoice(invoice: Invoice, items: List<InvoiceItem>): Long = withContext(Dispatchers.IO) {
        val invoiceNumber = posDao.insertInvoice(invoice)
        items.forEach { item ->
            posDao.insertInvoiceItem(item.copy(invoiceNumber = invoiceNumber))
        }
        invoiceNumber
    }

    suspend fun insertShiftLog(shiftLog: ShiftLog): Long = withContext(Dispatchers.IO) {
        posDao.insertShiftLog(shiftLog)
    }

    suspend fun updateShiftLog(shiftLog: ShiftLog) = withContext(Dispatchers.IO) {
        posDao.updateShiftLog(shiftLog)
    }

    suspend fun deleteShiftLog(shiftLog: ShiftLog) = withContext(Dispatchers.IO) {
        posDao.deleteShiftLog(shiftLog)
    }

    suspend fun deleteInvoice(invoice: Invoice) = withContext(Dispatchers.IO) {
        posDao.deleteInvoice(invoice)
        posDao.deleteInvoiceItemsByInvoiceNo(invoice.invoiceNumber)
    }

    suspend fun updateInvoice(invoice: Invoice) = withContext(Dispatchers.IO) {
        posDao.updateInvoice(invoice)
    }

    suspend fun clearInvoicesAndItems() = withContext(Dispatchers.IO) {
        posDao.clearInvoices()
        posDao.clearInvoiceItems()
        posDao.resetInvoiceSequence()
    }

    val allExpenses: Flow<List<ExpenseEntity>> = posDao.getAllExpenses()

    suspend fun insertExpense(expense: ExpenseEntity): Long = withContext(Dispatchers.IO) {
        posDao.insertExpense(expense)
    }

    suspend fun deleteExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        posDao.deleteExpense(expense)
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        posDao.clearCategories()
        posDao.clearProducts()
        posDao.clearInvoices()
        posDao.clearInvoiceItems()
        posDao.clearShiftLogs()
        posDao.clearExpenses()
    }

    suspend fun getAllCategoriesList(): List<Category> = withContext(Dispatchers.IO) { posDao.getAllCategoriesList() }
    suspend fun getAllProductsList(): List<Product> = withContext(Dispatchers.IO) { posDao.getAllProductsList() }
    suspend fun getAllInvoicesList(): List<Invoice> = withContext(Dispatchers.IO) { posDao.getAllInvoicesList() }
    suspend fun getAllInvoiceItemsList(): List<InvoiceItem> = withContext(Dispatchers.IO) { posDao.getAllInvoiceItemsList() }
    suspend fun getAllShiftLogsList(): List<ShiftLog> = withContext(Dispatchers.IO) { posDao.getAllShiftLogsList() }
    suspend fun getAllExpensesList(): List<ExpenseEntity> = withContext(Dispatchers.IO) { posDao.getAllExpensesList() }

    suspend fun restoreDatabaseData(
        categories: List<Category>,
        products: List<Product>,
        invoices: List<Invoice>,
        invoiceItems: List<InvoiceItem>,
        shiftLogs: List<ShiftLog>,
        expenses: List<ExpenseEntity>
    ) = withContext(Dispatchers.IO) {
        posDao.clearCategories()
        posDao.clearProducts()
        posDao.clearInvoices()
        posDao.clearInvoiceItems()
        posDao.clearShiftLogs()
        posDao.clearExpenses()

        if (categories.isNotEmpty()) posDao.insertCategories(categories)
        if (products.isNotEmpty()) posDao.insertProducts(products)
        if (invoices.isNotEmpty()) posDao.insertInvoices(invoices)
        if (invoiceItems.isNotEmpty()) posDao.insertInvoiceItems(invoiceItems)
        if (shiftLogs.isNotEmpty()) posDao.insertShiftLogs(shiftLogs)
        if (expenses.isNotEmpty()) posDao.insertExpenses(expenses)
    }

    suspend fun prepopulateIfEmpty() = withContext(Dispatchers.IO) {
        // Do not prepopulate the default shift anymore
    }
}
